print -r -- WSH_WAITING
read -r reply
zmodload zsh/stat || exit 3
zmodload zsh/system || exit 4
zmodload zsh/datetime || exit 5
zmodload -u zsh/stat || exit 6
zmodload zsh/stat || exit 7
module_path=($1 $module_path)
zmodload wshsuggest || exit 8
(( $+builtins[wsh-history-suggest] )) || exit 9
zmodload -u wshsuggest || exit 10
zmodload wshsuggest || exit 11
print -r -- WSH_LINKED_AND_EXTERNAL_OK
