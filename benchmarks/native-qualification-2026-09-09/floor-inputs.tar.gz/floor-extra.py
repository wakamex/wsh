from pathlib import Path
import json,subprocess
p=Path('/var/tmp/wsh-native-qualification');work=p/'build-a'
bundle=next((work/'build/floor/bundles').glob('[0-9a-f]'*64));b='/workspace/'+str(bundle.relative_to(work));out='/workspace/build/floor/extra'
commands=[['python3','native/test-profile.py',b,out+'/profile'],['python3','native/test-profile-report.py',b+'/bin/wsh',out+'/report','--native'],['python3','native/test-profile-storage.py',b+'/bin/wsh',out+'/storage'],['python3','native/test-profile-lifecycle.py',b,out+'/lifecycle'],['python3','native/test-profile-isolation.py',b,out+'/isolation'],['python3','native/test-runtime-protocol.py','/workspace/build/portable/glibc-2.28/target/release/wsh-runtime',b+'/bin/wsh-runtime',out+'/protocol'],['python3','native/test-runtime-lifecycle.py',b+'/bin/wsh-runtime',out+'/runtime'],['python3','native/test-recovery.py',b,out+'/recovery']]
script='import subprocess,json\nfrom pathlib import Path\nout=Path('+repr(out)+');out.mkdir(parents=True,exist_ok=True)\nresults=[]\nfor i,cmd in enumerate('+repr(commands)+'):\n with (out/(str(i)+".log")).open("wb") as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)\n results.append({"command":cmd,"status":r.returncode})\n (out/"results.json").write_text(json.dumps(results,indent=2)+"\\n")\n print(cmd[1],r.returncode,flush=True)\n if r.returncode:raise SystemExit(r.returncode)\n'
(work/'build/floor/test-extra.py').write_text(script)
base=json.loads((p/'floor-contracts-command.json').read_text());base=base[:base.index('localhost/wsh-native-floor-prototype-20260909')+1]+['python3','build/floor/test-extra.py']
(p/'floor-extra-command.json').write_text(json.dumps(base,indent=2)+'\n')
with (p/'floor-extra.log').open('wb') as log:r=subprocess.run(base,stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(r.returncode)
