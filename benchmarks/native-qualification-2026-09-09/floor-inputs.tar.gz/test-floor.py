from pathlib import Path
import json,subprocess
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-qualification');work=p/'build-a'
bundle=next((work/'build/floor/bundles').glob('[0-9a-f]'*64))
raw='/workspace/build/portable/glibc-2.28/zsh/zsh-cad0d67c-wsh2/bin/zsh'
cmd=['podman','run','--rm','--init','--userns=keep-id','--network=none','--workdir','/workspace']
for host,guest,mode in [(work,'/workspace','Z'),(r/'native/check-installation.py','/workspace/native/check-installation.py','ro,Z'),(r/'build/portable/glibc-2.28','/workspace/build/portable/glibc-2.28','ro,Z'),(Path('/home/mihai/.oh-my-zsh'),'/omz','ro,Z')]:cmd+=['--volume',str(host)+':'+guest+':'+mode]
for k,v in {'WSH_TEST_ZSH':raw,'WSH_REFERENCE_ZSH':raw,'WSH_TEST_MANAGER':'/workspace/build/floor/target/release/wsh','WSH_TEST_OMZ':'/omz','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}.items():cmd+=['--env',k+'='+v]
cmd+=['localhost/wsh-native-floor-prototype-20260909','python3','native/check-installation.py','/workspace/'+str(bundle.relative_to(work)),'/workspace/build/floor/contracts']
(p/'floor-contracts-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (p/'floor-contracts.log').open('wb') as log:res=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(res.returncode)
