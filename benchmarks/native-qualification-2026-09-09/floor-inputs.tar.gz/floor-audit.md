# Floor qualification environment audit

The initial SDK image lacked Python, which native lock preparation invokes. The corrected offline extension includes signature-verified Rocky Python 3.9 RPMs and an explicit python3 symlink. No native source change was needed.

The first native build and upstream suite passed. During the second build, starting the canonical legacy container against the same worktree with a private SELinux `:Z` mount relabeled its files away from the first container. The native upstream suite then reported Permission denied, including cleanup of Modules and .zcompdump. This is an invalid concurrent experiment. Finish the canonical container before restarting the second native build; use each worktree in one build container at a time. Retain the failed output.

The first floor component container used Python as PID 1. Its foreground regression found an orphan zombie, unlike the host and VM runs. Repeat the exact native component suite with Podman's init process to give orphan children the normal system reaper. This changes the test supervisor only. A continued failure would require a new process-ownership investigation, not weaker assertions.
