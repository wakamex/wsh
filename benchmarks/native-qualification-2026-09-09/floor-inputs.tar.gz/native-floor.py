from pathlib import Path
import json,os,subprocess
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-qualification');rev=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();epoch=subprocess.check_output(['git','show','-s','--format=%ct',rev],cwd=r,text=True).strip()
image='localhost/wsh-native-floor-prototype-20260909'
toolchain=Path.home()/'.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu'
subprocess.run([str(r/'build/verify-rust-toolchain.zsh')],check=True,cwd=r)
for name in ['build-a','build-b']:
 work=p/name
 
 if not work.exists():subprocess.run(['git','worktree','add','--detach',str(work),rev],cwd=r,check=True)
 env={'WSH_RUST_TOOLCHAIN_ROOT':'/toolchain','CARGO_HOME':'/workspace/build/floor/cargo-home','CARGO_TARGET_DIR':'/workspace/build/floor/target','CARGO_BUILD_JOBS':'1','PATH':'/toolchain/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','SOURCE_DATE_EPOCH':epoch,'WSH_ZSH_OUTPUT_ROOT':'/workspace/build/floor/zsh','WSH_BUNDLE_OUTPUT_ROOT':'/workspace/build/floor/bundles','WSH_BUILD_JOBS':'2','WSH_MINIMUM_GLIBC':'2.28','WSH_SOURCE_REVISION':rev,'WSH_KEEP_FAILED_BUILD':'1','WSH_BUILDER_BASE_IMAGE':'sha256:5da32743ab3b62bd8ebf0e67580d32512733e2a5e8b09f2f1b45d199ef7f5dd8'}
 command=['podman','run','--rm','--userns=keep-id','--network=host','--volume',str(work)+':/workspace:Z','--volume',str(toolchain)+':/toolchain:ro,Z','--workdir','/workspace']
 for k,v in env.items():command+=['--env',k+'='+v]
 command += [image,'zsh','-c','set -e; umask 022; ./build/build-native-installation.zsh']
 (p/(name+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
 with (p/(name+'-floor.log')).open('wb') as log:res=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 print(name,res.returncode,flush=True)
 if res.returncode:raise SystemExit(res.returncode)
