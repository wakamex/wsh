from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-qualification');v=Path('/var/tmp/wsh-native-vm');o=r/'benchmarks/native-qualification-2026-09-09'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
names=['native/check-installation.py','native/prepare-build.py','build/build-native-installation.zsh','build/build-development-bundle.zsh','build/build-zsh.zsh','build/archive-development-bundle.zsh','build/build-glibc-2.28-development-bundle.zsh','build/test-development-bundle.zsh','build/zsh-sources/zsh-cad0d67c-native.json','build/glibc-2.28-builder.lock','build/rust-toolchain.lock','packaging/build-rpm.py','packaging/wsh-native.spec']
names += [str(f.relative_to(r)) for pattern in ['*.c','*.h','test-profile*.py','test-runtime*.py','test-recovery.py','build-runtime.zsh','build-theme-prototype.zsh','tomlc17-wsh.patch'] for f in (r/'native').glob(pattern)]
names = sorted(set(names))
with tarfile.open(o/'floor-inputs.tar.gz','w:gz') as a:
 for n in names:a.add(r/n,arcname=n)
 for n in ['Containerfile','Containerfile.initial','native-floor.py','test-floor.py','floor-extra.py','floor-audit.md','sdk-packages.json']:a.add(p/n,arcname=n)
 for f in sorted((p/'sdk-rpms').glob('*.rpm')):a.add(f,arcname='sdk-rpms/'+f.name)
 a.add(__file__,arcname='retain-floor.py')
with tarfile.open(o/'floor-results.tar.gz','w:gz') as a:
 for n in ['build-a-floor.log','build-b-floor.log','build-a-missing-python.log','build-b-selinux-conflict.log','native-floor-driver.log','native-floor-driver-final.log','build-b-retry-driver.log','build-a-command.json','build-b-command.json','canonical-legacy-floor.log','floor-contracts.log','floor-contracts-no-init.log','floor-contracts-command.json','floor-extra.log','floor-extra-command.json','floor-elf.json','archive-a.log','final-reproduction.log','reproduction-results.json','floor-rpm-a.log','sdk-resolution.log','sdk-python-resolution.log','sdk-image.log','sdk-image-python.log']:a.add(p/n,arcname=n)
 for directory in ['contracts','contracts-no-init','extra']:
  for f in (p/'build-a/build/floor'/directory).rglob('*'):
   if f.is_file():a.add(f,arcname=str(f.relative_to(p/'build-a/build/floor')))
 a.add(next((p/'archives-a').glob('*.tar.xz')),arcname='native.tar.xz')
 a.add(next((p/'floor-rpm-a/RPMS').rglob('*.rpm')),arcname='native.rpm')
 selected=set(v.glob('floor-package-*'))
 for prefix in ['state-corrupt','state-unreadable','state-incompatible','runtime-missing','runtime-unreadable','runtime-incompatible','integration-missing']:
  selected.update(v.glob(prefix+'*.log'));selected.add(v/(prefix+'.json'));selected.add(v/(prefix+'.bin'))
 selected.add(v/'recovery-results.json')
 for f in sorted(selected):
  if f.is_file():a.add(f,arcname='vm/'+f.name)
meta={'recorded_at_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'+dirty','built_source_revision':json.loads((p/'reproduction-results.json').read_text())['source_revision'],'source_inputs':{n:sha(r/n) for n in names},'sdk_packages':json.loads((p/'sdk-packages.json').read_text()),'sdk_image':'sha256:5da32743ab3b62bd8ebf0e67580d32512733e2a5e8b09f2f1b45d199ef7f5dd8','canonical_base':'ghcr.io/wakamex/wsh-builder-glibc-2.28@sha256:74dda0facfec11e403a2cfd17cd6b08cdc4e13f28a9f161c21b1a1b30ac3b1fb','host':subprocess.check_output(['uname','-a'],text=True).strip(),'commands':'Exact native container argv are build-a-command.json and build-b-command.json. The canonical command is ./build/build-glibc-2.28-development-bundle.zsh at the same source commit. Extra harness commands, RPM/archiver commands and VM scripts are retained with their outputs.'}
(o/'floor-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(o/'floor-SHA256SUMS').write_text(''.join(sha(o/n)+'  '+str((o/n).relative_to(r))+'\n' for n in ['floor-report.md','floor-metadata.json','floor-inputs.tar.gz','floor-results.tar.gz']))
