set -e
dnf -y upgrade /var/tmp/wsh-native-development-0.3.1-0.6.fc44.x86_64.rpm
restorecon -R /usr/libexec/wsh /usr/bin/wsh
rpm -V wsh-native-development
sha256sum /usr/libexec/wsh/bin/wsh /usr/libexec/wsh/bin/wsh-runtime
/usr/bin/wsh --wsh-version
