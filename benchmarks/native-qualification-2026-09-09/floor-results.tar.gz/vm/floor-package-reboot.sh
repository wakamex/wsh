set -e
dnf -y downgrade /var/tmp/wsh-native-development-0.3.1-0.2.fc44.x86_64.rpm
dnf -y upgrade /var/tmp/wsh-native-development-0.3.1-0.6.fc44.x86_64.rpm
restorecon -R /usr/libexec/wsh /usr/bin/wsh
rpm -V wsh-native-development
if rpm -e wsh-native-development; then exit 1; fi
cat /proc/sys/kernel/random/boot_id
systemctl reboot
