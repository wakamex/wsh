set -e
cat /proc/sys/kernel/random/boot_id
getenforce
rpm -V wsh-native-development
sha256sum /usr/libexec/wsh/bin/wsh /usr/libexec/wsh/bin/wsh-runtime
