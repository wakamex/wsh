from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-qualification');out=r/'benchmarks/native-qualification-2026-09-09'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
names=['build/build-zsh.zsh','build/build-development-bundle.zsh','build/update-native-lock.py','build/zsh-sources/zsh-cad0d67c-native.json','native/startup.c','native/prepare-build.py','native/test-linked-modules.py','native/test-startup.py','native/check-installation.py','native/measure-startup.py','native/measure-linked-memory.py','native/suggestion-kernel-prototype.c','benchmarks/native-qualification-2026-09-09/modules-plan.md']
with tarfile.open(out/'modules-inputs.tar.gz','w:gz') as a:
 for n in names:a.add(r/n,arcname=n)
 a.add(__file__,arcname='retain-modules.py')
with tarfile.open(out/'modules-results.tar.gz','w:gz') as a:
 for f in p.iterdir():
  if f.is_file() and f.name.startswith(('linked-','module-','static-','sanitized-dynamic')):a.add(f,arcname=f.name)
 for directory in ['module-lifetime','module-lifetime-sanitized','linked-startup','linked-startup-sanitized','linked-contracts','linked-c-contracts','linked-timing','linked-memory']:
  for f in (p/directory).iterdir():
   if f.is_file():a.add(f,arcname=str(f.relative_to(p)))
base=p/'path-installations/2c45e74d390fee2d8f131f14e99cc174951bf24080203ef2227d838656ff8cf8';candidate=p/'linked-installations/622516bc153c52658ade6eaa9ea4e014e3306bfffe8e34d6fe8b63b092d2fe00'
meta=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'+dirty',source_inputs={n:sha(r/n) for n in names},variants={k:dict(manifest_sha256=sha(b/'manifest.json'),zsh_sha256=sha(b/'bin/wsh'),runtime_sha256=sha(b/'bin/wsh-runtime')) for k,b in [('control',base),('candidate',candidate)]},sanitized_binary_sha256=sha(p/'linked-sanitized-installation/bin/wsh'),external_module_sha256=sha(Path('/var/tmp/wsh-native-suggestion/wshsuggest.so')),sanitized_external_module_sha256=sha(Path('/var/tmp/wsh-native-suggestion/sanitized/wshsuggest.so')),host=subprocess.check_output(['uname','-a'],text=True).strip(),commands=[
'CPPFLAGS=-I/var/tmp/wsh-native-sdk/usr/include LDFLAGS=-L/var/tmp/wsh-native-sdk/usr/lib64 LIBS=-ljansson WSH_KEEP_FAILED_BUILD=1 WSH_ZSH_SOURCE_LOCK=/var/tmp/wsh-native-qualification/linked-source.json WSH_ZSH_OUTPUT_ROOT=/var/tmp/wsh-native-qualified-linked ./build/build-zsh.zsh',
'CPPFLAGS=-I/var/tmp/wsh-native-sdk/usr/include LDFLAGS=-L/var/tmp/wsh-native-sdk/usr/lib64 LIBS=-ljansson WSH_ZSH_SOURCE_LOCK=/var/tmp/wsh-native-qualification/linked-source.json WSH_ZSH_ROOT=/var/tmp/wsh-native-qualified-linked/zsh-cad0d67c-native-linked ./build/build-development-bundle.zsh',
f'python3 native/test-linked-modules.py /code/wsh/bundles/2f16088a07e00940ddf6d0ce7826513b5b872747c73efc82fad1f023bd2f39a4 /var/tmp/wsh-native-suggestion /code/wsh/bundles/d129be9f8b50f52fa9a0591ded5e1d1d64b85a22ed58e8434a5aa45877fcb5a9/bin/wsh {p}/module-lifetime',
f'ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 python3 native/test-linked-modules.py {p}/linked-sanitized-installation /var/tmp/wsh-native-suggestion/sanitized /code/wsh/bundles/d129be9f8b50f52fa9a0591ded5e1d1d64b85a22ed58e8434a5aa45877fcb5a9/bin/wsh {p}/module-lifetime-sanitized',
f'python3 native/check-installation.py {candidate} {p}/linked-c-contracts',
f'python3 native/measure-startup.py {base} {candidate} {p}/linked-timing',
f'python3 native/measure-linked-memory.py {base} {candidate} {p}/linked-memory'])
(out/'modules-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(out/'modules-SHA256SUMS').write_text(''.join(sha(out/n)+'  '+str((out/n).relative_to(r))+'\n' for n in ['modules-report.md','modules-metadata.json','modules-inputs.tar.gz','modules-results.tar.gz']))
