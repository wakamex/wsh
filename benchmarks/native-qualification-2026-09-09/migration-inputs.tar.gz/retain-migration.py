from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-qualification');o=r/'benchmarks/native-qualification-2026-09-09'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
names=['native/test-migration.py','NATIVE-MIGRATION.md']
for name in ['mux/src/session_persistence.rs','docs/agent-lifecycle.md']:
 raw=subprocess.check_output(['git','show','e33307f0b:'+name],cwd='/code/wakterm');dest=p/('wakterm-'+Path(name).name);dest.write_bytes(raw)
with tarfile.open(o/'migration-inputs.tar.gz','w:gz') as a:
 for n in names:a.add(r/n,arcname=n)
 a.add(__file__,arcname='retain-migration.py')
 for n in ['wakterm-native-restore.patch','wakterm-session_persistence.rs','wakterm-agent-lifecycle.md']:a.add(p/n,arcname=n)
with tarfile.open(o/'migration-results.tar.gz','w:gz') as a:
 for n in ['migration.log','migration/results.json','wakterm-caller-tests-final.log']:a.add(p/n,arcname=n)
meta={'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'+dirty','source_inputs':{n:sha(r/n) for n in names},'wakterm_commit':subprocess.check_output(['git','rev-parse','e33307f0b'],cwd='/code/wakterm',text=True).strip(),'commands':['python3 native/test-migration.py bundles/4bfc1bd9af7cf33c315f62a65db66eceb64a9ffba4585144b7ee2732106f0986 target/release/wsh /var/tmp/wsh-native-qualification/migration','cd /code/wakterm && cargo test --locked -p mux restored_harness_']}
(o/'migration-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(o/'migration-SHA256SUMS').write_text(''.join(sha(o/n)+'  '+str((o/n).relative_to(r))+'\n' for n in ['migration-report.md','migration-metadata.json','migration-inputs.tar.gz','migration-results.tar.gz']))
