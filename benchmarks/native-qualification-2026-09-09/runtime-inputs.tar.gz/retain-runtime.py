from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-qualification');o=r/'benchmarks/native-qualification-2026-09-09';b=r/'bundles/4bfc1bd9af7cf33c315f62a65db66eceb64a9ffba4585144b7ee2732106f0986'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
names=['build/build-development-bundle.zsh','native/build-runtime.zsh','native/build-theme-prototype.zsh','native/check-installation.py','native/test-runtime-protocol.py','native/test-runtime-lifecycle.py','VENDORED-COMPONENTS.md']+[str(f.relative_to(r)) for f in (r/'native').glob('*.c')]+['benchmarks/native-qualification-2026-09-09/runtime-plan.md']
with tarfile.open(o/'runtime-inputs.tar.gz','w:gz') as a:
 for n in names:a.add(r/n,arcname=n)
 a.add(__file__,arcname='retain-runtime.py')
with tarfile.open(o/'runtime-results.tar.gz','w:gz') as a:
 for n in ['selected-native-build.log','helper-build-a.log','helper-build-b.log','selected-protocol.log','selected-lifecycle.log','selected-contracts.log']:a.add(p/n,arcname=n)
 for n in ['selected-protocol','selected-lifecycle','selected-contracts']:
  for f in (p/n).iterdir():
   if f.is_file():a.add(f,arcname=str(f.relative_to(p)))
 a.add(b/'manifest.json',arcname='manifest.json')
meta=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'+dirty',source_inputs={n:sha(r/n) for n in names},helper_sha256={k:sha(f) for k,f in [('build-a',p/'helper-build-a/wsh-runtime'),('build-b',p/'helper-build-b/wsh-runtime'),('installed',b/'bin/wsh-runtime')]},manifest_sha256=sha(b/'manifest.json'),commands=['./native/build-runtime.zsh /var/tmp/wsh-native-qualification/helper-build-a','./native/build-runtime.zsh /var/tmp/wsh-native-qualification/helper-build-b','CPPFLAGS=-I/var/tmp/wsh-native-sdk/usr/include LDFLAGS=-L/var/tmp/wsh-native-sdk/usr/lib64 WSH_KEEP_FAILED_BUILD=1 WSH_ZSH_OUTPUT_ROOT=/var/tmp/wsh-native-selected ./build/build-native-installation.zsh','python3 native/test-runtime-protocol.py target/release/wsh-runtime /var/tmp/wsh-native-qualification/helper-build-a/wsh-runtime /var/tmp/wsh-native-qualification/selected-protocol','python3 native/test-runtime-lifecycle.py /var/tmp/wsh-native-qualification/helper-build-a/wsh-runtime /var/tmp/wsh-native-qualification/selected-lifecycle',f'python3 native/check-installation.py {b} /var/tmp/wsh-native-qualification/selected-contracts'])
(o/'runtime-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(o/'runtime-SHA256SUMS').write_text(''.join(sha(o/n)+'  '+str((o/n).relative_to(r))+'\n' for n in ['runtime-report.md','runtime-metadata.json','runtime-inputs.tar.gz','runtime-results.tar.gz']))
