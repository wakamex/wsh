from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-qualification');out=r/'benchmarks/native-qualification-2026-09-09'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
names=['native/startup.c','native/test-resource-paths.py','native/test-startup.py','native/check-installation.py','native/measure-startup.py','native/prepare-build.py','native/prepare-runtime-comparison.py','build/update-native-lock.py','build/build-native-installation.zsh','build/build-zsh.zsh','build/build-development-bundle.zsh','build/zsh-sources/zsh-cad0d67c-native.json','benchmarks/native-qualification-2026-09-09/plan.md']
names+= [x['path'] for x in json.loads((r/'build/zsh-sources/zsh-cad0d67c-native.json').read_text())['native']['sources'] if x['path'] not in names]
with tarfile.open(out/'paths-inputs.tar.gz','w:gz') as a:
 for n in names:a.add(r/n,arcname=n)
 a.add(__file__,arcname='retain-paths.py')
with tarfile.open(out/'paths-results.tar.gz','w:gz') as a:
 for f in p.iterdir():
  if f.is_file() and (f.name.startswith(('paths-','startup','contracts','c-contracts','path-installations','sanitized-native','sanitized-clean'))):a.add(f,arcname=f.name)
 for directory in ['paths-check','paths-sanitized-check','startup','startup-sanitized','contracts','c-contracts','paths-timing']:
  for f in (p/directory).iterdir():
   if f.is_file():a.add(f,arcname=str(f.relative_to(p)))
base=Path('/var/tmp/wsh-native-render/runtime-installations-final/ba2599f9f670b8ced903bb91d98b23db04a2ca8ef0ca0d7c353a575202006ab2');candidate=p/'path-installations/2c45e74d390fee2d8f131f14e99cc174951bf24080203ef2227d838656ff8cf8'
meta=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'+dirty',source_inputs={n:sha(r/n) for n in names},variants={k:dict(manifest_sha256=sha(b/'manifest.json'),zsh_sha256=sha(b/'bin/wsh'),runtime_sha256=sha(b/'bin/wsh-runtime')) for k,b in [('control',base),('candidate',candidate)]},sanitized_binary_sha256=sha(p/'sanitized-installation/bin/wsh'),host=subprocess.check_output(['uname','-a'],text=True).strip(),commands=[
'CPPFLAGS=-I/var/tmp/wsh-native-sdk/usr/include LDFLAGS=-L/var/tmp/wsh-native-sdk/usr/lib64 WSH_ZSH_OUTPUT_ROOT=/var/tmp/wsh-native-qualified-paths-final ./build/build-native-installation.zsh',
f'python3 native/test-resource-paths.py /code/wsh/bundles/d129be9f8b50f52fa9a0591ded5e1d1d64b85a22ed58e8434a5aa45877fcb5a9 /var/tmp/wsh-native-qualified-paths-final/zsh-cad0d67c-native {p}/paths-check',
f'python3 native/test-startup.py /code/wsh/bundles/d129be9f8b50f52fa9a0591ded5e1d1d64b85a22ed58e8434a5aa45877fcb5a9 {p}/startup',
f'python3 native/check-installation.py {candidate} {p}/c-contracts',
f'python3 native/measure-startup.py {base} {candidate} {p}/paths-timing',
"make -C /var/tmp/wsh-native-tools/source-sanitized -j 8 CC=clang DLLD=clang CFLAGS='-O1 -g -fsanitize=address,undefined -fno-sanitize=function -fno-omit-frame-pointer' CPPFLAGS=-I/var/tmp/wsh-native-sdk/usr/include LDFLAGS='-fsanitize=address,undefined -L/var/tmp/wsh-native-sdk/usr/lib64' LIBS='-lpcre2-8 -lcap -ldl -lncursesw -lrt -lm -lc -ljansson'",
f'ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 python3 native/test-startup.py {p}/sanitized-installation {p}/startup-sanitized'])
(out/'paths-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(out/'paths-SHA256SUMS').write_text(''.join(sha(out/n)+'  '+str((out/n).relative_to(r))+'\n' for n in ['paths-report.md','paths-metadata.json','paths-inputs.tar.gz','paths-results.tar.gz']))
