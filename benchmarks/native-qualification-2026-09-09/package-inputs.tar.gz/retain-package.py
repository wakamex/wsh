from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-qualification');v=Path('/var/tmp/wsh-native-vm');o=r/'benchmarks/native-qualification-2026-09-09'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
names=['packaging/build-rpm.py','packaging/wsh-native.spec','packaging/vm.py','packaging/test-login.py','packaging/test-vm-recovery.py','packaging/test-transactions-guest.py','packaging/test-chsh-guest.py','benchmarks/native-qualification-2026-09-09/package-plan.md']
with tarfile.open(o/'package-inputs.tar.gz','w:gz') as a:
 for n in names:a.add(r/n,arcname=n)
 a.add(__file__,arcname='retain-package.py')
 for f in v.glob('final-*.sh'):a.add(f,arcname='vm/'+f.name)
 a.add(v/'reproduce-commands.txt',arcname='vm/reproduce-commands.txt')
with tarfile.open(o/'package-results.tar.gz','w:gz') as a:
 for n in ['rpm-a.log','rpm-b.log','rpm-variants.log','rpm-queries.json','package-results.json']:a.add(p/n,arcname=n)
 a.add(next((p/'rpm-a/RPMS').rglob('*.rpm')),arcname='tested.rpm')
 for f in (p/'final-transactions-results').iterdir():
  if f.is_file():a.add(f,arcname='transactions/'+f.name)
 selected=set(v.glob('final-*.log'))|set(v.glob('final-*.json'))|set(v.glob('final-*.bin'))
 for prefix in ['state-corrupt','state-unreadable','state-incompatible','runtime-missing','runtime-unreadable','runtime-incompatible','integration-missing']:
  selected.update(v.glob(prefix+'*.log'));selected.add(v/(prefix+'.json'));selected.add(v/(prefix+'.bin'))
 selected.add(v/'recovery-results.json');selected.add(v/'image.json')
 for f in sorted(selected):a.add(f,arcname='vm/'+f.name)
meta={'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'+dirty','source_inputs':{n:sha(r/n) for n in names},'results':json.loads((p/'package-results.json').read_text()),'installation_manifest_sha256':'4bfc1bd9af7cf33c315f62a65db66eceb64a9ffba4585144b7ee2732106f0986','commands':['python3 packaging/build-rpm.py bundles/4bfc1bd9af7cf33c315f62a65db66eceb64a9ffba4585144b7ee2732106f0986 /var/tmp/wsh-native-qualification/rpm-a --epoch 1788931200','Repeat in rpm-b; compare source archive and RPM bytes. Repeat releases 0.2/none, 0.3/pre, 0.4/post, 0.5/pause for transaction variants.','python3 packaging/test-login.py final-native-pam shellempty --job-control','python3 packaging/test-vm-recovery.py','python3 packaging/test-login.py final-confined-pam shellsecond','python3 packaging/test-login.py final-fresh-empty-pam shellfinal','python3 packaging/test-login.py final-post-reboot-pam shellfinal','python3 packaging/test-login.py final-post-reboot-confined shellsecond','Guest setup/transaction/removal/reboot commands are retained as vm/final-*.sh.']}
(o/'package-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(o/'package-SHA256SUMS').write_text(''.join(sha(o/n)+'  '+str((o/n).relative_to(r))+'\n' for n in ['package-report.md','package-metadata.json','package-inputs.tar.gz','package-results.tar.gz']))
