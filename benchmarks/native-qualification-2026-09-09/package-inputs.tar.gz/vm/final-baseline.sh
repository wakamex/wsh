set -e
getenforce
rpm -q wsh-native-development
getent passwd shellempty shelltest shellsecond
cat /proc/sys/kernel/random/boot_id
