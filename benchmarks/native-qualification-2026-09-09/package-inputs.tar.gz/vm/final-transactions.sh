set -e
python3 /var/tmp/test-chsh-guest.py
rm -f /run/wsh-rpm-post-paused
python3 /var/tmp/test-transactions-guest.py
rpm -V wsh-native-development
