set -e
rpm -Uvh --oldpackage --replacepkgs /var/tmp/wsh-native-development-0.3.1-0.1.fc44.x86_64.rpm
restorecon -R /usr/libexec/wsh /usr/bin/wsh
rpm -V wsh-native-development
sha256sum /usr/libexec/wsh/bin/wsh /usr/libexec/wsh/bin/wsh-runtime
/usr/bin/wsh --wsh-version
rm -f /run/wsh-rpm-post-paused
