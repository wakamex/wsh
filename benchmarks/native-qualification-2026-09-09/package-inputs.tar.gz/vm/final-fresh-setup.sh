set -e
useradd -m -k /var/empty -s /usr/bin/wsh shellfinal
printf 'shellfinal:wsh-regression\n' | chpasswd
restorecon -R /home/shellfinal
getenforce
ls -ldZ /home/shellfinal /usr/bin/wsh /usr/libexec/wsh/bin/wsh
