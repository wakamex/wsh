set -e
runuser -u shellfinal -- env HOME=/nonexistent/wsh-home XDG_DATA_HOME=/nonexistent/wsh-data WSH_STATE_ROOT=/nonexistent/wsh-state /usr/bin/wsh -lc 'print -r -- LOGIN_BOUNDARY:$ZSH_VERSION; exit 23' && exit 1 || test "$?" = 23
if rpm -e wsh-native-development; then exit 1; fi
test -x /usr/bin/wsh
for account in shelltest shellsecond shellempty shellfinal; do chsh -s /bin/bash "$account"; done
rpm -e wsh-native-development
! test -e /usr/bin/wsh
! grep -qxF /usr/bin/wsh /etc/shells
runuser -u shellfinal -- /bin/bash -lc 'printf "RECOVERY_OK\n"'
rpm -Uvh /var/tmp/wsh-native-development-0.3.1-0.2.fc44.x86_64.rpm
restorecon -R /usr/libexec/wsh /usr/bin/wsh
for account in shelltest shellsecond shellempty shellfinal; do chsh -s /usr/bin/wsh "$account"; done
rpm -V wsh-native-development
cat /proc/sys/kernel/random/boot_id
systemctl reboot
