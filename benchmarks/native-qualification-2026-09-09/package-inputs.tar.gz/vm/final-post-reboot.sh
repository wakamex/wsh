set -e
cat /proc/sys/kernel/random/boot_id
getenforce
rpm -V wsh-native-development
id -Z
