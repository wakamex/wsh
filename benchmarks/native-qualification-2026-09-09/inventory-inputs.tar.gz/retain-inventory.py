from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-qualification');o=r/'benchmarks/native-qualification-2026-09-09'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
data=json.loads((p/'responsibility-inventory.json').read_text());names=set()
for group,record in data.items():
 for row in record.get('files',[]) if isinstance(record.get('files'),list) else []:
  f=r/row['path'];assert sha(f)==row['sha256'],row['path'];names.add(row['path'])
with tarfile.open(o/'inventory-inputs.tar.gz','w:gz') as a:
 for n in sorted(names):a.add(r/n,arcname=n)
 a.add(__file__,arcname='retain-inventory.py')
 a.add(r/'bundles/4bfc1bd9af7cf33c315f62a65db66eceb64a9ffba4585144b7ee2732106f0986/manifest.json',arcname='payload-manifest.json')
(o/'responsibility-inventory.json').write_text(json.dumps(data,indent=2)+'\n')
(o/'inventory-SHA256SUMS').write_text(''.join(sha(o/n)+'  '+str((o/n).relative_to(r))+'\n' for n in ['inventory-report.md','responsibility-inventory.json','inventory-inputs.tar.gz']))
