from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-completion');out=r/'benchmarks/native-completion-scan-2026-09-09';b=Path('/var/tmp/wsh-native-render/runtime-installations-final/ba2599f9f670b8ced903bb91d98b23db04a2ca8ef0ca0d7c353a575202006ab2')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
names=['native/'+n for n in ['measure-compinit.py','prepare-completion-prototype.py','test-completion-dump.py','test-completion-headers.py','test-completion-seed.py']]+['benchmarks/deferred-completion-2026-09-06/run.py','benchmarks/native-completion-scan-2026-09-09/plan.md']
with tarfile.open(out/'inputs.tar.gz','w:gz') as a:
 for n in names:a.add(r/n,arcname=n)
 for name in ['compinit','compaudit','compdump']:
  a.add(next((b/'share/zsh').glob('*/functions/'+name)),arcname='upstream/'+name)
 a.add('/var/tmp/wsh-native-tools/source-sanitized/Src/builtin.c',arcname='upstream/builtin.c')
 a.add(__file__,arcname='retain.py')
with tarfile.open(out/'results.tar.gz','w:gz') as a:
 for f in sorted(p.iterdir()):
  if f.is_file() and f.suffix in ['.log','.txt']:a.add(f,arcname=f.name)
 for name in ['spans','prototype','prototype-bulk','prototype-bulk-2','dump-correctness','dump-bulk','header-parity','header-parity-2','module-fallback','zle','zle-final','zle-bulk']:
  for f in sorted((p/name).rglob('*')):
   if f.is_file() and not f.is_symlink() and '.git' not in f.parts:a.add(f,arcname=str(f.relative_to(p)))
 a.add(b/'manifest.json',arcname='native-manifest.json')
meta=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'+dirty',source_inputs={n:sha(r/n) for n in names},bundle_path=str(b),bundle_sha256=sha(b/'manifest.json'),zsh_sha256=sha(b/'bin/wsh'),runtime_sha256=sha(b/'bin/wsh-runtime'),host=subprocess.check_output(['uname','-a'],text=True).strip(),cpu=0,commands=[
'python3 native/measure-compinit.py '+str(b)+' /var/tmp/wsh-native-completion/spans',
'python3 native/prepare-completion-prototype.py '+str(b)+' /var/tmp/wsh-native-completion/prototype',
'python3 native/test-completion-dump.py '+str(b)+' /var/tmp/wsh-native-completion/prototype /var/tmp/wsh-native-completion/dump-correctness',
'python3 native/test-completion-seed.py '+str(b)+' /var/tmp/wsh-native-completion/prototype /var/tmp/wsh-native-completion/zle-final correctness',
'python3 native/test-completion-seed.py '+str(b)+' /var/tmp/wsh-native-completion/prototype /var/tmp/wsh-native-completion/zle-final measure',
'python3 native/prepare-completion-prototype.py '+str(b)+' /var/tmp/wsh-native-completion/prototype-bulk-2 --bulk',
'python3 native/test-completion-headers.py '+str(b)+' /var/tmp/wsh-native-completion/prototype-bulk-2 /var/tmp/wsh-native-completion/header-parity-2',
'python3 native/test-completion-dump.py '+str(b)+' /var/tmp/wsh-native-completion/prototype-bulk-2 /var/tmp/wsh-native-completion/dump-bulk',
'python3 native/test-completion-seed.py '+str(b)+' /var/tmp/wsh-native-completion/prototype-bulk-2 /var/tmp/wsh-native-completion/zle-bulk correctness',
'python3 native/test-completion-seed.py '+str(b)+' /var/tmp/wsh-native-completion/prototype-bulk-2 /var/tmp/wsh-native-completion/zle-bulk measure'])
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(out/'SHA256SUMS').write_text(''.join(sha(out/n)+'  '+str((out/n).relative_to(r))+'\n' for n in ['report.md','metadata.json','inputs.tar.gz','results.tar.gz']))
