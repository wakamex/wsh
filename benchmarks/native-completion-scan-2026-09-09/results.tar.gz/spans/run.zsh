zmodload zsh/datetime
unalias -m '*' 2>/dev/null
if [[ $1 == timed ]]; then
  functions[compinit]="$(< $2)"
else
  autoload -Uz +X compinit
fi
start=$EPOCHREALTIME
compinit -i -d "$HOME/dump" || exit 2
end=$EPOCHREALTIME
print -r -- "$start $end ${_WSH_CI_audit_start:-0} ${_WSH_CI_audit_end:-0} ${_WSH_CI_scan_start:-0} ${_WSH_CI_scan_end:-0} ${_WSH_CI_dump_start:-0} ${_WSH_CI_dump_end:-0}"
print -r -- "${(j:|:)fpath}" > "$HOME/fpath"
typeset -p _comps _services _patcomps _postpatcomps _compautos > "$HOME/mappings"
