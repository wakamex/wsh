zmodload zsh/system
setopt extendedglob
typeset _i_bulk=yes _i_file _i_fd _i_header
typeset -a _i_line
for _i_file in "$1"/*(N); do
  if [[ $2 == candidate ]]; then
      if [[ $_i_bulk == yes ]] && { exec {_i_fd}< $_i_file } 2>/dev/null; then
        _i_header=''
        builtin sysread -i $_i_fd -s 4096 _i_header 2>/dev/null
        exec {_i_fd}<&-
        if [[ $_i_header == *$'\n'* ]]; then
          _i_header=${_i_header%%$'\n'*}
          _i_line=( ${(s: :)${_i_header//$'\t'/ }} )
        else
          IFS=$' \t' read -rA _i_line < $_i_file
        fi
      else
        IFS=$' \t' read -rA _i_line < $_i_file
      fi

  else
    IFS=$' \t' read -rA _i_line < $_i_file
  fi
  print -r -- "${_i_file:t}:${#_i_line}:${(j:|:)${(qqqq)_i_line}}"
done
