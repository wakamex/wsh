
PROMPT='HIGHLIGHT> '
ZSH_HIGHLIGHT_HIGHLIGHTERS=(main brackets)
source $WSH_TEST_SOURCE
for ((i=0;i<100;i++)); do functions[wsh_probe_$i]=':'; done
_clear() { BUFFER='' POSTDISPLAY='' CURSOR=0; }
zle -N _clear
bindkey '^G' _clear
_report_redraw() { print -nr -- $'\x1eRD:'"$BUFFER"$'\x1c'"${(j:;:)region_highlight}"$'\x1f'; }
autoload -Uz add-zle-hook-widget
_install_redraw() {
 add-zle-hook-widget line-pre-redraw _zsh_highlight__zle-line-pre-redraw
 add-zle-hook-widget line-finish _zsh_highlight__zle-line-finish
 add-zle-hook-widget line-pre-redraw _report_redraw
 add-zsh-hook -d precmd _install_redraw
}
autoload -Uz add-zsh-hook
add-zsh-hook precmd _install_redraw
