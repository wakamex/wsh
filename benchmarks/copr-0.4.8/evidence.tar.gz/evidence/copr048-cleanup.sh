set -euxo pipefail
tar -czf /var/tmp/wsh-copr048-test-evidence.tar.gz -C /var/tmp wsh-copr-048-history wsh-copr-048-mail wsh-copr-doctor-048 wsh-copr-048-defaults wsh-copr-048-directory wsh-copr-048-typeahead wsh-copr-048-symlink wsh-package-results/chsh.bin
chmod 0644 /var/tmp/wsh-copr048-test-evidence.tar.gz
cp /usr/share/wsh/manifest.json /var/tmp/wsh-copr048-manifest.json
chmod 0644 /var/tmp/wsh-copr048-manifest.json
test "$(getent passwd shellempty | cut -d: -f7)" = /usr/bin/wsh
dnf -y remove wsh
! test -e /usr/bin/wsh
! test -e /usr/libexec/wsh/wsh-runtime
! grep -Fx /usr/bin/wsh /etc/shells
! grep -Fx /bin/wsh /etc/shells
test "$(getent passwd shellempty | cut -d: -f7)" = /usr/bin/wsh
usermod -s /bin/bash shellempty
su -l shellempty -c 'echo RECOVERY_LOGIN_OK'
getenforce
