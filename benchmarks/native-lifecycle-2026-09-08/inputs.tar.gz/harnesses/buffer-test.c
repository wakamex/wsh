#define _GNU_SOURCE
#define WSH_VERSION "0.3.1"
#define WSH_SOURCE_REVISION "3f8b50d"
#define WSH_INPUTS_SHA256 "0000000000000000000000000000000000000000000000000000000000000000"
#define ZSH_VERSION "5.9.999.3-test"
#define WSH_ZSH_SOURCE_REVISION "cad0d67c"
#define WSH_TARGET "x86_64-linux-gnu"
#include "/code/wsh/native/profile.c"
#include <assert.h>
#include <sys/wait.h>
static int wsh_profile_report(const char *directory) { (void)directory; return 0; }
int main(int argc, char **argv) {
    struct stat st;
    char path[PATH_MAX];
    size_t i;
    pid_t child;
    assert(wsh_profile_start(argc, argv) == -1);
    assert(snprintf(path, sizeof(path), "%s/trace.jsonl", wsh_profile_directory) < (int)sizeof(path));
    assert(!stat(path, &st));
    off_t initial = st.st_size;
    for (i = 0; i < 10000; ++i) wsh_profile("native-startup-enter");
    assert(wsh_profile_startup_count == 32);
    child = fork(); assert(child >= 0);
    if (!child) { wsh_profile_flush_startup(); exit(0); }
    assert(waitpid(child, NULL, 0) == child);
    assert(!stat(path, &st) && st.st_size == initial);
    assert(!unlink(path) && !mkfifo(path, 0600));
    wsh_profile_flush_startup(); assert(wsh_profile_startup_count == 32);
    assert(!unlink(path));
    assert(symlink("/dev/null", path) == 0);
    wsh_profile_flush_startup(); assert(wsh_profile_startup_count == 32);
    assert(!unlink(path));
    int fd = open(path, O_WRONLY | O_CREAT | O_EXCL, 0600); assert(fd >= 0); close(fd);
    assert(!chmod(path, 0644));
    wsh_profile_flush_startup(); assert(wsh_profile_startup_count == 32);
    assert(!chmod(path, 0600));
    wsh_profile_flush_startup(); assert(wsh_profile_startup_count == 0);
    assert(!stat(path, &st) && st.st_size > 0 && st.st_size < 8192);
    puts("PASS: bounded 10000-event capture, child isolation, FIFO, symlink, public mode and private flush");
    return 0;
}
