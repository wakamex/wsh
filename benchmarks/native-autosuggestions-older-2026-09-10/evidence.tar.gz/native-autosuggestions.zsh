# Fish-like fast/unobtrusive autosuggestions for zsh.
# https://github.com/zsh-users/zsh-autosuggestions
# v0.7.1
# Copyright (c) 2013 Thiago de Arruda
# Copyright (c) 2016-2021 Eric Freese
# 
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation
# files (the "Software"), to deal in the Software without
# restriction, including without limitation the rights to use,
# copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following
# conditions:
# 
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.

#--------------------------------------------------------------------#
# Global Configuration Variables                                     #
#--------------------------------------------------------------------#

# Color to use when highlighting suggestion
# Uses format of `region_highlight`
# More info: http://zsh.sourceforge.net/Doc/Release/Zsh-Line-Editor.html#Zle-Widgets
(( ! ${+ZSH_AUTOSUGGEST_HIGHLIGHT_STYLE} )) &&
typeset -g ZSH_AUTOSUGGEST_HIGHLIGHT_STYLE='fg=8'

# Prefix to use when saving original versions of bound widgets
(( ! ${+ZSH_AUTOSUGGEST_ORIGINAL_WIDGET_PREFIX} )) &&
typeset -g ZSH_AUTOSUGGEST_ORIGINAL_WIDGET_PREFIX=autosuggest-orig-

# Strategies to use to fetch a suggestion
# Will try each strategy in order until a suggestion is returned
(( ! ${+ZSH_AUTOSUGGEST_STRATEGY} )) && {
	typeset -ga ZSH_AUTOSUGGEST_STRATEGY
	ZSH_AUTOSUGGEST_STRATEGY=(history)
}

# Widgets that clear the suggestion
(( ! ${+ZSH_AUTOSUGGEST_CLEAR_WIDGETS} )) && {
	typeset -ga ZSH_AUTOSUGGEST_CLEAR_WIDGETS
	ZSH_AUTOSUGGEST_CLEAR_WIDGETS=(
		history-search-forward
		history-search-backward
		history-beginning-search-forward
		history-beginning-search-backward
		history-beginning-search-forward-end
		history-beginning-search-backward-end
		history-substring-search-up
		history-substring-search-down
		up-line-or-beginning-search
		down-line-or-beginning-search
		up-line-or-history
		down-line-or-history
		accept-line
		copy-earlier-word
	)
}

# Widgets that accept the entire suggestion
(( ! ${+ZSH_AUTOSUGGEST_ACCEPT_WIDGETS} )) && {
	typeset -ga ZSH_AUTOSUGGEST_ACCEPT_WIDGETS
	ZSH_AUTOSUGGEST_ACCEPT_WIDGETS=(
		forward-char
		end-of-line
		vi-forward-char
		vi-end-of-line
		vi-add-eol
	)
}

# Widgets that accept the entire suggestion and execute it
(( ! ${+ZSH_AUTOSUGGEST_EXECUTE_WIDGETS} )) && {
	typeset -ga ZSH_AUTOSUGGEST_EXECUTE_WIDGETS
	ZSH_AUTOSUGGEST_EXECUTE_WIDGETS=(
	)
}

# Widgets that accept the suggestion as far as the cursor moves
(( ! ${+ZSH_AUTOSUGGEST_PARTIAL_ACCEPT_WIDGETS} )) && {
	typeset -ga ZSH_AUTOSUGGEST_PARTIAL_ACCEPT_WIDGETS
	ZSH_AUTOSUGGEST_PARTIAL_ACCEPT_WIDGETS=(
		forward-word
		emacs-forward-word
		vi-forward-word
		vi-forward-word-end
		vi-forward-blank-word
		vi-forward-blank-word-end
		vi-find-next-char
		vi-find-next-char-skip
	)
}

# Widgets that should be ignored (globbing supported but must be escaped)
(( ! ${+ZSH_AUTOSUGGEST_IGNORE_WIDGETS} )) && {
	typeset -ga ZSH_AUTOSUGGEST_IGNORE_WIDGETS
	ZSH_AUTOSUGGEST_IGNORE_WIDGETS=(
		orig-\*
		beep
		run-help
		set-local-history
		which-command
		yank
		yank-pop
		zle-\*
	)
}

# Pty name for capturing completions for completion suggestion strategy
(( ! ${+ZSH_AUTOSUGGEST_COMPLETIONS_PTY_NAME} )) &&
typeset -g ZSH_AUTOSUGGEST_COMPLETIONS_PTY_NAME=zsh_autosuggest_completion_pty


_zsh_autosuggest_capture_postcompletion() { builtin wsh-autosuggest-service postcompletion; }
_zsh_autosuggest_capture_completion_widget() {
  local -a +h comppostfuncs=(_zsh_autosuggest_capture_postcompletion)
  builtin wsh-autosuggest-service capture
}
zle -N autosuggest-capture-completion _zsh_autosuggest_capture_completion_widget
_zsh_autosuggest_capture_completion_sync() {
  builtin wsh-autosuggest-service completion-setup
  zle autosuggest-capture-completion
}
_zsh_autosuggest_capture_completion_async() {
  builtin wsh-autosuggest-service completion-setup
  autoload +X _complete
  functions[_original_complete]=$functions[_complete]
  _complete() { unset 'compstate[vared]'; _original_complete "$@"; }
  vared 1
}

_zsh_autosuggest_invoke_original_widget() {
	# Do nothing unless called with at least one arg
	(( $# )) || return 0

	local original_widget_name="$1"

	shift

	if (( ${+widgets[$original_widget_name]} )); then
		zle $original_widget_name -- $@
	fi
}
_zsh_autosuggest_strategy_completion() {
  emulate -L zsh
  setopt extendedglob
  local line REPLY
  builtin wsh-autosuggest-service completion "$1"
}
_zsh_autosuggest_bind_widgets() { builtin wsh-autosuggest-service bind; }
_zsh_autosuggest_fetch() { builtin wsh-autosuggest-service fetch; }
_zsh_autosuggest_async_response() { builtin wsh-autosuggest-service response "$@"; }
_zsh_autosuggest_strategy_history() { builtin wsh-history-suggest "$1"; }
_zsh_autosuggest_widget_clear() { builtin wsh-autosuggest-service widget clear "$@"; }
zle -N autosuggest-clear _zsh_autosuggest_widget_clear
_zsh_autosuggest_widget_fetch() { builtin wsh-autosuggest-service widget fetch "$@"; }
zle -N autosuggest-fetch _zsh_autosuggest_widget_fetch
_zsh_autosuggest_widget_suggest() { builtin wsh-autosuggest-service widget suggest "$@"; }
zle -N autosuggest-suggest _zsh_autosuggest_widget_suggest
_zsh_autosuggest_widget_accept() { builtin wsh-autosuggest-service widget accept "$@"; }
zle -N autosuggest-accept _zsh_autosuggest_widget_accept
_zsh_autosuggest_widget_execute() { builtin wsh-autosuggest-service widget execute "$@"; }
zle -N autosuggest-execute _zsh_autosuggest_widget_execute
_zsh_autosuggest_widget_enable() { builtin wsh-autosuggest-service widget enable "$@"; }
zle -N autosuggest-enable _zsh_autosuggest_widget_enable
_zsh_autosuggest_widget_disable() { builtin wsh-autosuggest-service widget disable "$@"; }
zle -N autosuggest-disable _zsh_autosuggest_widget_disable
_zsh_autosuggest_widget_toggle() { builtin wsh-autosuggest-service widget toggle "$@"; }
zle -N autosuggest-toggle _zsh_autosuggest_widget_toggle
_zsh_autosuggest_widget_modify() { builtin wsh-autosuggest-service widget modify "$@"; }
_zsh_autosuggest_widget_partial_accept() { builtin wsh-autosuggest-service widget partial_accept "$@"; }
_zsh_autosuggest_start() {
  (( ${+ZSH_AUTOSUGGEST_MANUAL_REBIND} )) && add-zsh-hook -d precmd _zsh_autosuggest_start
  builtin wsh-autosuggest-service bind
}
typeset -g ZSH_AUTOSUGGEST_USE_ASYNC=
autoload -Uz add-zsh-hook
add-zsh-hook precmd _zsh_autosuggest_start
_wsh_autosuggest_complete_finish() { builtin wsh-autosuggest-service cancel; }
autoload -Uz add-zle-hook-widget
add-zle-hook-widget line-finish _wsh_autosuggest_complete_finish
add-zsh-hook zshexit _wsh_autosuggest_complete_finish
add-zsh-hook precmd _wsh_autosuggest_complete_finish
