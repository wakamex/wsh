zshz() {
  setopt LOCAL_OPTIONS NO_KSH_ARRAYS NO_SH_WORD_SPLIT NO_EXTENDED_GLOB UNSET
  local REPLY result
  wsh-directory "$@"
  result=$?
  (( result == 64 )) && { _zshz_usage; return; }
  (( result )) && return $result
  if [[ -n $REPLY ]]; then
    if [[ -z $ZSHZ_CD ]]; then
      builtin cd "$REPLY" || return
    else
      ${=ZSHZ_CD} "$REPLY" || return
    fi
    if (( ZSHZ_ECHO )); then
      if (( ZSHZ_TILDE )); then
        print -r -- ${PWD/#${HOME}/\~}
      else
        print -r -- $PWD
      fi
    fi
  fi
  return 0
}

_zshz_precmd() {
  builtin wsh-directory --can-record || return 0
  # Protect against `setopt NO_UNSET'
  setopt LOCAL_OPTIONS UNSET

  # Do not add PWD to datafile when in HOME directory, or
  # if `z -x' has just been run
  [[ $PWD == "$HOME" ]] || (( ZSHZ[DIRECTORY_REMOVED] )) && return

  # Don't track directory trees excluded in ZSHZ_EXCLUDE_DIRS
  local exclude
  for exclude in ${(@)ZSHZ_EXCLUDE_DIRS:-${(@)_Z_EXCLUDE_DIRS}}; do
    case $PWD in
      ${exclude}|${exclude}/*) return ;;
    esac
  done

  # Add PWD to the datafile. Background the write so the prompt doesn't wait on
  # read + tempfile + rename + chown -- which is tens of ms per prompt on
  # 9P-bridged or VHD-backed paths. Backgrounding is safe under develop's
  # lock design: the `always { zsystem flock -u $lockfd }' block in
  # _zshz_add_or_remove_path guarantees the parent never holds an open
  # lockfd between precmd invocations (so a `&!' fork can't inherit one),
  # and ZSHZ_LOCK_TIMEOUT (default 1s) bounds contention so a stuck holder
  # can't pile up writers. `&!' is zsh background + disown: no wrapper
  # subshell, no job-table entry, no "Done" line at the next prompt.
  #
  # Do not restore the old foreground carve-out for Cygwin/MSYS2. It was
  # right when backgrounding meant a subshell plus a job (two forks) and
  # writes were line-by-line; with one disowned fork and batched writes,
  # measurement (June 2026, Cygwin zsh 5.8 and MSYS2 zsh 5.9) shows ~10-12ms
  # at the prompt for `&!' vs. ~30ms for a foreground add at 300 datafile
  # entries -- and ~300ms at 1,000 entries, since the foreground cost grows
  # with the datafile while the fork cost stays flat.
  #
  # `2> /dev/null' is what actually enforces the "stay quiet at every prompt"
  # rule that $_zshz_quiet_add describes. That marker can only gate Zsh-z's own
  # `print's; it cannot reach the external and builtin commands further down the
  # --add path -- `mkdir -p', `id -ng', ${ZSHZ[CHOWN]}, the deliberately loud
  # datafile-creation retry, or Zsh's own redirection diagnostics -- and any of
  # those can fail when $ZSHZ_DATA sits on an unwritable or unmounted directory,
  # or when $ZSHZ_OWNER names a user `id' can't resolve. Suppressing at the fork
  # covers every such site at once, including ones added later, whereas
  # suppressing site by site has to be kept in sync forever. Nothing actionable
  # is lost: a foreground `z --add .' still reports in full, which is exactly
  # the diagnostic the lock comment above tells the user to run.
  local _zshz_quiet_add=1
  zshz --add "$PWD" 2> /dev/null &!

  # See https://github.com/rupa/z/pull/247/commits/081406117ea42ccb8d159f7630cfc7658db054b6
  : $RANDOM
}

############################################################
# chpwd
#
# When the $PWD is removed from the datafile with `z -x',
# Zsh-z refrains from adding it again until the user has
# left the directory.
#
# Globals:
#   ZSHZ
############################################################
_zshz_chpwd() {
  ZSHZ[DIRECTORY_REMOVED]=0
  builtin wsh-directory --changed
}


zsh-z_plugin_unload() {
  builtin wsh-directory --changed
  emulate -L zsh

  add-zsh-hook -D precmd _zshz_precmd
  add-zsh-hook -d chpwd _zshz_chpwd

  zle -D _zshz_zle_completion_widget

  # Only restore Tab binding if it is still bound to our widget; otherwise
  # leave it alone.
  local _zshz_current_tab
  _zshz_current_tab="$(bindkey -M main '^I' 2>/dev/null || true)"
  if [[ ${_zshz_current_tab##* } == _zshz_zle_completion_widget ]]; then
    bindkey -M main '^I' "${ZSHZ[TAB_BINDING]:-expand-or-complete}"
  fi

  local x
  for x in ${=ZSHZ[FUNCTIONS]}; do
    (( ${+functions[$x]} )) && unfunction $x
  done

  # The directory captured at source time -- $0 here is the function name,
  # not the plugin file. Read it before ZSHZ is unset.
  #
  # Only when this plugin was the one that added it. A plugin manager that put
  # the directory on $fpath owns that entry: taking it away would break
  # autoloads for anything else living there and leave the manager believing
  # its configuration is intact. And drop a single occurrence rather than
  # filtering every match -- at most one of any duplicates can be ours.
  #
  # `(ie)', not `(i)': without the `e' the subscript treats the stored path as
  # a *pattern*, so a plugin directory containing `[', `*' or `?' would not
  # match itself and the entry would be left behind. The source-time lookup
  # already uses `(ie)'; these two must agree.
  local _zshz_dir
  integer _zshz_fp
  for _zshz_dir in ${(f)ZSHZ[ADDED_FPATH]-}; do
    [[ -n $_zshz_dir ]] || continue
    _zshz_fp=${fpath[(ie)$_zshz_dir]}
    (( _zshz_fp <= ${#fpath} )) && fpath[$_zshz_fp]=()
  done

  # Take back the completion mapping the widget installed on its first Tab.
  # Without this the entry outlives the function it names -- `_zshz' is
  # unfunctioned above and the plugin directory has just left $fpath, so a
  # later completion on that command looks up something unloadable.
  #
  # Only this one entry. compinit's own registrations (`_comps[zshz]', from the
  # static `#compdef' tag) are deliberately left in place: nothing re-runs
  # compinit when the plugin is sourced again, so removing them would break
  # completion for the literal `zshz' command until the user re-ran it by hand.
  # This entry has no such problem -- the widget re-registers it on the next
  # Tab after a reload.
  #
  # `$ZSHZ[COMPDEF]' is the ownership record: the registration above never
  # overwrites an existing mapping, so one Zsh-z did not create must survive
  # unload. Re-check the value too, in case it was repointed since.
  local _zshz_compdef
  for _zshz_compdef in ${=ZSHZ[COMPDEF]-}; do
    [[ ${_comps[$_zshz_compdef]-} == '_zshz' ]] &&
      compdef -d "$_zshz_compdef" 2> /dev/null
  done

  unset ZSHZ

  (( ${+aliases[${ZSHZ_CMD:-${_Z_CMD:-z}}]} )) &&
    unalias ${ZSHZ_CMD:-${_Z_CMD:-z}}

  unfunction $0
}

# vim: fdm=indent:ts=2:et:sts=2:sw=2:
