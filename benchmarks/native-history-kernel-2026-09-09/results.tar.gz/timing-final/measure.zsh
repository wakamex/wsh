module_path=($1 $module_path)
zmodload wshhistory || exit 2
zmodload zsh/datetime
source $2
zmodload zsh/parameter
fc -p
HISTSIZE=20000
unsetopt hist_ignore_all_dups hist_ignore_dups
repeat $3; do print -s -- 'echo duplicate'; done
print -s -- 'sentinel'
HISTORY_SUBSTRING_SEARCH_ENSURE_UNIQUE=1
typeset -a rows
typeset -a fixture=(${(Onk)history})
[[ $#fixture == $3 ]] || exit 4
for ((i=0;i<50;i++)); do
 owners=(control candidate)
 ((i%2)) && owners=(candidate control)
 for owner in $owners; do
  _history_substring_search_raw_matches=($fixture)
  _history_substring_search_raw_match_index=0
  _history_substring_search_matches=()
  _history_substring_search_unique_filter=()
  _history_substring_search_process_raw_matches
  start=$EPOCHREALTIME
  if [[ $owner == control ]]; then
   _history_substring_search_process_raw_matches
  else
   wsh-history-next
  fi
  result=$?
  elapsed=$(( (EPOCHREALTIME-start)*1000 ))
  [[ $result == 1 && $_history_substring_search_raw_match_index == $3 ]] || exit 3
  rows+=("$i $owner $elapsed")
 done
done
print -rl -- $rows
