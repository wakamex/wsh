module_path=($1 $module_path)
zmodload wshhistory || exit 2
source $2
zmodload zsh/parameter
fc -p
HISTSIZE=20000
unsetopt hist_ignore_all_dups hist_ignore_dups
for ((i=0;i<100;i++)); do
 print -s -- "echo project $((i%7))"
done
print -s -- $'echo multiline\nsecond line'
print -s -- 'echo $(false) [x] `false` ; quote'
(( $4 )) && setopt hist_ignore_all_dups
HISTORY_SUBSTRING_SEARCH_ENSURE_UNIQUE=$5
_history_substring_search_raw_matches=(${(Onk)history})
_history_substring_search_raw_match_index=0
_history_substring_search_matches=()
_history_substring_search_unique_filter=()
[[ $3 == candidate ]] && functions[_history_substring_search_process_raw_matches]='wsh-history-next'
for ((i=0;i<110;i++)); do
 _history_substring_search_process_raw_matches
 result=$?
 print -r -- "$result $_history_substring_search_raw_match_index ${(j:,:)_history_substring_search_matches}"
 # New history between calls must not change the already selected raw indices.
 ((i==3)) && print -s -- 'echo later history'
done
print -rl -- ${(ok)_history_substring_search_unique_filter}
