module_path=($1 $module_path)
zmodload wshdirectory || exit 90
source "$2"
cd "$HOME/project"
zshz -x "$PWD" || exit 1
if [[ $3 == reenter ]]; then
  cd "$HOME/other"
  cd "$HOME/project"
fi
_zshz_precmd
