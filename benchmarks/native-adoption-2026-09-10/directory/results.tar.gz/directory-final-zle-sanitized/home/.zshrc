PROMPT='DIRECTORY> '
module_path=($WSH_TEST_MODULE $module_path)
zmodload wshdirectory
autoload -Uz compinit
compinit -i -D
ZSHZ_DATA=$HOME/db
source $WSH_TEST_SOURCE
_capture() {
  print -nr -- $'\x1eBUFFER:'"$BUFFER"$'\x1f'
  BUFFER='' POSTDISPLAY='' CURSOR=0
  zle redisplay
}
zle -N _capture
bindkey '^G' _capture
