fpath=("$1" "$2"/share/zsh/*/functions)
TRAPDEBUG() {
  if [[ ${funcstack[2]} == _wsh_completion_autoload ]]; then
    _i_line=()
  fi
}
autoload -Uz compinit
compinit -i -D
