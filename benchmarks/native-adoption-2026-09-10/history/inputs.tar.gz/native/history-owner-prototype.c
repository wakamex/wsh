/* Private history owner. Zsh retains widget registration and highlighter hooks. */
#define _GNU_SOURCE 1
#define MODULE 1
#define IMPORTING_MODULE_zshQsmain 1
#include "zsh.mdh"

static struct {
    char *query, *result;
    char **parts;
    zlong *raw, *matches, index;
    size_t count, next, used;
    HashTable seen;
    int active;
} search;
static char *value(const char *name)
{
    char *s = getsparam((char *)name);
    return s ? s : "";
}
static void set_value(const char *name, const char *s)
{
    setsparam((char *)name, ztrdup(s));
}
static void reset(void)
{
    zsfree(search.query); zsfree(search.result);
    if (search.parts) freearray(search.parts);
    free(search.raw); free(search.matches);
    if (search.seen) deleteparamtable(search.seen);
    search.query = search.result = NULL; search.parts = NULL;
    search.raw = search.matches = NULL; search.seen = NULL;
    search.count = search.next = search.used = 0; search.index = 0;
}
static char *entry(zlong key)
{
    Histent h = gethistent(key, 0);
    return h && h->histnum == key ? h->node.nam : "";
}
static void begin(void)
{
    char *buffer = value("BUFFER");
    if (*buffer && search.result && !strcmp(buffer, search.result)) return;
    reset();
    search.query = ztrdup(buffer);
    char **parts;
    if (*value("HISTORY_SUBSTRING_SEARCH_FUZZY")) parts = spacesplit(buffer, 0, 1, 0);
    else { parts = zhalloc(2*sizeof(char *)); parts[0] = *buffer ? buffer : NULL; parts[1] = NULL; }
    search.parts = zarrdup(parts);
    size_t n = arrlen(parts);
    char **escaped = zhalloc((n+1)*sizeof(char *));
    for (size_t i=0; i<n; ++i) escaped[i] = quotestring(parts[i], QT_BACKSLASH_PATTERN);
    escaped[n] = NULL;
    char *pattern = zhtricat("(#", value("HISTORY_SUBSTRING_SEARCH_GLOBBING_FLAGS"), ")");
    pattern = dyncat(pattern, *value("HISTORY_SUBSTRING_SEARCH_PREFIXED") ? "" : "*");
    pattern = zhtricat(pattern, zjoin(escaped, '*', 1), "*");
    tokenize(pattern);
    Patprog compiled = patcompile(pattern, 0, NULL);
    LinkList keys = newlinklist();
    if (*buffer) for (Histent h=gethistent(addhistnum(curhist,-1,HIST_FOREIGN),GETHIST_UPWARD); h; h=up_histent(h)) {
        if (compiled && !pattry(compiled,h->node.nam)) continue;
        zlong *key = zhalloc(sizeof(*key)); *key = h->histnum;
        addlinknode(keys,key);
    }
    search.count = countlinknodes(keys);
    search.raw = zalloc((search.count+1)*sizeof(zlong));
    search.matches = zalloc((search.count+1)*sizeof(zlong));
    size_t i=0;
    for (LinkNode node=firstnode(keys); node; incnode(node)) search.raw[i++] = *(zlong *)getdata(node);
    search.seen = newparamtable(17,"history seen");
    search.index = !strcmp(value("WIDGET"),"history-substring-search-down") ? 1 : 0;
}
static int next(void)
{
    while (search.next < search.count) {
        zlong key = search.raw[search.next++];
        if (!isset(HISTIGNOREALLDUPS) && *value("HISTORY_SUBSTRING_SEARCH_ENSURE_UNIQUE")) {
            char *text = entry(key);
            if (search.seen->getnode(search.seen,text)) continue;
            queue_signals();
            HashTable saved=paramtab; paramtab=search.seen;
            Param p=createparam(text,PM_SCALAR|PM_HASHELEM); paramtab=saved;
            p->gsu.s->setfn(p,ztrdup("1"));
            unqueue_signals();
        }
        search.matches[search.used++]=key;
        return 1;
    }
    return 0;
}
static const char *navigate(int down)
{
    for (;;) {
        int found=0;
        if (down) {
            if (search.index >= 1) { found=search.index>1; --search.index; }
        } else if (search.index <= (zlong)search.used) {
            found=search.index<(zlong)search.used || next(); ++search.index;
        }
        set_value("BUFFER",found ? entry(search.matches[search.index-1]) : search.query);
        if (!found || isset(HISTIGNOREALLDUPS) || *value("HISTORY_SUBSTRING_SEARCH_ENSURE_UNIQUE") ||
            !isset(HISTFINDNODUPS) || !search.result || strcmp(value("BUFFER"),search.result))
            return found ? "HISTORY_SUBSTRING_SEARCH_HIGHLIGHT_FOUND" : "HISTORY_SUBSTRING_SEARCH_HIGHLIGHT_NOT_FOUND";
    }
}
static int count_lines(const char *text)
{
    int count=0, nonempty=0;
    for (; *text; ++text) {
        if (*text=='\n') { count+=nonempty; nonempty=0; }
        else nonempty=1;
    }
    return count+nonempty;
}
static void clear_highlight(void)
{
    char **old=getaparam("region_highlight");
    size_t count=old ? arrlen(old) : 0, used=0;
    char **updated=zalloc((count+1)*sizeof(char *));
    for (size_t i=0;i<count;++i)
        if (!strstr(old[i],"memo=history-substring-search")) updated[used++]=ztrdup(old[i]);
    updated[used]=NULL; setaparam("region_highlight",updated);
}
static void finish(int refresh, const char *style_name)
{
    zsfree(search.result); search.result=ztrdup(value("BUFFER"));
    char *style=dupstring(style_name ? value(style_name) : "");
    if (refresh) { clear_highlight(); setiparam("CURSOR",MB_METASTRLEN(value("BUFFER"))); }
    Shfunc fn=(Shfunc)shfunctab->getnode(shfunctab,"_zsh_highlight");
    if (fn) { LinkList args=newlinklist(); addlinknode(args,dupstring("_zsh_highlight")); doshfunc(fn,args,0); }
    if (*style) {
        char *buffer=dupstring(value("BUFFER")), *tail=buffer;
        int offset=0;
        for (char **part=search.parts; *part; ++part) {
            char *pattern=zhtricat("(#",value("HISTORY_SUBSTRING_SEARCH_GLOBBING_FLAGS"),")");
            pattern=dyncat(pattern,quotestring(*part,QT_BACKSLASH_PATTERN)); tokenize(pattern);
            char *matched=dupstring(tail);
            if (!getmatch(&matched,pattern,SUB_SUBSTR|SUB_LONG|SUB_BIND,1,NULL)) continue;
            int index=atoi(matched);
            if (index<1 || index>MB_METASTRLEN(tail)) continue;
            offset+=index;
            char region[80]; snprintf(region,sizeof(region),"%d %d ",offset-1,offset-1+MB_METASTRLEN(*part));
            char **old=getaparam("region_highlight"); size_t count=old ? arrlen(old) : 0;
            char **updated=zalloc((count+2)*sizeof(char *));
            for (size_t i=0;i<count;++i) updated[i]=ztrdup(old[i]);
            updated[count]=ztrdup(zhtricat(region,style,",memo=history-substring-search"));
            updated[count+1]=NULL; setaparam("region_highlight",updated);
            tail=buffer; int remaining=offset;
            while (*tail && remaining--) tail+=MB_METACHARLEN(tail);
        }
    }
    execstring("zle -R; read -k -t ${HISTORY_SUBSTRING_SEARCH_HIGHLIGHT_TIMEOUT:-1} && zle -U -- \"$REPLY\"",1,0,"wsh-history");
    clear_highlight();
}
static int command(char *name, char **args, Options options, int function)
{
    (void)name; (void)options; (void)function;
    if (search.active) return 1;
    if (!strcmp(args[0],"reset")) { reset(); return 0; }
    int down=!strcmp(args[0],"down");
    if (!down && strcmp(args[0],"up")) return 1;
    search.active=1; pushheap();
    int saved=opts[EXTENDEDGLOB]; opts[EXTENDEDGLOB]=1;
    begin();
    int refresh=0; const char *style=NULL;
    char *motion=down ? "zle down-line-or-history" : "zle up-line-or-history";
    if (!*search.query) {
        if (getiparam("HISTNO")==1 && (!down || !*value("BUFFER"))) {
            set_value("BUFFER",down ? entry(1) : ""); refresh=down;
        } else execstring(motion,1,0,"wsh-history");
    } else {
        char *side=down ? dyncat("x",value("RBUFFER")) : dyncat(value("LBUFFER"),"x");
        if (count_lines(value("BUFFER"))>1 && getiparam("CURSOR")!=MB_METASTRLEN(value("BUFFER")) && count_lines(side)!=1)
            execstring(motion,1,0,"wsh-history");
        else { style=navigate(down); refresh=1; }
    }
    finish(refresh,style);
    opts[EXTENDEDGLOB]=saved; popheap(); search.active=0;
    return 0;
}
static struct builtin builtins[]={BUILTIN("wsh-history",0,command,1,1,0,NULL,NULL)};
static struct features features={builtins,1,NULL,0,NULL,0,NULL,0,0};
int setup_(Module m) { (void)m; return 0; }
int boot_(Module m) { (void)m; return 0; }
int features_(Module m,char ***f) { *f=featuresarray(m,&features); return 0; }
int enables_(Module m,int **e) { return handlefeatures(m,&features,e); }
int cleanup_(Module m) { if (search.active) return 1; reset(); return setfeatureenables(m,&features,NULL); }
int finish_(Module m) { (void)m; return 0; }
