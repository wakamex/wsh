set -euxo pipefail
python3 - <<'PY'
from pathlib import Path
p=Path('/var/tmp/test-hosted-update-rpm.py')
s=p.read_text().replace('3f15fec0de1786ca7fe0d0136af1759f5a86ce8f','c8ec27971b43f31ba311a3922bad756ba39c89c4').replace('0.4.0-2.fc44','0.4.1-1.fc44')
Path('/var/tmp/test-hosted-041-rpm.py').write_text(s)
PY
cat /etc/yum.repos.d/*wsh*.repo
