set -euxo pipefail
systemctl restart serial-getty@ttyS0.service
python3 /var/tmp/test-hosted-041-rpm.py
