set -euxo pipefail
test "$(rpm -q --qf '%{VERSION}-%{RELEASE}' wsh)" = 0.4.0-2.fc44
dnf -y --refresh upgrade wsh
python3 /var/tmp/test-hosted-041-rpm.py
/usr/bin/wsh --wsh-version
/usr/bin/wsh --wsh-version | grep -Fx 'wsh 0.4.1 (release build)'
dnf download --destdir /var/tmp/wsh-copr-signed wsh
rpmkeys --checksig -v /var/tmp/wsh-copr-signed/wsh-0.4.1-1.fc44.x86_64.rpm
sha256sum /var/tmp/wsh-copr-signed/wsh-0.4.1-1.fc44.x86_64.rpm /usr/bin/wsh /usr/libexec/wsh/wsh-runtime /usr/share/wsh/manifest.json
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/history-persistence.py /usr/bin/wsh /var/tmp/wsh-copr-history-041
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/pane-history.py /usr/bin/wsh /var/tmp/wsh-copr-pane-041
python3 /var/tmp/test-chsh-guest.py
getenforce
