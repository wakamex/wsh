set -euxo pipefail
dnf -y --refresh install wsh-0.4.0-2.fc44
python3 /var/tmp/test-hosted-update-rpm.py
/usr/bin/wsh --wsh-version
getenforce
