unsetopt globalrcs
if [[ -z ${WSH_CHILD_TEST-} ]]; then WSH_CHILD_TEST=1 "$WSH_TEST_BINARY" -dic "exit 3"; fi
