unsetopt globalrcs
sleep 0.025
