unsetopt globalrcs
sleep 0.025
exit 23
