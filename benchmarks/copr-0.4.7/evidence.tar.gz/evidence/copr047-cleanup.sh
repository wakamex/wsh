set -euxo pipefail
tar -czf /var/tmp/wsh-copr047-test-evidence.tar.gz -C /var/tmp wsh-copr-047-history wsh-copr-047-mail wsh-copr-doctor-047 wsh-copr-047-defaults wsh-copr-047-directory wsh-package-results/chsh.bin
chmod 0644 /var/tmp/wsh-copr047-test-evidence.tar.gz
cp /usr/share/wsh/manifest.json /var/tmp/wsh-copr047-manifest.json
chmod 0644 /var/tmp/wsh-copr047-manifest.json
test "$(getent passwd shellempty | cut -d: -f7)" = /usr/bin/wsh
dnf -y remove wsh
! test -e /usr/bin/wsh
! test -e /usr/libexec/wsh/wsh-runtime
! grep -Fx /usr/bin/wsh /etc/shells
! grep -Fx /bin/wsh /etc/shells
test "$(getent passwd shellempty | cut -d: -f7)" = /usr/bin/wsh
usermod -s /bin/bash shellempty
su -l shellempty -c 'echo RECOVERY_LOGIN_OK'
getenforce
