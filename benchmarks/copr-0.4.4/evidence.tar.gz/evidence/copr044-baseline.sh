set -euxo pipefail
dnf -y --refresh install wsh-0.4.3-1.fc44
python3 /var/tmp/test-hosted-043-rpm.py
rm -f /var/tmp/test-hosted-044-rpm.py
python3 - <<'PY'
from pathlib import Path
s=Path('/var/tmp/test-hosted-043-rpm.py').read_text().replace('b30c880550843ef4e07d3658e85227b88d553a37','bf3d735d67f98811c04cfbf2ea9f9eb8374133ca').replace('0.4.3-1.fc44','0.4.4-1.fc44')
Path('/var/tmp/test-hosted-044-rpm.py').write_text(s)
PY
grep -c bf3d735 /var/tmp/test-hosted-044-rpm.py
getenforce
