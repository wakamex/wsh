set -euxo pipefail
test "$(rpm -q --qf '%{VERSION}-%{RELEASE}' wsh)" = 0.4.3-1.fc44
dnf -y --refresh upgrade wsh
python3 /var/tmp/test-hosted-044-rpm.py
/usr/bin/wsh --wsh-version | grep -Fx 'wsh 0.4.4 (release build)'
rm -rf /var/tmp/wsh-copr-signed
dnf download --destdir /var/tmp/wsh-copr-signed wsh
rpmkeys --checksig -v /var/tmp/wsh-copr-signed/wsh-0.4.4-1.fc44.x86_64.rpm
rpm -V wsh
sha256sum /var/tmp/wsh-copr-signed/wsh-0.4.4-1.fc44.x86_64.rpm /usr/bin/wsh /usr/libexec/wsh/wsh-runtime /usr/share/wsh/manifest.json
f=$(rpm -ql wsh | grep d42d6b1377423cf596ebc49405984ea7d81d5e9136d8892880f08a3d00ab7b17 | head -1)
test -n "$f"
echo "$(sha256sum "$f")"
grep -l d42d6b1377423cf596ebc49405984ea7d81d5e9136d8892880f08a3d00ab7b17 $(rpm -ql wsh | grep catalog.zsh)
rm -rf /var/tmp/wsh-copr-044-history /var/tmp/wsh-copr-044-mail /var/tmp/wsh-copr-doctor-044
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/history-persistence.py /usr/bin/wsh /var/tmp/wsh-copr-044-history
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/mail-check.py /usr/bin/wsh /var/tmp/wsh-copr-044-mail
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/doctor-terminal.py /usr/bin/wsh /var/tmp/wsh-copr-doctor-044
getenforce
