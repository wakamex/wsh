use std::env;
use std::ffi::OsString;
use std::os::unix::process::CommandExt;
use std::path::{Path, PathBuf};
use std::process::{Command, ExitCode};

use wsh::{
    BundleStatus, activate_bundle, active_bundle, active_bundle_for_launch,
    active_bundle_for_profile, active_verified_bundle, entrypoints, rollback_bundle, verify_bundle,
};

mod doctor;
mod login;
mod profile;
mod update;

fn usage() -> &'static str {
    "usage:\n  wsh\n  wsh --version\n  wsh version [--state-root <directory>]\n  wsh -- <command> [arguments...]\n  wsh bundle verify <bundle>\n  wsh bundle activate <bundle> [--state-root <directory>]\n  wsh bundle rollback [--state-root <directory>]\n  wsh bundle current [--state-root <directory>]\n  wsh doctor [--state-root <directory>]\n  wsh profile [--functions] [--bundle <bundle>] [--state-root <directory>] [-- <zsh arguments...>]\n  wsh profile report <profile-directory>\n  wsh update [--check | --to vMAJOR.MINOR.PATCH] [--state-root <directory>]\n  wsh run [--bundle <bundle>] [--state-root <directory>] [-- <zsh arguments...>]\n  wsh run-foreground [--bundle <bundle>] [--state-root <directory>] [--login] -- <command> [arguments...]"
}

fn default_state_root() -> Result<PathBuf, String> {
    if let Some(path) = env::var_os("WSH_STATE_ROOT") {
        return Ok(PathBuf::from(path));
    }
    if let Some(path) = env::var_os("XDG_DATA_HOME") {
        return Ok(PathBuf::from(path).join("wsh"));
    }
    env::var_os("HOME")
        .map(|path| PathBuf::from(path).join(".local/share/wsh"))
        .ok_or_else(|| "HOME, XDG_DATA_HOME, or WSH_STATE_ROOT is required".into())
}

fn parse_state_root(arguments: &[std::ffi::OsString]) -> Result<PathBuf, String> {
    match arguments {
        [] => default_state_root(),
        [option, path] if option == "--state-root" => Ok(PathBuf::from(path)),
        _ => Err(usage().into()),
    }
}

fn select_user_zdotdir(
    configured: Option<OsString>,
    inherited_bundle_root: Option<OsString>,
    inherited_user_zdotdir: Option<OsString>,
    home: Option<OsString>,
) -> Option<OsString> {
    let inherited_bundle_zdotdir = inherited_bundle_root
        .map(PathBuf::from)
        .map(|root| root.join("share/wsh/zdotdir"));
    match configured {
        Some(path)
            if inherited_bundle_zdotdir
                .as_ref()
                .is_some_and(|bundle| PathBuf::from(&path) == *bundle) =>
        {
            inherited_user_zdotdir.or(home)
        }
        Some(path) => Some(path),
        None => home,
    }
}

fn user_zdotdir() -> Option<OsString> {
    select_user_zdotdir(
        env::var_os("ZDOTDIR"),
        env::var_os("WSH_BUNDLE_ROOT"),
        env::var_os("WSH_USER_ZDOTDIR"),
        env::var_os("HOME"),
    )
}

fn configured_shell(bundle: &Path, paths: &wsh::EntrypointPaths) -> Command {
    let mut command = Command::new(&paths.shell);
    command.arg("-d");
    if let Some(user_zdotdir) = user_zdotdir() {
        command.env("WSH_USER_ZDOTDIR", user_zdotdir);
    } else {
        command.env_remove("WSH_USER_ZDOTDIR");
    }
    command
        .env("WSH_BUNDLE_ROOT", bundle)
        .env("WSH_RUNTIME", &paths.runtime)
        .env("WSH_NATIVE_TERMINAL_INTEGRATION", "1")
        .env("ZDOTDIR", &paths.zdotdir)
        .env_remove("WSH_RUN_FOREGROUND")
        .env_remove("WSH_STARTUP_BUNDLE_ZDOTDIR")
        .env_remove("WSH_STARTUP_RCS");
    command
}

fn run() -> Result<(), String> {
    let mut incoming = env::args_os();
    let program = incoming.next().unwrap_or_default();
    let remaining: Vec<_> = incoming.collect();
    if login::is_shell_invocation(&program, &remaining) {
        return login::run(&program, &remaining);
    }
    let mut args = remaining.into_iter();
    let requested_action = args
        .next()
        .map(|arg| arg.into_string())
        .transpose()
        .map_err(|_| usage().to_owned())?;
    let foreground_shorthand = requested_action.as_deref() == Some("--");
    let action = if foreground_shorthand {
        "run-foreground"
    } else {
        requested_action.as_deref().unwrap_or("run")
    };
    match action {
        "--version" => {
            if args.next().is_some() {
                return Err(usage().into());
            }
            println!("wsh {}", env!("CARGO_PKG_VERSION"));
            Ok(())
        }
        "version" => {
            let remaining: Vec<_> = args.collect();
            let state_root = parse_state_root(&remaining)?;
            let (_, verified) = active_verified_bundle(&state_root)?;
            let status = match verified.manifest.status {
                BundleStatus::Development => "development",
                BundleStatus::Release => "release",
            };
            println!("wsh {}", env!("CARGO_PKG_VERSION"));
            println!("bundle: {} ({status})", verified.manifest.release_id);
            println!("wsh source: {}", verified.manifest.rust.source_revision);
            println!("zsh: {}", verified.manifest.zsh.version);
            println!("zsh source: {}", verified.manifest.zsh.source_revision);
            println!("target: {}", verified.manifest.target);
            println!("bundle sha256: {}", verified.manifest_sha256);
            Ok(())
        }
        "bundle" => {
            let action = args
                .next()
                .and_then(|arg| arg.into_string().ok())
                .ok_or_else(|| usage().to_owned())?;
            let remaining: Vec<_> = args.collect();
            match action.as_str() {
                "verify" => {
                    let [bundle] = remaining.as_slice() else {
                        return Err(usage().into());
                    };
                    let verified = verify_bundle(&PathBuf::from(bundle))?;
                    println!("{}", verified.manifest_sha256);
                }
                "activate" => {
                    let bundle = remaining.first().ok_or_else(|| usage().to_owned())?;
                    let state_root = parse_state_root(&remaining[1..])?;
                    println!("{}", activate_bundle(&state_root, &PathBuf::from(bundle))?);
                }
                "rollback" => {
                    let state_root = parse_state_root(&remaining)?;
                    println!("{}", rollback_bundle(&state_root)?);
                }
                "current" => {
                    let state_root = parse_state_root(&remaining)?;
                    println!("{}", active_bundle(&state_root)?.display());
                }
                _ => return Err(usage().into()),
            }
            Ok(())
        }
        "run" => {
            let remaining: Vec<_> = args.collect();
            let separator = remaining.iter().position(|arg| arg == "--");
            let (options, shell_args) = separator.map_or((&remaining[..], &[][..]), |index| {
                (&remaining[..index], &remaining[index + 1..])
            });
            let mut bundle = None;
            let mut state_root = None;
            let mut index = 0;
            while index < options.len() {
                let value = options.get(index + 1).ok_or_else(|| usage().to_owned())?;
                match options[index].to_str() {
                    Some("--bundle") => bundle = Some(PathBuf::from(value)),
                    Some("--state-root") => state_root = Some(PathBuf::from(value)),
                    _ => return Err(usage().into()),
                }
                index += 2;
            }
            let (bundle, paths) = match bundle {
                Some(bundle) => {
                    let verified = verify_bundle(&bundle)?;
                    let paths = entrypoints(&bundle, &verified.manifest);
                    (bundle, paths)
                }
                None => {
                    let launch =
                        active_bundle_for_launch(&state_root.unwrap_or(default_state_root()?))?;
                    (launch.root, launch.entrypoints)
                }
            };
            let mut command = configured_shell(&bundle, &paths);
            command.args(shell_args);
            let error = command.exec();
            Err(format!(
                "could not replace the launcher with {}: {error}",
                paths.shell.display()
            ))
        }
        "run-foreground" => {
            let mut remaining: Vec<_> = args.collect();
            if foreground_shorthand {
                remaining.insert(0, OsString::from("--"));
            }
            let separator = remaining
                .iter()
                .position(|arg| arg == "--")
                .ok_or_else(|| usage().to_owned())?;
            let (options, foreground_args) = (&remaining[..separator], &remaining[separator + 1..]);
            if foreground_args.is_empty() {
                return Err(usage().into());
            }
            let mut bundle = None;
            let mut state_root = None;
            let mut login = false;
            let mut index = 0;
            while index < options.len() {
                match options[index].to_str() {
                    Some("--bundle") => {
                        let value = options.get(index + 1).ok_or_else(|| usage().to_owned())?;
                        bundle = Some(PathBuf::from(value));
                        index += 2;
                    }
                    Some("--state-root") => {
                        let value = options.get(index + 1).ok_or_else(|| usage().to_owned())?;
                        state_root = Some(PathBuf::from(value));
                        index += 2;
                    }
                    Some("--login") if !login => {
                        login = true;
                        index += 1;
                    }
                    _ => return Err(usage().into()),
                }
            }
            let (bundle, paths) = match bundle {
                Some(bundle) => {
                    let verified = verify_bundle(&bundle)?;
                    let paths = entrypoints(&bundle, &verified.manifest);
                    (bundle, paths)
                }
                None => {
                    let launch =
                        active_bundle_for_launch(&state_root.unwrap_or(default_state_root()?))?;
                    (launch.root, launch.entrypoints)
                }
            };
            let mut command = Command::new(&paths.shell);
            command.arg("-d");
            if login {
                command.arg("-l");
            }
            command.arg("-i").arg("-s").arg("--").args(foreground_args);
            if let Some(user_zdotdir) = user_zdotdir() {
                command.env("WSH_USER_ZDOTDIR", user_zdotdir);
            } else {
                command.env_remove("WSH_USER_ZDOTDIR");
            }
            command
                .env("WSH_BUNDLE_ROOT", &bundle)
                .env("WSH_RUNTIME", &paths.runtime)
                .env("WSH_NATIVE_TERMINAL_INTEGRATION", "1")
                .env("WSH_RUN_FOREGROUND", "1")
                .env("ZDOTDIR", &paths.zdotdir)
                .env_remove("WSH_STARTUP_BUNDLE_ZDOTDIR")
                .env_remove("WSH_STARTUP_RCS");
            let error = command.exec();
            Err(format!(
                "could not replace the launcher with {}: {error}",
                paths.shell.display()
            ))
        }
        "profile" => {
            let remaining: Vec<_> = args.collect();
            if remaining.first().is_some_and(|value| value == "report") {
                let [_, directory] = remaining.as_slice() else {
                    return Err(usage().into());
                };
                print!("{}", profile::report(&PathBuf::from(directory))?);
                return Ok(());
            }
            let separator = remaining.iter().position(|arg| arg == "--");
            let (options, shell_args) = separator.map_or((&remaining[..], &[][..]), |index| {
                (&remaining[..index], &remaining[index + 1..])
            });
            let mut bundle = None;
            let mut state_root = None;
            let mut functions = false;
            let mut index = 0;
            while index < options.len() {
                match options[index].to_str() {
                    Some("--functions") if !functions => {
                        functions = true;
                        index += 1;
                        continue;
                    }
                    Some("--bundle") => {
                        let value = options.get(index + 1).ok_or_else(|| usage().to_owned())?;
                        bundle = Some(PathBuf::from(value));
                    }
                    Some("--state-root") => {
                        let value = options.get(index + 1).ok_or_else(|| usage().to_owned())?;
                        state_root = Some(PathBuf::from(value));
                    }
                    _ => return Err(usage().into()),
                }
                index += 2;
            }
            let state_root = state_root.unwrap_or(default_state_root()?);
            let session = profile::create(&state_root, functions)?;
            eprintln!(
                "Profiling this shell. Exit to view the report.\nTrace: {}",
                session.directory.display()
            );
            let (bundle, paths, manifest_sha256) = match bundle {
                Some(bundle) => {
                    let verified = verify_bundle(&bundle)?;
                    let paths = entrypoints(&bundle, &verified.manifest);
                    (bundle, paths, verified.manifest_sha256)
                }
                None => {
                    let selected = active_bundle_for_profile(&state_root)?;
                    (
                        selected.root,
                        selected.entrypoints,
                        selected.manifest_sha256,
                    )
                }
            };
            profile::record_manager_metadata(&session, &bundle, &manifest_sha256)?;
            let reporter = env::current_exe()
                .map_err(|error| format!("could not resolve the wsh executable: {error}"))?;
            let mut command = Command::new(&paths.shell);
            command.arg("-d").args(shell_args);
            if let Some(user_zdotdir) = user_zdotdir() {
                command.env("WSH_USER_ZDOTDIR", user_zdotdir);
            } else {
                command.env_remove("WSH_USER_ZDOTDIR");
            }
            command
                .env("WSH_BUNDLE_ROOT", &bundle)
                .env("WSH_RUNTIME", &paths.runtime)
                .env("WSH_NATIVE_TERMINAL_INTEGRATION", "1")
                .env("WSH_PROFILE_DIRECTORY", &session.directory)
                .env("WSH_PROFILE_FILE", &session.trace)
                .env("WSH_PROFILE_ZPROF_FILE", &session.zprof)
                .env("WSH_PROFILE_REPORTER", reporter)
                .env("WSH_PROFILE_FUNCTIONS", if functions { "1" } else { "0" })
                .env(
                    "WSH_PROFILE_STARTED_UNIX_US",
                    session.started_unix_us.to_string(),
                )
                .env("WSH_PROFILE_STARTED_AT", profile::started_seconds(&session))
                .env("WSH_TRACE_FILE", &session.trace)
                .env("ZDOTDIR", &paths.zdotdir)
                .env_remove("WSH_RUN_FOREGROUND")
                .env_remove("WSH_STARTUP_BUNDLE_ZDOTDIR")
                .env_remove("WSH_STARTUP_RCS");
            let error = command.exec();
            Err(format!(
                "could not replace the profiler with {}: {error}",
                paths.shell.display()
            ))
        }
        "update" => {
            let remaining: Vec<_> = args.collect();
            let mut check = false;
            let mut target = None;
            let mut state_root = None;
            let mut index = 0;
            while index < remaining.len() {
                match remaining[index].to_str() {
                    Some("--check") => {
                        if check {
                            return Err(usage().into());
                        }
                        check = true;
                        index += 1;
                    }
                    Some("--to") => {
                        if target.is_some() {
                            return Err(usage().into());
                        }
                        let value = remaining.get(index + 1).ok_or_else(|| usage().to_owned())?;
                        target = Some(
                            value
                                .to_str()
                                .ok_or_else(|| "release tag must be UTF-8".to_owned())?
                                .to_owned(),
                        );
                        index += 2;
                    }
                    Some("--state-root") => {
                        if state_root.is_some() {
                            return Err(usage().into());
                        }
                        let value = remaining.get(index + 1).ok_or_else(|| usage().to_owned())?;
                        state_root = Some(PathBuf::from(value));
                        index += 2;
                    }
                    _ => return Err(usage().into()),
                }
            }
            if check && target.is_some() {
                return Err(usage().into());
            }
            let state_root = state_root.unwrap_or(default_state_root()?);
            let bundle = active_bundle(&state_root)?;
            let verified = verify_bundle(&bundle)?;
            if verified.manifest.status != BundleStatus::Release {
                return Err("updates require an active official release bundle".into());
            }
            let mode = if check {
                update::UpdateMode::Check
            } else if let Some(target) = target {
                update::UpdateMode::Exact(target)
            } else {
                update::UpdateMode::Latest
            };
            update::run(mode, &verified.manifest.release_id, &state_root)
        }
        "doctor" => {
            let remaining: Vec<_> = args.collect();
            let state_root = parse_state_root(&remaining)?;
            let launch = active_bundle_for_launch(&state_root)?;
            let user_zdotdir = user_zdotdir();
            doctor::run(doctor::Shell {
                executable: &launch.entrypoints.shell,
                bundle_root: &launch.root,
                runtime: &launch.entrypoints.runtime,
                zdotdir: &launch.entrypoints.zdotdir,
                user_zdotdir: user_zdotdir.as_deref(),
            })
        }
        _ => Err(usage().into()),
    }
}

fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("error: {error}");
            ExitCode::FAILURE
        }
    }
}

#[cfg(test)]
mod tests {
    use super::select_user_zdotdir;
    use std::ffi::OsString;

    fn value(value: &str) -> Option<OsString> {
        Some(OsString::from(value))
    }

    #[test]
    fn preserves_explicit_user_zdotdir() {
        assert_eq!(
            select_user_zdotdir(value("/user/config"), None, None, value("/home/user")),
            value("/user/config")
        );
    }

    #[test]
    fn recovers_user_zdotdir_inherited_from_an_older_wsh_session() {
        assert_eq!(
            select_user_zdotdir(
                value("/old-bundle/share/wsh/zdotdir"),
                value("/old-bundle"),
                value("/user/config"),
                value("/home/user"),
            ),
            value("/user/config")
        );
    }

    #[test]
    fn uses_home_when_zdotdir_is_unset_or_only_the_old_bundle_is_known() {
        assert_eq!(
            select_user_zdotdir(None, None, None, value("/home/user")),
            value("/home/user")
        );
        assert_eq!(
            select_user_zdotdir(
                value("/old-bundle/share/wsh/zdotdir"),
                value("/old-bundle"),
                None,
                value("/home/user"),
            ),
            value("/home/user")
        );
    }
}
