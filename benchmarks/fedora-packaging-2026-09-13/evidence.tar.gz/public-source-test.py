import importlib.util
import json
from pathlib import Path
import subprocess

root = Path('/code/wsh')
spec = importlib.util.spec_from_file_location('srpm', root/'packaging/build-source-rpm.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
records = [(name, subprocess.check_output(['git', 'show', revision+':'+name], cwd=root), 0o644)
           for name in ('VERSION', 'native/startup.c', 'packaging/wsh.spec')]
module.download_sources(revision, records, Path('/var/tmp/wsh-public-source-check.tar.gz'))
try:
    module.download_sources(revision, [('VERSION', b'wrong', 0o644)], Path('/var/tmp/wsh-public-source-rejection.tar.gz'))
except AssertionError as error:
    assert str(error) == 'published source differs: VERSION'
else:
    raise AssertionError('accepted mismatched source')
result = dict(revision=revision, compared_files=[r[0] for r in records],
              public_archive_matches=True, mismatched_source_rejected=True)
Path('/var/tmp/wsh-fedora-public-source.json').write_text(json.dumps(result, indent=2)+'\n')
print('PASS: real public archive matches committed sources and rejects altered inputs')
