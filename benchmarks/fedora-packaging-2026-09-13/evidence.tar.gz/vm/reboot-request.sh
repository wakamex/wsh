cat /proc/sys/kernel/random/boot_id
systemctl reboot
