set -e
mv /usr/share/wsh /var/tmp/wsh-integration-backup
