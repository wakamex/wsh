set -e
getenforce
dnf -y install /var/tmp/wsh-0.4.0-0.1.x86_64.rpm
mkdir -p /var/tmp/wsh-package-results
python3 /var/tmp/test-chsh-guest.py
rpm -V wsh
ls -lZ /usr/bin/wsh /usr/libexec/wsh/wsh-runtime /usr/share/wsh/defaults/native-before.zsh
