set -e
rpm -Uvh --replacepkgs /var/tmp/wsh-0.4.0-1.fc44.x86_64.rpm
rpm -V wsh
rpm -q --provides wsh
getenforce
