set -e
chmod 000 /usr/libexec/wsh/wsh-runtime
