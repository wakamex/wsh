set -e
mv /usr/libexec/wsh/wsh-runtime /var/tmp/wsh-runtime-backup; printf '#!/bin/sh\nexit 64\n' > /usr/libexec/wsh/wsh-runtime; chmod 755 /usr/libexec/wsh/wsh-runtime; restorecon /usr/libexec/wsh/wsh-runtime
