set -e
mv /usr/libexec/wsh/wsh-runtime /var/tmp/wsh-runtime-backup
