set -e
rpm -V wsh
ls -lZ /usr/bin/wsh /usr/libexec/wsh/wsh-runtime /usr/share/wsh/native-before.zsh
python3 /var/tmp/test-transactions-guest.py
