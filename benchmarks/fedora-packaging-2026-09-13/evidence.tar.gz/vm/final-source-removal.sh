set -e
rpm -e wsh
test "$(getent passwd shellempty | cut -d: -f7)" = /usr/bin/wsh
! grep -qxF /usr/bin/wsh /etc/shells
! grep -qxF /bin/wsh /etc/shells
usermod -s /bin/bash shellempty
runuser -l shellempty -c "echo RECOVERY_OK"
echo "PASS: final source RPM removal and independent recovery"
