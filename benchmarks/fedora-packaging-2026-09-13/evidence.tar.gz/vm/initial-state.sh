set -eu
getenforce
rpm -q wsh || :
getent passwd shellempty
cat /proc/sys/kernel/random/boot_id
