set -e
dnf -y --disablerepo="*" install /var/tmp/wsh-0.4.0-1.fc44.x86_64.rpm
python3 /var/tmp/test-chsh-guest.py
rpm -V wsh
getenforce
