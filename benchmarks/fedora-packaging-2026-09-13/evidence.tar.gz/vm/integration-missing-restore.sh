set -e
if [ -f /var/tmp/wsh-runtime-backup ]; then mv -f /var/tmp/wsh-runtime-backup /usr/libexec/wsh/wsh-runtime; fi
chmod 755 /usr/libexec/wsh/wsh-runtime
if [ -d /var/tmp/wsh-integration-backup ]; then mv /var/tmp/wsh-integration-backup /usr/share/wsh; fi
rm -f /home/shellempty/.zshrc
restorecon -R /usr/libexec/wsh /usr/share/wsh
rpm -V wsh
