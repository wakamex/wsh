set -e
getenforce
cat /proc/sys/kernel/random/boot_id
rpm -V wsh
