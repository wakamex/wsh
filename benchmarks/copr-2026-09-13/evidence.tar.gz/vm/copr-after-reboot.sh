set -euxo pipefail
test "$(cat /proc/sys/kernel/random/boot_id)" != bf397516-4f7e-4a80-820f-12aa9ce8bce1
cat /proc/sys/kernel/random/boot_id
test "$(getenforce)" = Enforcing
rpm -V wsh
