set -euxo pipefail
dnf -y install /var/tmp/wsh-0.4.0-0.1.x86_64.rpm
rpm -q wsh
rpm -V wsh
/usr/bin/wsh --wsh-version
readlink /usr/bin/wsh
python3 /var/tmp/test-chsh-guest.py
