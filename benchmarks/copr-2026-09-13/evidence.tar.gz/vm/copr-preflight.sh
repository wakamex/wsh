set -euxo pipefail
cat /etc/fedora-release
getenforce
getent passwd shellempty
rpm -q wsh || test $? = 1
dnf copr --help >/dev/null
