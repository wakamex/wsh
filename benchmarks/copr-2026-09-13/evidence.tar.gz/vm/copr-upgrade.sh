set -euxo pipefail
dnf -y --refresh upgrade wsh
python3 /var/tmp/test-hosted-rpm.py
/usr/bin/wsh --wsh-version
dnf info --installed wsh
mkdir -p /var/tmp/wsh-copr-signed
dnf download --destdir /var/tmp/wsh-copr-signed wsh
rpmkeys --checksig -v /var/tmp/wsh-copr-signed/wsh-0.4.0-1.fc44.x86_64.rpm
sha256sum /var/tmp/wsh-copr-signed/wsh-0.4.0-1.fc44.x86_64.rpm /usr/bin/wsh /usr/libexec/wsh/wsh-runtime /usr/share/wsh/manifest.json
rpmkeys --list
getenforce
