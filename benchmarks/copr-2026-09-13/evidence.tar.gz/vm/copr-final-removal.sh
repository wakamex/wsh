set -euxo pipefail
test "$(getent passwd shellempty | cut -d: -f7)" = /usr/bin/wsh
dnf -y remove wsh
! test -e /usr/bin/wsh
! test -e /usr/libexec/wsh/wsh-runtime
! grep -Fx /usr/bin/wsh /etc/shells
! grep -Fx /bin/wsh /etc/shells
test "$(getent passwd shellempty | cut -d: -f7)" = /usr/bin/wsh
usermod -s /bin/bash shellempty
su -l shellempty -c 'echo RECOVERY_LOGIN_OK'
getenforce
