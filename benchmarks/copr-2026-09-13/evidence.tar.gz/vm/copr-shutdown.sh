set -e
systemctl poweroff --no-block
