set -e
rpm -q dnf5-plugins
