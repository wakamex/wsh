set -euxo pipefail
dnf -y copr enable wakamex/wsh
cat /etc/yum.repos.d/_copr:copr.fedorainfracloud.org:wakamex:wsh.repo
python3 - <<'PY'
import configparser
p=configparser.ConfigParser(interpolation=None)
p.read('/etc/yum.repos.d/_copr:copr.fedorainfracloud.org:wakamex:wsh.repo')
s=p['copr:copr.fedorainfracloud.org:wakamex:wsh']
assert s.getboolean('enabled') and s.getboolean('gpgcheck')
assert s['gpgkey']=='https://download.copr.fedorainfracloud.org/results/wakamex/wsh/pubkey.gpg',dict(s)
assert s['baseurl'].startswith('https://download.copr.fedorainfracloud.org/results/wakamex/wsh/')
print('PASS: actual COPR repository enabled with package signature checking')
PY
