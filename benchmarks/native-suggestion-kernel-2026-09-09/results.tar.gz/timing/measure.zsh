module_path=($1 $module_path)
zmodload wshsuggest || exit 2
zmodload zsh/datetime
source $2
functions[control]=$functions[_zsh_autosuggest_strategy_history]
source $3
functions[quote_builtin]=$functions[_zsh_autosuggest_strategy_history]
candidate() { emulate -L zsh; setopt extended_glob; wsh-history-suggest "$1"; }
zmodload zsh/parameter
fc -p
HISTSIZE=20000
for ((i=0;i<$4;i++)); do print -s -- "echo project $i"; done
print -s -- sentinel
typeset -a rows
for query in 'echo project' 'no-match'; do
 control "$query"; quote_builtin "$query"; candidate "$query"
 for ((i=0;i<50;i++)); do
  owners=(control quote_builtin candidate)
  ((i%2)) && owners=(candidate quote_builtin control)
  for owner in $owners; do
   start=$EPOCHREALTIME
   $owner "$query"
   elapsed=$(( (EPOCHREALTIME-start)*1000 ))
   rows+=("$i ${(qqq)query} $owner $elapsed ${(qqq)suggestion}")
  done
 done
done
print -rl -- $rows
