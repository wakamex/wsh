module_path=($1 $module_path)
zmodload wshsuggest || exit 2
source $2
zmodload zsh/parameter
fc -p
HISTSIZE=10000
unsetopt hist_ignore_all_dups hist_ignore_dups
source $3
for prefix in $prefixes; do print -s -- "$prefix suffix"; done
print -s -- 'sentinel'
[[ $4 == candidate ]] && functions[_zsh_autosuggest_strategy_history]='emulate -L zsh; setopt extended_glob; wsh-history-suggest "$1"'
for ignore in '' '*suffix' '*[ab]*' '(#i)*ECHO*' '[' '('; do
 ZSH_AUTOSUGGEST_HISTORY_IGNORE=$ignore
 for prefix in "${prefixes[@]}"; do
  _zsh_autosuggest_strategy_history "$prefix"
  result=$?
  print -r -- "$result ${(qqqq)suggestion}"
 done
 print -s -- 'echo new history'
 print -s -- 'sentinel next'
done
