if [[ -n ${WSH_BUNDLE_ROOT:-} ]]; then
  typeset WSH_STARTUP_MODULE_PATH=${WSH_BUNDLE_ROOT}/lib/zsh/${ZSH_VERSION}
  typeset WSH_STARTUP_FUNCTION_PATH=${WSH_BUNDLE_ROOT}/share/zsh/${ZSH_VERSION}/functions
  module_path=("$WSH_STARTUP_MODULE_PATH" "${(@)module_path:#${(b)WSH_STARTUP_MODULE_PATH}}")
  fpath=("$WSH_STARTUP_FUNCTION_PATH" "${(@)fpath:#${(b)WSH_STARTUP_FUNCTION_PATH}}")
  unset WSH_STARTUP_MODULE_PATH WSH_STARTUP_FUNCTION_PATH
  if [[ ${WSH_RUN_FOREGROUND:-0} == prepared ]]; then
    autoload -Uz add-zsh-hook
    _wsh_run_foreground_startup() {
      builtin emulate -L zsh -o no_aliases
      add-zsh-hook -d precmd _wsh_run_foreground_startup
      local -a foreground_command=("${_WSH_FOREGROUND_ARGV[@]}")
      unset _WSH_FOREGROUND_ARGV WSH_RUN_FOREGROUND
      unfunction _wsh_run_foreground_startup
      if (( $#foreground_command == 0 )); then
        print -u2 -- 'wsh: foreground command is unavailable'
        return 127
      fi
      local extension extension_name
      local -i output_markers=1
      for extension in "${.term.extensions[@]}"; do
        extension_name=${extension#-}
        if [[ $extension_name == integration || $extension_name == integration-output ]]; then
          if [[ $extension == -* ]]; then
            output_markers=0
          else
            output_markers=1
          fi
          break
        fi
      done
      (( output_markers )) && print -nr -- $'\e]133;C\e\\' >| /dev/tty
      "$foreground_command[@]"
      local -i foreground_status=$?
      (( output_markers )) && print -nr -- $'\e]133;D\e\\' >| /dev/tty
      return $foreground_status
    }
    add-zsh-hook precmd _wsh_run_foreground_startup
    precmd_functions=(_wsh_run_foreground_startup "${(@)precmd_functions:#_wsh_run_foreground_startup}")
  fi
  (( $+functions[_wsh_profile_event] )) && _wsh_profile_event directory-jump-start
  source "${WSH_BUNDLE_ROOT}/share/wsh/defaults/directory-jump.zsh"
  (( $+functions[_wsh_profile_event] )) && _wsh_profile_event directory-jump-end
  (( $+functions[_wsh_profile_event] )) && _wsh_profile_event history-start
  source "${WSH_BUNDLE_ROOT}/share/wsh/defaults/history-substring-search.zsh"
  (( $+functions[_wsh_profile_event] )) && _wsh_profile_event history-end
  (( $+functions[_wsh_profile_event] )) && _wsh_profile_event autosuggestions-start
  source "${WSH_BUNDLE_ROOT}/share/wsh/defaults/autosuggestions.zsh"
  (( $+functions[_wsh_profile_event] )) && _wsh_profile_event autosuggestions-end
  (( $+functions[_wsh_profile_event] )) && _wsh_profile_event syntax-highlighting-start
  if [[ ${WSH_DISABLE_SYNTAX_HIGHLIGHTING:-0} == 1 ]]; then
    typeset -g WSH_SYNTAX_HIGHLIGHTING_OWNER=disabled
  else
    source "${WSH_BUNDLE_ROOT}/share/wsh/defaults/syntax-highlighting.zsh"
  fi
  (( $+functions[_wsh_profile_event] )) && _wsh_profile_event syntax-highlighting-end
  (( $+functions[_wsh_profile_event] )) && _wsh_profile_event integration-start
  source "${WSH_BUNDLE_ROOT}/share/wsh/integration.zsh"
  (( $+functions[_wsh_profile_event] )) && _wsh_profile_event integration-end
  (( $+functions[_wsh_profile_install] )) && _wsh_profile_install
fi

