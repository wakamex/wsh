module_path=($1 $module_path)
zmodload wshcollector || exit 2
repeat 100; do
  wsh-collector-probe start "$2" || exit 3
  while ! wsh-collector-probe poll; do :; done
done
zmodload -u wshcollector || exit 4
