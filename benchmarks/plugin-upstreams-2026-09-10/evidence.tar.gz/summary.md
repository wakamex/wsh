| Component | Upstream | Result |
| --- | --- | --- |
| autosuggestions | https://github.com/zsh-users/zsh-autosuggestions/commit/85919cd1ffa7d2d5412f6d3fe437ebdbeeec4fc5 | known |
| history | https://github.com/zsh-users/zsh-history-substring-search/commit/14c8d2e0ffaee98f2df9850b19944f32546fdea5 | known |
| history | https://github.com/ohmyzsh/ohmyzsh/commit/c6e66edee824d83e84473ec666917b58323630df | known |
| syntax | https://github.com/zsh-users/zsh-syntax-highlighting/commit/2fc57d63067c18b1100ecdbf684fa5baf49459d1 | known |
| directory | https://github.com/ohmyzsh/ohmyzsh/commit/c6e66edee824d83e84473ec666917b58323630df | known |
| git-prompt | https://github.com/ohmyzsh/ohmyzsh/commit/c6e66edee824d83e84473ec666917b58323630df | known |
