/* Generated automatically */
#if defined(HAVE_PCRE2_COMPILE_8) && defined(HAVE_PCRE2_H)
static int zpcre_utf8_enabled(void);
static int bin_pcre_compile(char*nam,char**args,Options ops,UNUSED(int func));
static int bin_pcre_study(char*nam,UNUSED(char**args),UNUSED(Options ops),UNUSED(int func));
static int getposint(char*instr,char*nam);
static int bin_pcre_match(char*nam,char**args,Options ops,UNUSED(int func));
static int cond_pcre_match(char**a,int id);
#else /* !(HAVE_PCRE_COMPILE && HAVE_PCRE_EXEC) */
#endif /* !(HAVE_PCRE_COMPILE && HAVE_PCRE_EXEC) */
