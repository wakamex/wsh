/* Generated automatically */
static int bin_example(char*nam,char**args,Options ops,UNUSED(int func));
static int cond_p_len(char**a,UNUSED(int id));
static int cond_i_ex(char**a,UNUSED(int id));
static mnumber math_sum(UNUSED(char*name),int argc,mnumber*argv,UNUSED(int id));
static mnumber math_length(UNUSED(char*name),char*arg,UNUSED(int id));
static int ex_wrapper(Eprog prog,FuncWrap w,char*name);
