/* Generated automatically */
static int bin_zcurses(char*nam,char**args,UNUSED(Options ops),UNUSED(int func));
