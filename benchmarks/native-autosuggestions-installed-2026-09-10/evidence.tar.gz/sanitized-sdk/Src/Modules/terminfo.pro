/* Generated automatically */
#ifdef USE_TERMINFO_MODULE
static int bin_echoti(char*name,char**argv,UNUSED(Options ops),UNUSED(int func));
static HashNode getterminfo(UNUSED(HashTable ht),const char*name);
static void scanterminfo(UNUSED(HashTable ht),ScanFunc func,int flags);
#endif /* USE_TERMINFO_MODULE */
