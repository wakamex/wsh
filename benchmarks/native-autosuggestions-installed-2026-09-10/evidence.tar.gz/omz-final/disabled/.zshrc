ZSH=/var/tmp/wsh-omz-source-20260903
ZSH_CUSTOM=/var/tmp/wsh-autosuggestions-installed/omz-final/disabled/custom
ZSH_THEME=""
plugins=(git zsh-autosuggestions)
DISABLE_AUTO_UPDATE=true
zstyle ":omz:update" mode disabled
source "$ZSH/oh-my-zsh.sh"
PROMPT="OMZ> "
WSH_DISABLE_AUTOSUGGESTIONS=1
