import os,pty,select,time,json
from pathlib import Path
root=Path('/var/tmp/wsh-autosuggestions-installed');home=root/'omz/pending'
rows=[]
for owner,binary in [('control',Path('/code/wsh/bundles/e70519fc262f3e93a386d74e0ffbe1696a93f44ceb0ec76b19aaf59c7d85c5dc/bin/wsh')),('candidate',root/'bundles/f318bec1a15d5a67ecfa51e640527c235ba89f0b9ae3c8ffadfdadab50e04afb/bin/wsh')]:
 pid,fd=pty.fork()
 if not pid:os.execve(binary,[str(binary),'--wsh-doctor'],dict(PATH='/usr/bin:/bin',HOME=str(home),ZDOTDIR=str(home),TERM='xterm-256color',LC_ALL='C.UTF-8'))
 data=bytearray();end=time.monotonic()+15
 while time.monotonic()<end:
  if select.select([fd],[],[],.05)[0]:
   try:data.extend(os.read(fd,65536))
   except OSError:break
 else:os.kill(pid,9)
 _,status=os.waitpid(pid,0);os.close(fd)
 (root/('doctor-tty-'+owner+'.log')).write_bytes(data);rows.append(dict(owner=owner,status=os.waitstatus_to_exitcode(status),timeout=b'did not finish within 10 seconds' in data))
(root/'doctor-tty-counterfactual.json').write_text(json.dumps(rows,indent=2)+'\n')
print(rows)
