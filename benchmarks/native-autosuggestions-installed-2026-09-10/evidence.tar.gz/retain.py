from pathlib import Path
import hashlib,json,tarfile,subprocess,platform
root=Path('/code/wsh');out=Path('/var/tmp/wsh-autosuggestions-installed');dest=root/'benchmarks/native-autosuggestions-installed-2026-09-10'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={}
sources=['native/autosuggestions.c','native/startup.c','native/prepare-autosuggestions.py','native/test-installed-autosuggestions.py','native/test-autosuggestions-omz.py','native/test-autosuggestions-complete.py','native/test-autosuggestions-owner.py','native/test-autosuggestions-lifecycle.py','native/test-autosuggestions-bounds.py','native/measure-startup.py','benchmarks/deferred-completion-2026-09-06/run.py','integration/autosuggestions.zsh','build/build-development-bundle.zsh','build/test-native-installation.zsh','build/update-native-lock.py','build/zsh-sources/zsh-cad0d67c-native.json','tests/autosuggestions.zsh','tests/zsh-config-coexistence.zsh']
for n in sources:files['source/'+n]=root/n
for directory in ['correctness','lifecycle','bounds','sanitized-correctness','sanitized-lifecycle','sanitized-bounds','omz-final','contracts-final','measure','startup']:
 for p in (out/directory).rglob('*'):
  if p.is_file() and not p.is_symlink():files[str(p.relative_to(out))]=p
for p in out.iterdir():
 if p.is_file() and p.suffix in ('.log','.json','.txt','.py'):files[p.name]=p
floor=root/'build/portable/autosuggestions-2026-09-10'
checks=Path((floor/'checks-path').read_text().strip().replace('/workspace',str(root),1))
for p in checks.rglob('*'):
 if p.is_file() and not p.is_symlink():files['floor-checks/'+str(p.relative_to(checks))]=p
files['floor-build.log']=floor/'build.log'
normal=out/'bundles/f318bec1a15d5a67ecfa51e640527c235ba89f0b9ae3c8ffadfdadab50e04afb'
control=root/'bundles/e70519fc262f3e93a386d74e0ffbe1696a93f44ceb0ec76b19aaf59c7d85c5dc'
floorbundle=Path((floor/'installation-path').read_text().strip().replace('/workspace',str(root),1))
for name,bundle in [('normal',normal),('control',control),('floor',floorbundle)]:files[name+'-manifest.json']=bundle/'manifest.json'
for n in ('native-autosuggestions.zsh','zsh-autosuggestions.zsh'):
 files['installed/'+n]=normal/'share/wsh/defaults'/n
sdk=out/'sanitized-source'
for p in sdk.rglob('*'):
 if p.is_file() and p.suffix in ('.h','.c','.mdh','.pro','.epro') and '.git' not in p.parts:files['sanitized-sdk/'+str(p.relative_to(sdk))]=p
files['sanitized-sdk/config.modules']=sdk/'config.modules'
archive=dest/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
identity=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'+dirty',host=platform.platform(),selected=True,archive_sha256=sha(archive),files={n:sha(p) for n,p in sorted(files.items())},current_sources={n:sha(root/n) for n in sources},binaries={str(p):sha(p) for p in [normal/'bin/wsh',control/'bin/wsh',floorbundle/'bin/wsh',out/'sanitized-installation/bin/wsh',Path('/var/tmp/wsh-native-adoption/sanitized-installation/bin/wsh')]},rpm_sha256=sha(next((floor/'rpm/RPMS/x86_64').glob('*.rpm'))),trace_mode='off',sanitizer='ASan/UBSan, function sanitizer and leak detection disabled; private incremental installed-layout fixture')
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n');print(len(files),archive.stat().st_size)
