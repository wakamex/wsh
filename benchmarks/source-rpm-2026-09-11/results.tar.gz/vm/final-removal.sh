set -eu
rpm -V wsh
python3 /var/tmp/native_manifest.py verify /usr/libexec/wsh
cat /usr/libexec/wsh/manifest.json
getenforce
chsh -s /bin/bash shellempty
rpm -e wsh
! test -e /usr/bin/wsh
! grep -qxF /usr/bin/wsh /etc/shells
! grep -qxF /bin/wsh /etc/shells
getent passwd recovery
