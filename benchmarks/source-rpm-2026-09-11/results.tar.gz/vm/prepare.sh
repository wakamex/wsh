set -eu
dnf -y install util-linux-user python3 git-core jq
mkdir -p /var/tmp/wsh-package-results
useradd -m -s /bin/bash shellempty
printf 'shellempty:wsh-regression\n' | chpasswd
cat /proc/sys/kernel/random/boot_id
getenforce
