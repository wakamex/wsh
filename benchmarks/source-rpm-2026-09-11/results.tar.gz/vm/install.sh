set -eu
dnf -y install /var/tmp/wsh-*.x86_64.rpm
rpm -V wsh
python3 /var/tmp/native_manifest.py verify /usr/libexec/wsh
/usr/bin/wsh --version
/usr/bin/wsh --wsh-version
grep -qxF /usr/bin/wsh /etc/shells
grep -qxF /bin/wsh /etc/shells
python3 /var/tmp/test-chsh-guest.py
rpm -qa | sort
cat /proc/sys/kernel/random/boot_id
getenforce
