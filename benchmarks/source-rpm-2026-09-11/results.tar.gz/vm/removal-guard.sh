set -eu
if rpm -e wsh; then echo 'unexpected removal'; exit 1; fi
rpm -V wsh
printf 'export WSH_THEME=minimal
' > /home/shellempty/.zshrc
chown shellempty:shellempty /home/shellempty/.zshrc
