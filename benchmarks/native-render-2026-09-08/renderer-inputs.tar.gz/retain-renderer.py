from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-render');out=r/'benchmarks/native-render-2026-09-08'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
names=['native/render.c','native/render.h','native/render-driver.c','native/build-render-driver.zsh','native/theme.c','native/theme.h','native/git.h','native/theme-prototype.c','native/build-theme-prototype.zsh','native/tomlc17-wsh.patch','crates/wsh-runtime/src/render_comparison.rs','crates/wsh-runtime/src/lib.rs','crates/wsh-runtime/src/git.rs','crates/wsh-runtime/Cargo.toml','crates/wsh-runtime/build.rs','Cargo.toml','Cargo.lock','benchmarks/native-render-2026-09-08/plan.md']
for d in ['third_party/tomlc17','third_party/yyjson','themes']:
 names += [str(f.relative_to(r)) for f in (r/d).iterdir() if f.is_file()]
with tarfile.open(out/'renderer-inputs.tar.gz','w:gz') as a:
 for n in sorted(names):a.add(r/n,arcname=n)
 a.add(__file__,arcname='retain-renderer.py')
results=['render-parity-1.json','render-parity-1.log','render-parity-expanded.json','render-parity-expanded.log','render-parity-release.json','render-parity-release.log','render-samples.json','render-summary.json','render-benchmark.log','render-release-build.log','yyjson-configure.log','yyjson-build.log','yyjson-tests.log']
with tarfile.open(out/'renderer-results.tar.gz','w:gz') as a:
 for n in results:a.add(p/n,arcname=n)
binaries={'c':p/'render-driver-release','sanitized':p/'render-driver-sanitized','rust':next(f for f in (p/'rust-target/release/deps').glob('wsh_runtime-*') if f.is_file() and f.stat().st_mode & 0o111 and subprocess.run([str(f),'--list'],capture_output=True).stdout.find(b'native_renderer_matches_rust')>=0)}
meta=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'+dirty',source_inputs={n:sha(r/n) for n in names},binaries={n:dict(path=str(f),sha256=sha(f),size=f.stat().st_size) for n,f in binaries.items()},toolchains={c:subprocess.check_output([c,'--version'],text=True).splitlines()[0] for c in ['cc','clang','cargo','rustc']},host=subprocess.check_output(['uname','-a'],text=True).strip(),cpu=0,trace_mode='none',components='standalone renderer, unchanged schema-1 TOML themes; no shell installation',commands=[
'clang -std=c17 -Wall -Wextra -Werror -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -I/var/tmp/wsh-native-render/theme-sanitized -Ithird_party/yyjson native/theme.c native/render.c native/render-driver.c /var/tmp/wsh-native-render/theme-sanitized/tomlc17.c third_party/yyjson/yyjson.c -o /var/tmp/wsh-native-render/render-driver-sanitized',
'cc -std=c17 -Wall -Wextra -Werror -O2 -I/var/tmp/wsh-native-render/theme-release -Ithird_party/yyjson native/theme.c native/render.c native/render-driver.c /var/tmp/wsh-native-render/theme-release/tomlc17.c third_party/yyjson/yyjson.c -o /var/tmp/wsh-native-render/render-driver-release',
'WSH_RENDER_DRIVER=/var/tmp/wsh-native-render/render-driver-sanitized WSH_RENDER_OUTPUT=/var/tmp/wsh-native-render/render-parity-expanded.json CARGO_TARGET_DIR=/var/tmp/wsh-native-render/rust-target cargo test --offline --locked -p wsh-runtime native_renderer_matches_rust -- --ignored --nocapture',
'WSH_RENDER_DRIVER=/var/tmp/wsh-native-render/render-driver-release WSH_RENDER_OUTPUT=/var/tmp/wsh-native-render/render-parity-release.json CARGO_TARGET_DIR=/var/tmp/wsh-native-render/rust-target cargo test --offline --locked --release -p wsh-runtime native_renderer_matches_rust -- --ignored --nocapture',
'WSH_RENDER_BENCHMARK=1 WSH_RENDER_DRIVER=/var/tmp/wsh-native-render/render-driver-release WSH_RENDER_OUTPUT=/var/tmp/wsh-native-render/render-samples.json CARGO_TARGET_DIR=/var/tmp/wsh-native-render/rust-target taskset -c 0 cargo test --offline --locked --release -p wsh-runtime native_renderer_matches_rust -- --ignored --nocapture',
'cmake -S /var/tmp/wsh-native-render/yyjson -B /var/tmp/wsh-native-render/yyjson-sanitized -DCMAKE_C_COMPILER=clang -DCMAKE_BUILD_TYPE=Debug -DYYJSON_BUILD_TESTS=ON -DCMAKE_C_FLAGS="-fsanitize=address,undefined -fno-omit-frame-pointer"',
'cmake --build /var/tmp/wsh-native-render/yyjson-sanitized -j8',
'ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1 ctest --test-dir /var/tmp/wsh-native-render/yyjson-sanitized --output-on-failure'])
(out/'renderer-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
files=['renderer-report.md','renderer-metadata.json','renderer-inputs.tar.gz','renderer-results.tar.gz']
(out/'renderer-SHA256SUMS').write_text(''.join(sha(out/n)+'  '+str((out/n).relative_to(r))+'\n' for n in files))
