#include "tomlc17.h"
#include <inttypes.h>
#include <stdio.h>
int main(void) {
    toml_option_t options = toml_default_option();
    options.check_utf8 = true;
    options.allow_uint64 = true;
    toml_set_option(options);
    toml_result_t result = toml_parse_file(stdin);
    if (!result.ok) { fprintf(stderr, "%s\n", result.errmsg); toml_free(result); return 1; }
    toml_datum_t value = toml_get(result.toptab, "value");
    if (value.type == TOML_UINT64) printf("%" PRIu64 "\n", value.u.uint64);
    else if (value.type == TOML_INT64) printf("%" PRId64 "\n", value.u.int64);
    else { toml_free(result); return 2; }
    toml_free(result);
    return 0;
}
