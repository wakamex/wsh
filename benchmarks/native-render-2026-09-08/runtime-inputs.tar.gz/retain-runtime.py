from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-render');out=r/'benchmarks/native-render-2026-09-08'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
names=['native/'+n for n in ['runtime.c','runtime-json.h','runtime-trace.c','runtime-trace.h','git.c','git.h','render.c','render.h','theme.c','theme.h','theme-prototype.c','tomlc17-wsh.patch','build-runtime-prototype.zsh','build-theme-prototype.zsh','test-runtime-protocol.py','test-runtime-lifecycle.py','test-runtime-nul-path.py','test-git-matrix.py','test-git-adversarial.py','test-git-output.py','test-git-pipe-lifetime.py','prepare-runtime-comparison.py','check-installation.py','measure-git.py','measure-startup.py']]
names += ['benchmarks/'+n for n in ['benchmark-runtime-memory.zsh','benchmark-trace-overhead.zsh','native-render-2026-09-08/plan.md']]
names += ['tests/runtime-pty.zsh','integration/integration.zsh','Cargo.lock']
for d in ['third_party/tomlc17','third_party/yyjson','themes']:
 names += [str(f.relative_to(r)) for f in (r/d).iterdir() if f.is_file()]
with tarfile.open(out/'runtime-inputs.tar.gz','w:gz') as a:
 for n in sorted(names):a.add(r/n,arcname=n)
 a.add(__file__,arcname='retain-runtime.py')
with tarfile.open(out/'runtime-results.tar.gz','w:gz') as a:
 for f in sorted(p.iterdir()):
  if f.is_file() and f.name.startswith('runtime-') and f.suffix in ['.json','.log','.tsv']:a.add(f,arcname=f.name)
 for directory in ['runtime-protocol-1','runtime-protocol-2','runtime-protocol-final','runtime-protocol-release','runtime-lifecycle-1','runtime-lifecycle-final','runtime-git-matrix-1','runtime-git-adversarial-1','runtime-pipe-cancel','runtime-pipe-timeout','runtime-output','runtime-contracts','runtime-contracts-final','runtime-collection','runtime-readiness']:
  for f in sorted((p/directory).iterdir()):
   if f.is_file() and not f.is_symlink() and (f.suffix in ['.json','.log','.zsh','.tsv','.jsonl'] or f.name in ['stdout','stderr']):a.add(f,arcname=str(f.relative_to(p)))
 comparison=json.loads((p/'runtime-installations-final.json').read_text())
 for name,v in comparison['variants'].items():a.add(Path(v['path'])/'manifest.json',arcname='installations/'+name+'-manifest.json')
binaries={'rust':Path('/var/tmp/wsh-native-git/rust-target/release/wsh-runtime'),'c':p/'runtime-release-final/wsh-runtime','sanitized':p/'runtime-sanitized-final/wsh-runtime','initial_sanitized':p/'runtime-sanitized/wsh-runtime','ordered_trace_sanitized':p/'runtime-sanitized-2/wsh-runtime'}
meta=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'+dirty',source_inputs={n:sha(r/n) for n in names},source_sizes={n:dict(bytes=(r/n).stat().st_size,lines=len((r/n).read_bytes().splitlines())) for n in names if n.endswith(('.c','.h','.patch'))},binaries={n:dict(path=str(f),sha256=sha(f),size=f.stat().st_size) for n,f in binaries.items()},comparison=comparison,native_binary_sha256=sha(Path(comparison['variants']['c']['path'])/'bin/wsh'),toolchains={c:subprocess.check_output([c,'--version'],text=True).splitlines()[0] for c in ['cc','clang','cargo','rustc']},host=subprocess.check_output(['uname','-a'],text=True).strip(),cpu=0,trace_mode='matched off/on only in trace experiment',dependencies=subprocess.check_output(['ldd',binaries['c']],text=True),commands=[])
meta['zlib']=dict(path=str(Path('/usr/lib64/libz.so.1').resolve()),sha256=sha(Path('/usr/lib64/libz.so.1').resolve()),size=Path('/usr/lib64/libz.so.1').stat().st_size)
meta['commands']=[
"CC=clang CFLAGS='-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer' native/build-runtime-prototype.zsh /var/tmp/wsh-native-render/runtime-sanitized-final",
'native/build-runtime-prototype.zsh /var/tmp/wsh-native-render/runtime-release-final',
'ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1 python3 native/test-runtime-protocol.py /var/tmp/wsh-native-git/rust-target/release/wsh-runtime /var/tmp/wsh-native-render/runtime-sanitized-final/wsh-runtime /var/tmp/wsh-native-render/runtime-protocol-final',
'ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1 python3 native/test-runtime-lifecycle.py /var/tmp/wsh-native-render/runtime-sanitized-final/wsh-runtime /var/tmp/wsh-native-render/runtime-lifecycle-final',
'python3 native/test-runtime-protocol.py /var/tmp/wsh-native-git/rust-target/release/wsh-runtime /var/tmp/wsh-native-render/runtime-release-final/wsh-runtime /var/tmp/wsh-native-render/runtime-protocol-release',
'python3 native/test-runtime-nul-path.py /var/tmp/wsh-native-git/rust-target/release/wsh-runtime /var/tmp/wsh-native-render/runtime-release-final/wsh-runtime /var/tmp/wsh-native-render/runtime-nul-path.json',
'ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1 python3 native/test-git-matrix.py /var/tmp/wsh-native-git/rust-target/release/wsh-runtime /var/tmp/wsh-native-render/runtime-sanitized/wsh-runtime /var/tmp/wsh-native-render/runtime-git-matrix-1',
'ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1 python3 native/test-git-adversarial.py /var/tmp/wsh-native-render/runtime-sanitized/wsh-runtime /var/tmp/wsh-native-render/runtime-git-adversarial-1',
'ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1 python3 native/test-git-output.py /var/tmp/wsh-native-render/runtime-sanitized-2/wsh-runtime /var/tmp/wsh-native-render/runtime-output',
'ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1 python3 native/test-git-pipe-lifetime.py /var/tmp/wsh-native-render/runtime-sanitized-2/wsh-runtime /var/tmp/wsh-native-render/runtime-pipe-cancel --require-bounded',
'ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1 python3 native/test-git-pipe-lifetime.py /var/tmp/wsh-native-render/runtime-sanitized-final/wsh-runtime /var/tmp/wsh-native-render/runtime-pipe-timeout --timeout --require-bounded',
'python3 native/prepare-runtime-comparison.py /var/tmp/wsh-native-git/installations/0e52c10a9a6c389ef5afd48eb9c950a3b7bdf3d0c38206ae726b1289aeb15a53 /var/tmp/wsh-native-git/rust-target/release/wsh-runtime /var/tmp/wsh-native-render/runtime-release-final/wsh-runtime /var/tmp/wsh-native-render/runtime-installations-final',
'python3 native/check-installation.py '+comparison['variants']['c']['path']+' /var/tmp/wsh-native-render/runtime-contracts-final',
'WSH_TEST_RUNTIME=/var/tmp/wsh-native-render/runtime-release-final/wsh-runtime ./tests/runtime-pty.zsh',
'python3 native/measure-git.py /var/tmp/wsh-native-git/rust-target/release/wsh-runtime /var/tmp/wsh-native-render/runtime-release-final/wsh-runtime /var/tmp/wsh-native-render/runtime-collection',
'python3 native/measure-startup.py '+comparison['variants']['rust']['path']+' '+comparison['variants']['c']['path']+' /var/tmp/wsh-native-render/runtime-readiness',
'WSH_THEME=minimal WSH_MEMORY_RUNTIME=/var/tmp/wsh-native-render/runtime-release-final/wsh-runtime taskset -c 0 build/out/zsh-cad0d67c-wsh2/bin/zsh benchmarks/benchmark-runtime-memory.zsh',
'WSH_TRACE_RUNTIME=/var/tmp/wsh-native-render/runtime-release-final/wsh-runtime taskset -c 0 build/out/zsh-cad0d67c-wsh2/bin/zsh benchmarks/benchmark-trace-overhead.zsh']
(out/'runtime-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
files=['runtime-report.md','runtime-metadata.json','runtime-inputs.tar.gz','runtime-results.tar.gz']
(out/'runtime-SHA256SUMS').write_text(''.join(sha(out/n)+'  '+str((out/n).relative_to(r))+'\n' for n in files))
