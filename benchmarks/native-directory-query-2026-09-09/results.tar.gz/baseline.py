import json,subprocess,os
from pathlib import Path
p=Path('/var/tmp/wsh-native-directory');b=Path('/var/tmp/wsh-native-render/runtime-installations-final/ba2599f9f670b8ced903bb91d98b23db04a2ca8ef0ca0d7c353a575202006ab2/bin/wsh')
script=p/'baseline.zsh';script.write_text('source /code/wsh/third_party/zsh-z/z.plugin.zsh\nzmodload zsh/datetime\nzshz -e project >/dev/null\nrepeat 50; do\n start=$EPOCHREALTIME\n zshz -e project >/dev/null\n print -r -- $(( (EPOCHREALTIME-start)*1000 ))\ndone\n')
summary={}
for count in [100,1000]:
 home=p/str(count);home.mkdir();entries=[]
 for i in range(count):
  directory=home/f'project-{i:04}';directory.mkdir();entries.append(str(directory)+f'|{i%30+1}|1700000000\n')
 (home/'db').write_text(''.join(entries))
 r=subprocess.run([b,'-df',script],env=dict(PATH='/usr/bin:/bin',HOME=str(home),ZSHZ_DATA=str(home/'db'),LC_ALL='C.UTF-8'),capture_output=True,check=True,preexec_fn=lambda:os.sched_setaffinity(0,{0}))
 (p/f'baseline-{count}.stdout').write_bytes(r.stdout);(p/f'baseline-{count}.stderr').write_bytes(r.stderr);assert not r.stderr
 rows=list(map(float,r.stdout.split()));assert len(rows)==50;summary[count]=dict(samples_ms=rows,median_ms=sorted(rows)[24])
(p/'baseline.json').write_text(json.dumps(summary,indent=2)+'\n');print({n:r['median_ms'] for n,r in summary.items()})
