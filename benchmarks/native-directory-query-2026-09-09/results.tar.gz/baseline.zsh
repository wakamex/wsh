source /code/wsh/third_party/zsh-z/z.plugin.zsh
zmodload zsh/datetime
zshz -e project >/dev/null
repeat 50; do
 start=$EPOCHREALTIME
 zshz -e project >/dev/null
 print -r -- $(( (EPOCHREALTIME-start)*1000 ))
done
