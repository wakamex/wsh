module_path=($1 $module_path)
zmodload wshdirectory || exit 2
source $2
zshz -e project
