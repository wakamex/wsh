module_path=($1 $module_path)
zmodload wshdirectory || exit 2
zmodload zsh/datetime
control=$2/control.zsh candidate=$2/candidate.zsh
source $control
zshz -e project >/dev/null
source $candidate
zshz -e project >/dev/null
typeset -a rows
for ((i=0;i<50;i++)); do
 owners=(control candidate)
 ((i % 2)) && owners=(candidate control)
 for owner in $owners; do
  source ${(P)owner}
  start=$EPOCHREALTIME
  zshz -e project >/dev/null
  elapsed=$(( (EPOCHREALTIME-start)*1000 ))
  rows+=("$i $owner $elapsed")
 done
done
print -rl -- $rows
