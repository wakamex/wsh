from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path('/code/wsh');p=Path('/var/tmp/wsh-native-directory');out=r/'benchmarks/native-directory-query-2026-09-09';source=Path('/var/tmp/wsh-native-tools/source-sanitized');bundle=Path('/var/tmp/wsh-native-render/runtime-installations-final/ba2599f9f670b8ced903bb91d98b23db04a2ca8ef0ca0d7c353a575202006ab2')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
names=['native/'+n for n in ['directory-query-prototype.c','prepare-directory-query.py','test-directory-query.py','measure-directory-query.py']]+['third_party/zsh-z/z.plugin.zsh','benchmarks/native-directory-query-2026-09-09/plan.md','build/zsh-sources/zsh-cad0d67c-native.json']
headers=[f for f in source.rglob('*') if f.is_file() and f.suffix in ['.h','.epro','.mdh']]
with tarfile.open(out/'inputs.tar.gz','w:gz') as a:
 for n in names:a.add(r/n,arcname=n)
 for f in headers:a.add(f,arcname='configured-zsh/'+str(f.relative_to(source)))
 a.add(__file__,arcname='retain.py')
with tarfile.open(out/'results.tar.gz','w:gz') as a:
 for f in sorted(p.rglob('*')):
  if f.is_file() and f.suffix!='.so' and f.name!='retain.py':a.add(f,arcname=str(f.relative_to(p)))
 a.add(bundle/'manifest.json',arcname='native-manifest.json')
meta=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'+dirty',source_inputs={n:sha(r/n) for n in names},configured_headers={str(f.relative_to(source)):sha(f) for f in headers},bundle_sha256=sha(bundle/'manifest.json'),binaries={str(f):dict(sha256=sha(f),size=f.stat().st_size) for f in [p/'wshdirectory.so',p/'sanitized/wshdirectory.so',bundle/'bin/wsh',source/'Src/zsh']},host=subprocess.check_output(['uname','-a'],text=True).strip(),cc=subprocess.check_output(['cc','--version'],text=True).splitlines()[0],clang=subprocess.check_output(['clang','--version'],text=True).splitlines()[0],commands=[
'cc -std=c11 -Wall -Wextra -Werror -O2 -fPIC -shared -I/var/tmp/wsh-native-tools/source-sanitized/Src -I/var/tmp/wsh-native-tools/source-sanitized native/directory-query-prototype.c -o /var/tmp/wsh-native-directory/wshdirectory.so',
'clang -std=c11 -Wall -Wextra -Werror -O1 -g -fsanitize=address,undefined -fno-sanitize=function -fno-omit-frame-pointer -fPIC -shared -I/var/tmp/wsh-native-tools/source-sanitized/Src -I/var/tmp/wsh-native-tools/source-sanitized native/directory-query-prototype.c -o /var/tmp/wsh-native-directory/sanitized/wshdirectory.so',
'python3 native/prepare-directory-query.py /var/tmp/wsh-native-directory/prototype',
f'python3 native/test-directory-query.py {bundle}/bin/wsh {p} {p}/prototype {p}/parity-final',
f'ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 python3 native/test-directory-query.py {source}/Src/zsh {p}/sanitized {p}/prototype {p}/parity-sanitized-final',
f'python3 native/measure-directory-query.py {bundle}/bin/wsh {p} {p}/prototype {p}/timing'])
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(out/'SHA256SUMS').write_text(''.join(sha(out/n)+'  '+str((out/n).relative_to(r))+'\n' for n in ['report.md','metadata.json','inputs.tar.gz','results.tar.gz']))
