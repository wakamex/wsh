# usage: zsh -f bench.zsh BUNDLE_ROOT ZFILE AUTOFILE MISSFILE ROUNDS
builtin emulate -L zsh -o no_aliases
WSH_BUNDLE_ROOT=${1:A}
source $WSH_BUNDLE_ROOT/share/wsh/defaults/plugin-recognition.zsh
_wsh_plugin_git_recognized() { return 1 }   # isolate the catalog path
zmodload zsh/datetime
local -A cases=(z_hit $2 auto_hit $3 z_miss $4)
local name t0 i
for name in z_hit auto_hit z_miss; do
  local -a s=()
  for i in {1..$5}; do
    t0=$EPOCHREALTIME
    if [[ $name == auto_hit ]]; then _wsh_plugin_recognized autosuggestions $cases[$name]; else _wsh_plugin_recognized directory $cases[$name]; fi
    s+=$(( (EPOCHREALTIME - t0) * 1e6 ))
  done
  s=(${(on)s})
  printf '%-9s median %7.1f us  p95 %7.1f us\n' $name $s[$(( $5/2 ))] $s[$(( $5*95/100 ))]
done
