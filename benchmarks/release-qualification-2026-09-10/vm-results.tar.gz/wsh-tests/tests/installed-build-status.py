#!/usr/bin/env python3
"""Compile the real native dispatcher with both production-generated headers."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

# The canonical installation suite supplies its freshly built installation.
if len(sys.argv) == 2:
    bundle = Path(sys.argv[1]).resolve()
    manifest = json.loads((bundle/'manifest.json').read_text())
    expected = 'release build' if manifest['status'] == 'release' else 'unsigned development artifact'
    with tempfile.TemporaryDirectory(prefix='wsh-installed-version-') as tmp:
        home = Path(tmp)
        (home/'.zshenv').write_text('print STARTUP_LEAK; exit 91\n')
        (home/'manifest.json').write_text('{broken')
        env = dict(PATH='/usr/bin:/bin', HOME=tmp, ZDOTDIR=tmp, WSH_BUNDLE_STATUS='invalid', WSH_STATE_ROOT=tmp)
        def run(binary, args):
            return subprocess.run([binary,*args], cwd=home, env=env, capture_output=True, text=True, timeout=10)
        executable = bundle/'bin/wsh'
        result = run(executable,['--wsh-version'])
        assert result.returncode == 0 and not result.stderr
        assert result.stdout.splitlines()[0] == f"wsh {manifest['version']} ({expected})"
        assert 'STARTUP_LEAK' not in result.stdout
        moved = home/'relocated-wsh'
        shutil.copyfile(executable,moved)
        moved.chmod(0o755)
        assert run(moved,['--wsh-version']).stdout == result.stdout
        assert run(executable,['--wsh-version','extra']).returncode == 2
        assert run(executable,['--wsh-help']).returncode == 0
        assert run(executable,['--version']).stdout.startswith('zsh ')
        (home/'.zshenv').write_text('')
        (home/'version').write_text('print -r -- "$1"; exit 23\n')
        result = run(executable,['-f','version','literal argument'])
        assert result.returncode == 23 and result.stdout == 'literal argument\n'
        result = run(executable,['-dfc','print -r -- NATIVE_SHELL_OK'])
        assert result.returncode == 0 and result.stdout == 'NATIVE_SHELL_OK\n'
    print('PASS: installed label, missing resources, corrupt metadata, startup isolation and native shell arguments')
