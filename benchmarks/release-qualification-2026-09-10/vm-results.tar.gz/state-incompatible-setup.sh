set -e
chmod 644 /home/shellempty/.local/share/wsh/bundle-state.json; printf '{"schema_version":999}' > /home/shellempty/.local/share/wsh/bundle-state.json
