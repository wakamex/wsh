set -euo pipefail
cat /etc/os-release
uname -a
getenforce
[ "$(getenforce)" = Enforcing ]
! rpm -q wsh
sha256sum /var/tmp/wsh-qualification.rpm
dnf -y install util-linux util-linux-user zsh policycoreutils-python-utils /var/tmp/wsh-qualification.rpm
rpm -V wsh
rpm -q wsh
/usr/bin/wsh --wsh-version
/usr/bin/wsh --version
python3 /var/tmp/wsh-tests/build/native_manifest.py verify /usr/libexec/wsh
python3 /var/tmp/wsh-tests/tests/installed-build-status.py /usr/libexec/wsh
for account in shellempty shelltest shellsecond migrated; do
    useradd -m -s /usr/bin/wsh "$account"
    printf '%s:wsh-regression\n' "$account" | chpasswd
done
semanage login -a -s user_u shellsecond
mkdir -p /var/tmp/wsh-package-results
python3 /var/tmp/wsh-tests/packaging/test-chsh-guest.py
printf 'WSH_THEME=minimal\n' > /home/shelltest/.zshrc
chown shelltest:shelltest /home/shelltest/.zshrc
restorecon -RF /home
cat /proc/sys/kernel/random/boot_id
getent passwd recovery shellempty shelltest shellsecond migrated
