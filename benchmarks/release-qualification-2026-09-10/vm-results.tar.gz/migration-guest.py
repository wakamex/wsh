from pathlib import Path
import hashlib,json,os,pwd,subprocess

def call(args,**kwargs):
    return subprocess.run(args,check=True,capture_output=True,text=True,**kwargs).stdout
subprocess.run(['python3','/var/tmp/wsh-tests/native/test-migration.py','/usr/libexec/wsh','/var/tmp/wsh-legacy','/var/tmp/wsh-package-results/private-migration'],check=True)
home=Path('/home/migrated'); old=home/'.local/bin/wsh'; old.parent.mkdir(parents=True)
old.write_bytes(Path('/var/tmp/wsh-legacy').read_bytes());old.chmod(0o755)
state=home/'.local/share/wsh/bundle-state.json';state.parent.mkdir(parents=True);state.write_text('{broken legacy state\n')
(home/'.zshrc').write_text('WSH_THEME=minimal\n')
(home/'.zsh_history').write_text(': 1:0;echo preserved\n')
call(['chown','-R','migrated:migrated',str(home)])
call(['restorecon','-RF',str(home)])
call(['chsh','-s',str(old),'migrated'])
before={str(p.relative_to(home)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (home/'.zshrc',home/'.zsh_history',state)}
env=dict(os.environ,HOME=str(home),ZDOTDIR=str(home),PATH=str(old.parent)+':/usr/bin:/bin',TERM='xterm-256color')
def as_user(args):return call(['runuser','-u','migrated','--',*args],env=env)
assert as_user(['/usr/bin/wsh','-dfc','whence -p wsh']).strip()==str(old)
assert '(release build)' in as_user(['/usr/bin/wsh','--wsh-version'])
assert as_user(['/usr/bin/wsh','-dlc','print -r -- NATIVE_LOGIN_OK']).strip()=='NATIVE_LOGIN_OK'
call(['chsh','-s','/usr/bin/wsh','migrated'])
assert pwd.getpwnam('migrated').pw_shell=='/usr/bin/wsh'
old.rename(old.with_name('wsh-legacy'))
assert as_user(['/usr/bin/wsh','-dfc','rehash; whence -p wsh']).strip()=='/usr/bin/wsh'
assert as_user([str(old.with_name('wsh-legacy')),'--version']).strip()=='wsh 0.3.0'
after={name:hashlib.sha256((home/name).read_bytes()).hexdigest() for name in before}
assert before==after
Path('/var/tmp/wsh-package-results/account-migration.json').write_text(json.dumps(dict(passed=True,legacy_version='0.3.0',files=before),indent=2)+'\n')
print('PASS: real legacy launcher, account shell transition, PATH retirement and preserved user files')
