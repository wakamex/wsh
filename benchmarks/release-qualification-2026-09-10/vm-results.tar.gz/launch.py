from pathlib import Path
import json, subprocess
w=Path(__file__).parent
command=['systemd-run','--user','--unit=wsh-release-13cb60d-vm','--property=Restart=no','/usr/bin/qemu-system-x86_64','-enable-kvm','-cpu','host','-smp','4','-m','4096','-drive',f'file={w}/guest.qcow2,if=virtio,format=qcow2','-drive',f'file={w}/seed.iso,media=cdrom,readonly=on','-netdev','user,id=net0,hostfwd=tcp:127.0.0.1:22284-:22','-device','virtio-net-pci,netdev=net0','-display','none','-serial',f'unix:{w}/serial.sock,server=on,wait=off','-monitor',f'unix:{w}/monitor.sock,server=on,wait=off']
(w/'launch-command.json').write_text(json.dumps(command,indent=2)+'\n')
subprocess.run(command,check=True)
