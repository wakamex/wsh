set -e
python3 /var/tmp/migration-guest.py
