set -e
if [ -f /var/tmp/wsh-runtime-backup ]; then mv -f /var/tmp/wsh-runtime-backup /usr/libexec/wsh/bin/wsh-runtime; fi
chmod 755 /usr/libexec/wsh/bin/wsh-runtime
if [ -d /var/tmp/wsh-integration-backup ]; then mv /var/tmp/wsh-integration-backup /usr/libexec/wsh/share/wsh; fi
rm -f /home/shellempty/.zshrc
restorecon -R /usr/libexec/wsh
rpm -V wsh
