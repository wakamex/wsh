set -e
rpm -V wsh
python3 /var/tmp/wsh-tests/build/native_manifest.py verify /usr/libexec/wsh
getenforce
ls -Z /usr/bin/wsh /usr/libexec/wsh/bin/wsh
journalctl -b --no-pager -u serial-getty@ttyS0 > /var/tmp/wsh-package-results/getty-journal.log
cp /usr/libexec/wsh/manifest.json /var/tmp/wsh-package-results/installed-manifest.json
chown -R recovery:recovery /var/tmp/wsh-package-results
