set -e
cat /proc/sys/kernel/random/boot_id > /var/tmp/wsh-package-results/boot-after
! cmp /var/tmp/wsh-package-results/boot-before /var/tmp/wsh-package-results/boot-after
[ "$(getenforce)" = Enforcing ]
rpm -V wsh
/usr/bin/wsh --wsh-version
