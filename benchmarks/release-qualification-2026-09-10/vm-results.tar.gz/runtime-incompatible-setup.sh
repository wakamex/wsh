set -e
mv /usr/libexec/wsh/bin/wsh-runtime /var/tmp/wsh-runtime-backup; printf '#!/bin/sh\nexit 64\n' > /usr/libexec/wsh/bin/wsh-runtime; chmod 755 /usr/libexec/wsh/bin/wsh-runtime; restorecon /usr/libexec/wsh/bin/wsh-runtime
