systemctl status serial-getty@ttyS0 --no-pager
journalctl -b -u serial-getty@ttyS0 --no-pager -n 35
journalctl -b --no-pager | grep -E 'segfault|dumped core|wsh|python3' | tail -20
