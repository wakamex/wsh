ps -eo pid,ppid,pgid,sid,tpgid,stat,args | grep -E 'ttyS0|python3 -c|/bin/wsh'
stty -F /dev/ttyS0 -a
