set -e
rpm -V wsh
sha256sum /usr/libexec/wsh/manifest.json /var/tmp/wsh-qualification.rpm /usr/libexec/wsh/bin/wsh
cat /proc/sys/kernel/random/boot_id > /var/tmp/wsh-package-results/boot-before
cat /var/tmp/wsh-package-results/boot-before
getenforce
id -Z
rpm -qa | sort > /var/tmp/wsh-package-results/packages.txt
getent passwd recovery shellempty shelltest shellsecond migrated
