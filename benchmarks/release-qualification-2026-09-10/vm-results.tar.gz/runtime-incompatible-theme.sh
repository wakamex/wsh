printf 'WSH_THEME=minimal\n' > /home/shellempty/.zshrc; chown shellempty:shellempty /home/shellempty/.zshrc
