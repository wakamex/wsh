from pathlib import Path
import shutil,time
root=Path('/var/tmp/wsh-release-qualification-13cb60d')
for unused in range(1800):
    for worker in ('a','b'):
        src=root/f'source-{worker}/build/portable/glibc-2.28'
        dest=root/f'details-{worker}'
        if src.exists():
            dest.mkdir(exist_ok=True)
            for name in ('build.log','installation-path','checks-path'):
                try: shutil.copyfile(src/name,dest/name)
                except FileNotFoundError: pass
            for path in src.glob('checks.*'):
                try: shutil.copytree(path,dest/path.name,dirs_exist_ok=True)
                except (FileNotFoundError,shutil.Error): pass
    if (root/'SHA256SUMS').exists(): break
    time.sleep(2)
