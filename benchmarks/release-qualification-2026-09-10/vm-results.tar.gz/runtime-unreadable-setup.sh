set -e
chmod 000 /usr/libexec/wsh/bin/wsh-runtime
