set -e
python3 /var/tmp/migration-guest.py
systemctl restart serial-getty@ttyS0
