set -e
systemctl poweroff
