set -e
rpm -V wsh
sha256sum /usr/libexec/wsh/manifest.json /var/tmp/wsh-qualification.rpm /usr/libexec/wsh/bin/wsh
cat /proc/sys/kernel/random/boot_id > /var/tmp/wsh-package-results/boot-before
cat /var/tmp/wsh-package-results/boot-before
getenforce
rpm -qa | sort > /var/tmp/wsh-package-results/packages.txt
getent passwd recovery shellempty shelltest shellsecond migrated
if rpm -e wsh > /var/tmp/wsh-package-results/removal-guard.log 2>&1; then
  echo 'FAIL: removal accepted while accounts use Wsh'
  exit 1
fi
grep -F 'Wsh is still a local account shell' /var/tmp/wsh-package-results/removal-guard.log
rpm -V wsh
systemctl reboot
