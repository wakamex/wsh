set -e
stat -c '%a %n' /var/tmp/wsh-legacy
chmod 755 /var/tmp/wsh-legacy
/var/tmp/wsh-legacy --version
