ps -eo pid,ppid,pgid,sid,tpgid,stat,args | grep -E 'python|wsh|login'
stty -F /dev/ttyS0 -a
