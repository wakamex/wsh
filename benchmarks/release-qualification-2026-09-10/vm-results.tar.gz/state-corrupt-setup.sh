set -e
mkdir -p /home/shellempty/.local/share/wsh; printf '{broken' > /home/shellempty/.local/share/wsh/bundle-state.json
