set -e
mv /usr/libexec/wsh/share/wsh /var/tmp/wsh-integration-backup
