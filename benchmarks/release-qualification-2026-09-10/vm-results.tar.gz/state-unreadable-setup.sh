set -e
chmod 000 /home/shellempty/.local/share/wsh/bundle-state.json
