set -e
mv /usr/libexec/wsh/bin/wsh-runtime /var/tmp/wsh-runtime-backup
