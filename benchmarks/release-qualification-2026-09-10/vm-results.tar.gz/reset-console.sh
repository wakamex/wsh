set -e
systemctl restart serial-getty@ttyS0
