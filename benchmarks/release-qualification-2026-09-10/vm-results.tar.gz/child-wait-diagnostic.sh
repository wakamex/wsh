ps -eo pid,ppid,pgid,tpgid,stat,wchan:30,args | grep -E 'python3 -c|wsh|login'
