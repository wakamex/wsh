import subprocess,sys,time,json
p=subprocess.Popen(json.loads(sys.argv[1]),stdin=subprocess.PIPE,stdout=subprocess.PIPE)
assert b"ready" in p.stdout.readline()
p.stdin.write(bytes.fromhex(sys.argv[2]));p.stdin.flush()
open(sys.argv[3],"w").write(str(p.pid))
time.sleep(30)
