unsetopt globalrcs
WSH_SECRET=never-record-this-secret
sleep 0.05
