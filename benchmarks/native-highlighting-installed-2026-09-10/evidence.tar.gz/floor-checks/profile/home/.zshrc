PROMPT="NATIVE> "
WSH_THEME=minimal
ZSHZ_DATA=$HOME/jump-data
wsh_profile_slow() { sleep 0.02; }
wsh_profile_slow
zmodload zsh/zle
autoload -Uz add-zle-hook-widget
wsh_profile_editor_delay() { sleep 0.08; }
add-zle-hook-widget zle-line-init wsh_profile_editor_delay
