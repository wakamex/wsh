source /workspace/build/portable/highlighting-full-2026-09-10/checks.VGdlI0/highlighting/fixture/candidate/zsh-syntax-highlighting.zsh
_run() {
 local BUFFER='' PREBUFFER='' WIDGET='' CONTEXT=''
 local -a region_highlight
 local -A zsyh_user_options=("${(kv)options[@]}")
 emulate -L zsh
 BUFFER='echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; echo hello; '
 integer phase i
 for phase in 1 2 3; do
  for (( i=0; i<2000; i++ )); do
   region_highlight=()
   _zsh_highlight_highlighter_main_paint
  done
  print -r -- READY
  read -r REPLY
 done
}
_run
