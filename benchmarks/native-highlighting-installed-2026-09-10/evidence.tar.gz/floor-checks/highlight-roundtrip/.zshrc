
PROMPT='ROUNDTRIP> '
_probe() {
 local value
 for value in '0 1 fg=green memo=probe' '0 1 none memo=probe' '0 1 none, memo=probe' '0 1 none,layer=4 memo=probe' '0 1 bold,none memo=probe'; do
  region_highlight=("$value")
  local first=$region_highlight[1]
  region_highlight=("${region_highlight[@]}")
  print -nr -- $'\x1eROW:'"$value|$first|$region_highlight[1]"$'\x1f'
 done
 region_highlight=()
 print -nr -- $'\x1eDONE\x1f'
}
zle -N _probe
bindkey '^T' _probe
