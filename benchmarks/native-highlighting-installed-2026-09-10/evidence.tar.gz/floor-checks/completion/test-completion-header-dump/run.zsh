fpath=($1)
[[ -d $HOME/extra ]] && fpath=($HOME/extra $fpath)
if [[ $2 == control ]]; then
  functions[compinit]="$(< $3)"
  compinit -i -d "$HOME/dump" || exit 2
else
  autoload -Uz compinit
  compinit -i -d "$HOME/dump" || exit 2
fi
typeset -p _comps _services _patcomps _postpatcomps _compautos
bindkey '^I'
