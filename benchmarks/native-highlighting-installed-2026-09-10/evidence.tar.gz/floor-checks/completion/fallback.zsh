fpath=($1)
functions[compinit]="$(< $2)"
compinit -i -D || exit 1
[[ $_comps[git] == _git ]] || exit 2
