fpath=("$1" "$2")
TRAPDEBUG() {
  if [[ ${funcstack[2]} == _wsh_completion_autoload ]]; then
    _i_line=()
    trap_ran=yes
  fi
}
autoload -Uz compinit
compinit -i -D || exit 1
[[ $trap_ran == yes && $_compautos[_probe] == -U ]] || exit 2
