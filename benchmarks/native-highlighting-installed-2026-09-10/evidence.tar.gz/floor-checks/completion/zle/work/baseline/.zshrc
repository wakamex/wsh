
PROMPT='COMP> '
HISTFILE=$HOME/history
SAVEHIST=0
ZSHZ_DATA=$HOME/jump-data
[[ $COMP_CASE == candidate-vi ]] && bindkey -v
if [[ $COMP_CASE == eager-* || $COMP_CASE == existing ]]; then
  autoload -Uz compinit
  compinit -i -d "$HOME/.zcompdump"
fi
if [[ $COMP_CASE == custom-tab ]]; then
  _custom_tab() { BUFFER+='CUSTOMTAB'; CURSOR=$#BUFFER; }
  zle -N _custom_tab
  bindkey '^I' _custom_tab
fi
print -s 'print -r -- DEFER_AUTOSUGGEST_COMPLETE'
_state() {
  print -nr -- $'\x1eSTATE:'"$POSTDISPLAY|${#region_highlight}|${+functions[compdef]}|${_DEFERRED_RUNS:-0}|$WSH_AUTOSUGGESTIONS_OWNER|$WSH_SYNTAX_HIGHLIGHTING_OWNER|${_comps[z]:-}|$(bindkey '^I')"$'\x1f'
}
_custom() { BUFFER+='CUSTOM'; CURSOR=$#BUFFER; }
zle -N _state
zle -N _custom
bindkey '^T' _state
bindkey '^X' _custom
_capture() {
  print -nr -- $'\x1eBUFFER:'"$BUFFER"$'\x1f'
  BUFFER=''
  POSTDISPLAY=''
  CURSOR=0
  zle redisplay
}
zle -N _capture
bindkey '^G' _capture

if [[ $COMP_CASE == control-* ]]; then
 functions[compinit]="$(< $WSH_COMPINIT_PROTOTYPE)"
 compinit -i -d "$HOME/dump"
elif [[ $COMP_CASE == candidate-* ]]; then
 autoload -Uz compinit
 compinit -i -d "$HOME/dump"
fi
