fpath=($HOME/'first [x]' $HOME/second $1)
if [[ $2 == candidate ]]; then functions[compinit]="$(< $3)"; else autoload -Uz compinit; fi
if [[ $4 == refuse ]]; then compinit -D < /dev/null; else compinit -i -D; fi
print -r -- "STATUS:$?"
typeset -p _comps _services _patcomps _postpatcomps _compautos
zle -l
