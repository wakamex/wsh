module_path=($WSH_TEST_MODULE $module_path)
zmodload wshcompletion
setopt extendedglob
typeset _i_bulk=yes _i_file _i_fd _i_header
typeset -a _i_line
for _i_file in "$1"/*(N); do
  if [[ $2 == candidate ]]; then
      wsh-completion-header "$_i_file" _i_line ||
      IFS=$' \t' read -rA _i_line < $_i_file

  else
    IFS=$' \t' read -rA _i_line < $_i_file
  fi
  print -r -- "${_i_file:t}:${#_i_line}:${(j:|:)${(@qqqq)_i_line}}"
done
