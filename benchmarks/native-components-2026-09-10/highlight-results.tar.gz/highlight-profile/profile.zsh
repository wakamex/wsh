source $1
zmodload zsh/datetime
typeset -a buffers samples
buffers=('echo hello')
repeated='' distinct=''
for ((i=1;i<=100;i++)); do
 functions[wsh_probe_$i]=':'
 repeated+='echo hello; '
 distinct+="wsh_probe_$i hello; "
done
buffers+=("$repeated" "$distinct" $'if true; then\n echo "${HOME}"\nfi')
CONTEXT=start PREBUFFER=''
for ((workload=1;workload<=4;workload++)); do
 BUFFER=$buffers[$workload] CURSOR=$#BUFFER
 for ((i=0;i<50;i++)); do
  modes=(off on)
  ((i%2)) && modes=(on off)
  for mode in $modes; do
   [[ $mode == on ]] && zmodload zsh/zprof
   _zsh_highlight_main__command_type_cache=()
   region_highlight=()
   start=$EPOCHREALTIME
   _zsh_highlight_highlighter_main_paint
   elapsed=$(( (EPOCHREALTIME-start)*1000 ))
   samples+=("$workload $i $mode $elapsed ${(qqq)${(j:|:)region_highlight}}")
   if [[ $mode == on ]]; then
    zprof > "$2/profile-$workload-$i.txt"
    zmodload -u zsh/zprof
   fi
  done
 done
done
print -rl -- $samples
