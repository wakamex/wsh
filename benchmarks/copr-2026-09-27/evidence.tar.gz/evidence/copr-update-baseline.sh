set -euxo pipefail
getenforce
getent passwd recovery shellempty
find /etc/yum.repos.d -name '*wsh*' -exec cat {} \;
dnf -y --refresh install wsh-0.4.0-1.fc44
rpm -q wsh
/usr/bin/wsh --wsh-version
rpm -V wsh
