set -euxo pipefail
cat /proc/sys/kernel/random/boot_id
python3 /var/tmp/test-hosted-update-rpm.py
getenforce
