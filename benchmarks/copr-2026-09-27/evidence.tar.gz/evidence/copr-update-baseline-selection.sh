set -euxo pipefail
mkdir -p /var/tmp/wsh-package-results
python3 /var/tmp/test-chsh-guest.py
cat /var/tmp/test-hosted-rpm.py
