set -euxo pipefail
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/history-persistence.py /usr/bin/wsh /var/tmp/wsh-copr-history-2
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/pane-history.py /usr/bin/wsh /var/tmp/wsh-copr-pane-2
