set -euxo pipefail
tar -czf /var/tmp/wsh-copr-update-history-evidence.tar.gz -C /var/tmp wsh-copr-history-2 wsh-copr-pane-2 wsh-package-results/chsh.bin
chmod 0644 /var/tmp/wsh-copr-update-history-evidence.tar.gz
test "$(getent passwd shellempty | cut -d: -f7)" = /usr/bin/wsh
dnf -y remove wsh
! test -e /usr/bin/wsh
! test -e /usr/libexec/wsh/wsh-runtime
! grep -Fx /usr/bin/wsh /etc/shells
! grep -Fx /bin/wsh /etc/shells
test "$(getent passwd shellempty | cut -d: -f7)" = /usr/bin/wsh
usermod -s /bin/bash shellempty
su -l shellempty -c 'echo RECOVERY_LOGIN_OK'
getenforce
