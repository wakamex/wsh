set -euxo pipefail
python3 - <<'PY'
from pathlib import Path
p = Path('/var/tmp/test-hosted-rpm.py')
s = p.read_text().replace('2bd3924e57f2b7e1f8726972cd4406b44c21fb77','3f15fec0de1786ca7fe0d0136af1759f5a86ce8f').replace('0.4.0-1.fc44','0.4.0-2.fc44')
Path('/var/tmp/test-hosted-update-rpm.py').write_text(s)
PY
cat /etc/yum.repos.d/*wsh*.repo
cat /etc/os-release
uname -a
