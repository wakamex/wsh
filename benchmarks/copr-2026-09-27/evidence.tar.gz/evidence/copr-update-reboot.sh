set -euxo pipefail
cat /proc/sys/kernel/random/boot_id
rpm -q wsh
sync
systemctl reboot
