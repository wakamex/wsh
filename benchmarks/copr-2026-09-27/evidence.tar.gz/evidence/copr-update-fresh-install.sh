set -euxo pipefail
usermod -s /bin/bash shellempty
su -l shellempty -c 'echo RECOVERY_LOGIN_OK'
dnf -y remove wsh
! test -e /usr/bin/wsh
! test -e /usr/libexec/wsh/wsh-runtime
! grep -Fx /usr/bin/wsh /etc/shells
! grep -Fx /bin/wsh /etc/shells
dnf -y --refresh install wsh
python3 /var/tmp/test-hosted-update-rpm.py
python3 /var/tmp/test-chsh-guest.py
getenforce
