set -euxo pipefail
test "$(rpm -q --qf '%{VERSION}-%{RELEASE}' wsh)" = 0.4.8-1.fc44
dnf -y --refresh upgrade wsh
python3 /var/tmp/test-hosted-049-rpm.py
/usr/bin/wsh --wsh-version | grep -Fx 'wsh 0.4.9 (release build)'
rm -rf /var/tmp/wsh-copr-signed
dnf download --destdir /var/tmp/wsh-copr-signed wsh
rpmkeys --checksig -v /var/tmp/wsh-copr-signed/wsh-0.4.9-1.fc44.x86_64.rpm
rpm -V wsh
sha256sum /var/tmp/wsh-copr-signed/wsh-0.4.9-1.fc44.x86_64.rpm /usr/bin/wsh /usr/libexec/wsh/wsh-runtime /usr/share/wsh/manifest.json
python3 - <<'PY'
import hashlib, re
from pathlib import Path
catalog = [Path(p) for p in __import__('subprocess').check_output(['rpm','-ql','wsh'],text=True).split() if p.endswith('plugin-catalog/catalog.zsh')]
assert len(catalog) == 1, catalog
root = catalog[0].parent
snapshots = [p for p in root.iterdir() if re.fullmatch('[0-9a-f]{64}', p.name)]
for p in snapshots:
    assert hashlib.sha256(p.read_bytes()).hexdigest() == p.name, p
refs = re.findall(r"plugin-catalog/([0-9a-f]{64})", catalog[0].read_text())
assert refs and all((root / r).is_file() for r in refs)
print('catalog snapshots', len(snapshots), 'references', len(refs))
PY
/usr/bin/wsh /var/tmp/wsh-tests/tests/interrupt-propagation.zsh /usr/bin/wsh
/usr/bin/wsh /var/tmp/wsh-tests/tests/wsh-version-parameter.zsh /usr/bin/wsh
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/wsh-tests/tests/autosuggestions-reload.py /usr/bin/wsh
rm -rf /var/tmp/wsh-copr-049-history /var/tmp/wsh-copr-049-mail /var/tmp/wsh-copr-doctor-049 /var/tmp/wsh-copr-049-defaults /var/tmp/wsh-copr-049-directory
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/wsh-tests/tests/history-persistence.py /usr/bin/wsh /var/tmp/wsh-copr-049-history
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/wsh-tests/tests/mail-check.py /usr/bin/wsh /var/tmp/wsh-copr-049-mail
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/wsh-tests/tests/doctor-terminal.py /usr/bin/wsh /var/tmp/wsh-copr-doctor-049
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/wsh-tests/tests/interactive-defaults.py /usr/bin/wsh /var/tmp/wsh-copr-049-defaults
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/wsh-tests/tests/directory-report.py /usr/bin/wsh /var/tmp/wsh-copr-049-directory
rm -rf /var/tmp/wsh-copr-049-typeahead /var/tmp/wsh-copr-049-symlink
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/wsh-tests/tests/typeahead.py /var/tmp/wsh-copr-049-typeahead /usr/bin/wsh
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/wsh-tests/tests/symlinked-executable.py /usr/bin/wsh /var/tmp/wsh-copr-049-symlink
getenforce
