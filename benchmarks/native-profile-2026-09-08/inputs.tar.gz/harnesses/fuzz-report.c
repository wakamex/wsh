#define _GNU_SOURCE
#define WSH_VERSION "0.3.1"
#define WSH_SOURCE_REVISION "c4ac10f"
#define WSH_INPUTS_SHA256 "0000000000000000000000000000000000000000000000000000000000000000"
#define ZSH_VERSION "5.9.999.3-test"
#define WSH_ZSH_SOURCE_REVISION "cad0d67c"
#define WSH_TARGET "x86_64-linux-gnu"
#include "/code/wsh/native/profile.c"
#include "/code/wsh/native/profile-report.c"
static unsigned state=20260908;
static unsigned random_byte(void) {state^=state<<13; state^=state>>17; state^=state<<5; return state;}
int main(int argc,char **argv) {
 unsigned i,j,length; char buffer[1024]; json_t *value;
 const char *seed="{\"schema_version\":1,\"source\":\"zsh\",\"event\":\"editor-ready\",\"elapsed_us\":1}";
 if(argc==2) return wsh_profile_report(argv[1]);
 if(argc>2) return wsh_profile_start(argc,argv);
 for(i=0;i<10000;i++) {
  if(i%2) {length=(unsigned)strlen(seed); memcpy(buffer,seed,length); for(j=0;j<1+i%8;j++) buffer[random_byte()%length]=(char)random_byte();}
  else {length=random_byte()%sizeof(buffer); for(j=0;j<length;j++)buffer[j]=(char)random_byte();}
  value=json_loadb(buffer,length,JSON_REJECT_DUPLICATES,NULL);
  (void)wsh_profile_event_valid(value);
  json_decref(value);
 }
 puts("PASS: 10000 deterministic mutated and arbitrary JSON byte inputs");
 return 0;
}
