#define _GNU_SOURCE
#define WSH_VERSION "0.3.1"
#define WSH_SOURCE_REVISION "c4ac10f"
#define WSH_INPUTS_SHA256 "0000000000000000000000000000000000000000000000000000000000000000"
#define ZSH_VERSION "5.9.999.3-test"
#define WSH_ZSH_SOURCE_REVISION "cad0d67c"
#define WSH_TARGET "x86_64-linux-gnu"
#include "/code/wsh/native/profile.c"
#include "/code/wsh/native/profile-report.c"
int main(int argc,char **argv) {
 if (argc>1 && !strcmp(argv[1],"--wsh-profile")) return wsh_profile_start(argc,argv)<0 ? 0 : 1;
 return argc==2 ? wsh_profile_report(argv[1]) : 2;
}
