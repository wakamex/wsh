set -euxo pipefail
chmod 0644 /var/tmp/doctor-terminal.py
