set -euxo pipefail
dnf -y --refresh install wsh-0.4.1-1.fc44
python3 /var/tmp/test-hosted-041-rpm.py
python3 - <<'PY'
from pathlib import Path
p=Path('/var/tmp/test-hosted-041-rpm.py')
s=p.read_text().replace('c8ec27971b43f31ba311a3922bad756ba39c89c4','9edbaf9f72cf8966d8f9bd5cfafbc15863bd0e77').replace('0.4.1-1.fc44','0.4.2-1.fc44')
Path('/var/tmp/test-hosted-042-rpm.py').write_text(s)
PY
cat /etc/yum.repos.d/*wsh*.repo
getenforce
