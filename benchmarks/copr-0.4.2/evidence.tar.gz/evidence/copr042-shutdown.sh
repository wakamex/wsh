set -euxo pipefail
getent passwd recovery shellempty
! rpm -q wsh
sync
systemctl poweroff
