# Generated from verified upstream snapshots.
typeset -gA _WSH_PLUGIN_REFERENCES=(
  autosuggestions 'pending-widget-binding-legacy-zle-ignore|plugin-catalog/8261e6428679ac48f85d315837821680ba2a28d60519b00a8abd67f608b2e7c6
pending-widget-binding|plugin-catalog/7b865223ed1a60e905f1af986bf29816be2dddbd9bcbf56b07a88f1b593798e6
pending-widget-binding|plugin-catalog/32ae59df91c02afb04ee8858185bf66dd0279d321a53c1071b51b9b981b2c586
pending-widget-binding|plugin-catalog/f6701d3b43db69cfdf5ece5608235869c37b793d291ae69d7263ee3707470d7f
pending-widget-binding|plugin-catalog/cd431823c960243e1c12fe0b1bf4c9dc20e12bb27052feb2a1883e1cd67190c6
pending-widget-binding|plugin-catalog/7f5d56a502671c18cdf8056239c67963afd58bd21c19717ec5921cdc314dc75e
pending-widget-binding|plugin-catalog/70c34826cb110e1c54dfba85802ad3ac0144e3a2e203c41a617fd7651d43c875
pending-widget-binding|plugin-catalog/eec7ba8f7a71414ace0ea0fab0908d005b24cf65d83b169c0ff97815d3cfc51a'
  history 'replace-history-hooks|plugin-catalog/86939add2abfa59b18d4adc9735af3cd90323f1822bc3772d14b4a8a9fbfdd81
replace-history-hooks|plugin-catalog/1f6884e13e5c64d58dd47258d234ba73b2ca6f8a63faf0e89858a539b8f2ae1d
replace-history-hooks|plugin-catalog/9f2e15817cca2d9813a8ca49ec6090596d7d6a13ef1f19e1a896700ad1e21ccb
replace-history-hooks|plugin-catalog/840d6a4d403c7ae1e1fafb1f5b5d2a38066defcc62d7d9951b473a3421dd3b04
replace-history-hooks|plugin-catalog/0b864862a3b48992d7316cc7e585a1315fa389d730c17bf16e2f2bd5918089f3
replace-history-hooks|plugin-catalog/b2f8ffceca6006eadfdca72a487adb572fe3dccbd5ac3e9f95c50127968454b9'
  syntax 'main-parser-with-preserved-lifecycle|plugin-catalog/156ebe9530eb991dcef54d476967e2ff4338d35dabaaff9e5462673a287cc63b|plugin-catalog/d63bf09783100d426d0eb068872ea42b87d9609c49deb0d063daaa173223e7fd
main-parser-with-preserved-lifecycle|plugin-catalog/b6df8eb756bfef2cafdae00e2920d5ddf969220e8f1e9d61601e566c4cf8a61f|plugin-catalog/c0f8ddf4a2d307fe31559a14329516ccac8c8e1c563783b759685455e939d260'
  directory 'preserve-directory-lifecycle|plugin-catalog/ccd085ac09a6a0e771e12bc4c531cfde1ecab804f6d04b5ea2275f131c841ff7'
  git-prompt 'remove-prompt-collector-hooks|plugin-catalog/4f9129fd2000dfaca06734c7471934fb179c91a83b0cdb13bd63142d99be432d|plugin-catalog/2485a9e27dd30afa01d4b12e1bdf344933ab4f9927cb42c7c0505c39c05a611d'
)
typeset -gA _WSH_PLUGIN_UPSTREAMS=(
  autosuggestions 'https://github.com/zsh-users/zsh-autosuggestions|master|pending-widget-binding|zsh-autosuggestions.zsh'
  history 'https://github.com/zsh-users/zsh-history-substring-search|master|replace-history-hooks|zsh-history-substring-search.zsh
https://github.com/ohmyzsh/ohmyzsh|master|replace-history-hooks|plugins/history-substring-search/history-substring-search.zsh'
  syntax 'https://github.com/zsh-users/zsh-syntax-highlighting|master|main-parser-with-preserved-lifecycle|zsh-syntax-highlighting.zsh|highlighters/main/main-highlighter.zsh'
  directory 'https://github.com/ohmyzsh/ohmyzsh|master|preserve-directory-lifecycle|plugins/z/z.plugin.zsh'
  git-prompt 'https://github.com/ohmyzsh/ohmyzsh|master|remove-prompt-collector-hooks|plugins/git-prompt/git-prompt.plugin.zsh|plugins/git-prompt/gitstatus.py'
)
