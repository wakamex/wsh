set -euxo pipefail
test "$(rpm -q --qf '%{VERSION}-%{RELEASE}' wsh)" = 0.4.5-1.fc44
dnf -y --refresh upgrade wsh
python3 /var/tmp/test-hosted-046-rpm.py
/usr/bin/wsh --wsh-version | grep -Fx 'wsh 0.4.6 (release build)'
rm -rf /var/tmp/wsh-copr-signed
dnf download --destdir /var/tmp/wsh-copr-signed wsh
rpmkeys --checksig -v /var/tmp/wsh-copr-signed/wsh-0.4.6-1.fc44.x86_64.rpm
rpm -V wsh
sha256sum /var/tmp/wsh-copr-signed/wsh-0.4.6-1.fc44.x86_64.rpm /usr/bin/wsh /usr/libexec/wsh/wsh-runtime /usr/share/wsh/manifest.json
python3 - <<'PY'
import hashlib, re
from pathlib import Path
catalog = [Path(p) for p in __import__('subprocess').check_output(['rpm','-ql','wsh'],text=True).split() if p.endswith('plugin-catalog/catalog.zsh')]
assert len(catalog) == 1, catalog
root = catalog[0].parent
snapshots = [p for p in root.iterdir() if re.fullmatch('[0-9a-f]{64}', p.name)]
for p in snapshots:
    assert hashlib.sha256(p.read_bytes()).hexdigest() == p.name, p
refs = re.findall(r"plugin-catalog/([0-9a-f]{64})", catalog[0].read_text())
assert refs and all((root / r).is_file() for r in refs)
print('catalog snapshots', len(snapshots), 'references', len(refs))
PY
/usr/bin/wsh /var/tmp/interrupt-propagation.zsh /usr/bin/wsh
/usr/bin/wsh /var/tmp/wsh-tests/tests/wsh-version-parameter.zsh /usr/bin/wsh
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/wsh-tests/tests/autosuggestions-reload.py /usr/bin/wsh
rm -rf /var/tmp/wsh-copr-046-history /var/tmp/wsh-copr-046-mail /var/tmp/wsh-copr-doctor-046
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/history-persistence.py /usr/bin/wsh /var/tmp/wsh-copr-046-history
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/mail-check.py /usr/bin/wsh /var/tmp/wsh-copr-046-mail
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/doctor-terminal.py /usr/bin/wsh /var/tmp/wsh-copr-doctor-046
getenforce
