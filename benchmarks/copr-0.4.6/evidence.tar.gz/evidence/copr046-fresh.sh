set -euxo pipefail
usermod -s /bin/bash shellempty
dnf -y remove wsh
! test -e /usr/bin/wsh
! grep -Fx /usr/bin/wsh /etc/shells
! grep -Fx /bin/wsh /etc/shells
dnf -y --refresh install wsh
python3 /var/tmp/test-hosted-046-rpm.py
python3 /var/tmp/test-chsh-guest.py
getenforce
