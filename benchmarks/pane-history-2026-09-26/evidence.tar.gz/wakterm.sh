# shellcheck shell=bash

# This file hooks up shell integration for wakterm.
# It is suitable for zsh and bash.
#
# Although wakterm is mentioned here, the sequences used are not wakterm
# specific and may provide the same functionality for other terminals.  Most
# terminals are good at ignoring OSC sequences that they don't understand, but
# if not there are some bypasses:
#
# WAKTERM_SHELL_SKIP_ALL - disables all
# WAKTERM_SHELL_SKIP_SEMANTIC_ZONES - disables zones
# WAKTERM_SHELL_SKIP_CWD - disables OSC 7 cwd setting
# WAKTERM_SHELL_SKIP_USER_VARS - disable user vars that capture information
#                                about running programs
# WAKTERM_SHELL_SKIP_PANE_HISTORY - disables pane-local history

# shellcheck disable=SC2166
if [ -z "${BASH_VERSION-}" -a -z "${ZSH_NAME-}" ] ; then
  # Only for bash or zsh
  return 0
fi

if [ "${WAKTERM_SHELL_SKIP_ALL-}" = "1" ] ; then
  return 0
fi

# Wsh owns standard OSC 7 and OSC 133 sequences through its bundled Zsh. Keep
# Wakterm's separate OSC 1337 metadata, but do not install duplicate prompt,
# output, or working-directory reporters.
if [ "${WSH_NATIVE_TERMINAL_INTEGRATION-}" = "1" ] ; then
  WAKTERM_SHELL_SKIP_SEMANTIC_ZONES=1
  WAKTERM_SHELL_SKIP_CWD=1
fi

if [[ $- != *i* ]] ; then
  # Shell integration is only useful in interactive sessions
  return 0
fi

# Wakterm can load this file automatically, and it may also be sourced from
# a startup file or /etc/profile.d. Install the hooks only once per shell.
if [[ -n "${__wakterm_shell_integration_loaded-}" ]] ; then
  return 0
fi
__wakterm_shell_integration_loaded=1

case "$TERM" in
  linux | dumb )
    # Avoid terminals that don't like OSC sequences
    return 0
  ;;
esac

# This function wraps bash-preexec.sh so that it can be included verbatim
# in this file, even though it uses `return` to short-circuit in some cases.
__wakterm_install_bash_prexec() {

# bash-preexec.sh -- Bash support for ZSH-like 'preexec' and 'precmd' functions.
# https://github.com/rcaloras/bash-preexec
#
#
# 'preexec' functions are executed before each interactive command is
# executed, with the interactive command as its argument. The 'precmd'
# function is executed before each prompt is displayed.
#
# Author: Ryan Caloras (ryan@bashhub.com)
# Forked from Original Author: Glyph Lefkowitz
#
# V0.5.0
#

# General Usage:
#
#  1. Source this file at the end of your bash profile so as not to interfere
#     with anything else that's using PROMPT_COMMAND.
#
#  2. Add any precmd or preexec functions by appending them to their arrays:
#       e.g.
#       precmd_functions+=(my_precmd_function)
#       precmd_functions+=(some_other_precmd_function)
#
#       preexec_functions+=(my_preexec_function)
#
#  3. Consider changing anything using the DEBUG trap or PROMPT_COMMAND
#     to use preexec and precmd instead. Preexisting usages will be
#     preserved, but doing so manually may be less surprising.
#
#  Note: This module requires two Bash features which you must not otherwise be
#  using: the "DEBUG" trap, and the "PROMPT_COMMAND" variable. If you override
#  either of these after bash-preexec has been installed it will most likely break.

# Tell shellcheck what kind of file this is.
# shellcheck shell=bash

# Make sure this is bash that's running and return otherwise.
# Use POSIX syntax for this line:
if [ -z "${BASH_VERSION-}" ]; then
    return 1;
fi

# We only support Bash 3.1+.
# Note: BASH_VERSINFO is first available in Bash-2.0.
if [[ -z "${BASH_VERSINFO-}" ]] || (( BASH_VERSINFO[0] < 3 || (BASH_VERSINFO[0] == 3 && BASH_VERSINFO[1] < 1) )); then
    return 1
fi

# Avoid duplicate inclusion
if [[ -n "${bash_preexec_imported:-}" ]]; then
    return 0
fi
bash_preexec_imported="defined"

# WARNING: This variable is no longer used and should not be relied upon.
# Use ${bash_preexec_imported} instead.
# shellcheck disable=SC2034
__bp_imported="${bash_preexec_imported}"

# Should be available to each precmd and preexec
# functions, should they want it. $? and $_ are available as $? and $_, but
# $PIPESTATUS is available only in a copy, $BP_PIPESTATUS.
# TODO: Figure out how to restore PIPESTATUS before each precmd or preexec
# function.
__bp_last_ret_value="$?"
BP_PIPESTATUS=("${PIPESTATUS[@]}")
__bp_last_argument_prev_command="$_"

__bp_inside_precmd=0
__bp_inside_preexec=0

# Initial PROMPT_COMMAND string that is removed from PROMPT_COMMAND post __bp_install
__bp_install_string=$'__bp_trap_string="$(trap -p DEBUG)"\ntrap - DEBUG\n__bp_install'

# Fails if any of the given variables are readonly
# Reference https://stackoverflow.com/a/4441178
__bp_require_not_readonly() {
  local var
  for var; do
    if ! ( unset "$var" 2> /dev/null ); then
      echo "bash-preexec requires write access to ${var}" >&2
      return 1
    fi
  done
}

# Remove ignorespace and or replace ignoreboth from HISTCONTROL
# so we can accurately invoke preexec with a command from our
# history even if it starts with a space.
__bp_adjust_histcontrol() {
    local histcontrol
    histcontrol="${HISTCONTROL:-}"
    histcontrol="${histcontrol//ignorespace}"
    # Replace ignoreboth with ignoredups
    if [[ "$histcontrol" == *"ignoreboth"* ]]; then
        histcontrol="ignoredups:${histcontrol//ignoreboth}"
    fi;
    export HISTCONTROL="$histcontrol"
}

# This variable describes whether we are currently in "interactive mode";
# i.e. whether this shell has just executed a prompt and is waiting for user
# input.  It documents whether the current command invoked by the trace hook is
# run interactively by the user; it's set immediately after the prompt hook,
# and unset as soon as the trace hook is run.
__bp_preexec_interactive_mode=""

# These arrays are used to add functions to be run before, or after, prompts.
declare -a precmd_functions
declare -a preexec_functions

# Trims leading and trailing whitespace from $2 and writes it to the variable
# name passed as $1
__bp_trim_whitespace() {
    local var=${1:?} text=${2:-}
    text="${text#"${text%%[![:space:]]*}"}"   # remove leading whitespace characters
    text="${text%"${text##*[![:space:]]}"}"   # remove trailing whitespace characters
    printf -v "$var" '%s' "$text"
}


# Trims whitespace and removes any leading or trailing semicolons from $2 and
# writes the resulting string to the variable name passed as $1. Used for
# manipulating substrings in PROMPT_COMMAND
__bp_sanitize_string() {
    local var=${1:?} text=${2:-} sanitized
    __bp_trim_whitespace sanitized "$text"
    sanitized=${sanitized%;}
    sanitized=${sanitized#;}
    __bp_trim_whitespace sanitized "$sanitized"
    printf -v "$var" '%s' "$sanitized"
}

# This function is installed as part of the PROMPT_COMMAND;
# It sets a variable to indicate that the prompt was just displayed,
# to allow the DEBUG trap to know that the next command is likely interactive.
__bp_interactive_mode() {
    __bp_preexec_interactive_mode="on";
}


# This function is installed as part of the PROMPT_COMMAND.
# It will invoke any functions defined in the precmd_functions array.
__bp_precmd_invoke_cmd() {
    # Save the returned value from our last command, and from each process in
    # its pipeline. Note: this MUST be the first thing done in this function.
    # BP_PIPESTATUS may be unused, ignore
    # shellcheck disable=SC2034

    __bp_last_ret_value="$?" BP_PIPESTATUS=("${PIPESTATUS[@]}")

    # Don't invoke precmds if we are inside an execution of an "original
    # prompt command" by another precmd execution loop. This avoids infinite
    # recursion.
    if (( __bp_inside_precmd > 0 )); then
      return
    fi
    local __bp_inside_precmd=1

    # Invoke every function defined in our function array.
    local precmd_function
    for precmd_function in "${precmd_functions[@]}"; do

        # Only execute this function if it actually exists.
        # Test existence of functions with: declare -[Ff]
        if type -t "$precmd_function" 1>/dev/null; then
            __bp_set_ret_value "$__bp_last_ret_value" "$__bp_last_argument_prev_command"
            # Quote our function invocation to prevent issues with IFS
            "$precmd_function"
        fi
    done

    __bp_set_ret_value "$__bp_last_ret_value"
}

# Sets a return value in $?. We may want to get access to the $? variable in our
# precmd functions. This is available for instance in zsh. We can simulate it in bash
# by setting the value here.
__bp_set_ret_value() {
    return ${1:+"$1"}
}

__bp_in_prompt_command() {

    local prompt_command_array IFS=$'\n;'
    read -rd '' -a prompt_command_array <<< "${PROMPT_COMMAND[*]:-}"

    local trimmed_arg
    __bp_trim_whitespace trimmed_arg "${1:-}"

    local command trimmed_command
    for command in "${prompt_command_array[@]:-}"; do
        __bp_trim_whitespace trimmed_command "$command"
        if [[ "$trimmed_command" == "$trimmed_arg" ]]; then
            return 0
        fi
    done

    return 1
}

# This function is installed as the DEBUG trap.  It is invoked before each
# interactive prompt display.  Its purpose is to inspect the current
# environment to attempt to detect if the current command is being invoked
# interactively, and invoke 'preexec' if so.
__bp_preexec_invoke_exec() {

    # Save the contents of $_ so that it can be restored later on.
    # https://stackoverflow.com/questions/40944532/bash-preserve-in-a-debug-trap#40944702
    __bp_last_argument_prev_command="${1:-}"
    # Don't invoke preexecs if we are inside of another preexec.
    if (( __bp_inside_preexec > 0 )); then
      return
    fi
    local __bp_inside_preexec=1

    # Checks if the file descriptor is not standard out (i.e. '1')
    # __bp_delay_install checks if we're in test. Needed for bats to run.
    # Prevents preexec from being invoked for functions in PS1
    if [[ ! -t 1 && -z "${__bp_delay_install:-}" ]]; then
        return
    fi

    if [[ -n "${COMP_LINE:-}" ]]; then
        # We're in the middle of a completer. This obviously can't be
        # an interactively issued command.
        return
    fi
    if [[ -z "${__bp_preexec_interactive_mode:-}" ]]; then
        # We're doing something related to displaying the prompt.  Let the
        # prompt set the title instead of me.
        return
    else
        # If we're in a subshell, then the prompt won't be re-displayed to put
        # us back into interactive mode, so let's not set the variable back.
        # In other words, if you have a subshell like
        #   (sleep 1; sleep 2)
        # You want to see the 'sleep 2' as a set_command_title as well.
        if [[ 0 -eq "${BASH_SUBSHELL:-}" ]]; then
            __bp_preexec_interactive_mode=""
        fi
    fi

    if  __bp_in_prompt_command "${BASH_COMMAND:-}"; then
        # If we're executing something inside our prompt_command then we don't
        # want to call preexec. Bash prior to 3.1 can't detect this at all :/
        __bp_preexec_interactive_mode=""
        return
    fi

    local this_command
    this_command=$(
        export LC_ALL=C
        HISTTIMEFORMAT='' builtin history 1 | sed '1 s/^ *[0-9][0-9]*[* ] //'
    )

    # Sanity check to make sure we have something to invoke our function with.
    if [[ -z "$this_command" ]]; then
        return
    fi

    # Invoke every function defined in our function array.
    local preexec_function
    local preexec_function_ret_value
    local preexec_ret_value=0
    for preexec_function in "${preexec_functions[@]:-}"; do

        # Only execute each function if it actually exists.
        # Test existence of function with: declare -[fF]
        if type -t "$preexec_function" 1>/dev/null; then
            __bp_set_ret_value "${__bp_last_ret_value:-}"
            # Quote our function invocation to prevent issues with IFS
            "$preexec_function" "$this_command"
            preexec_function_ret_value="$?"
            if [[ "$preexec_function_ret_value" != 0 ]]; then
                preexec_ret_value="$preexec_function_ret_value"
            fi
        fi
    done

    # Restore the last argument of the last executed command, and set the return
    # value of the DEBUG trap to be the return code of the last preexec function
    # to return an error.
    # If `extdebug` is enabled a non-zero return value from any preexec function
    # will cause the user's command not to execute.
    # Run `shopt -s extdebug` to enable
    __bp_set_ret_value "$preexec_ret_value" "$__bp_last_argument_prev_command"
}

__bp_install() {
    # Exit if we already have this installed.
    if [[ "${PROMPT_COMMAND[*]:-}" == *"__bp_precmd_invoke_cmd"* ]]; then
        return 1;
    fi

    trap '__bp_preexec_invoke_exec "$_"' DEBUG

    # Preserve any prior DEBUG trap as a preexec function
    local prior_trap
    # we can't easily do this with variable expansion. Leaving as sed command.
    # shellcheck disable=SC2001
    prior_trap=$(sed "s/[^']*'\(.*\)'[^']*/\1/" <<<"${__bp_trap_string:-}")
    unset __bp_trap_string
    if [[ -n "$prior_trap" ]]; then
        eval '__bp_original_debug_trap() {
          '"$prior_trap"'
        }'
        preexec_functions+=(__bp_original_debug_trap)
    fi

    # Adjust our HISTCONTROL Variable if needed.
    __bp_adjust_histcontrol

    # Issue #25. Setting debug trap for subshells causes sessions to exit for
    # backgrounded subshell commands (e.g. (pwd)& ). Believe this is a bug in Bash.
    #
    # Disabling this by default. It can be enabled by setting this variable.
    if [[ -n "${__bp_enable_subshells:-}" ]]; then

        # Set so debug trap will work be invoked in subshells.
        set -o functrace > /dev/null 2>&1
        shopt -s extdebug > /dev/null 2>&1
    fi;

    local existing_prompt_command
    # Remove setting our trap install string and sanitize the existing prompt command string
    existing_prompt_command="${PROMPT_COMMAND:-}"
    # Edge case of appending to PROMPT_COMMAND
    existing_prompt_command="${existing_prompt_command//$__bp_install_string/:}" # no-op
    existing_prompt_command="${existing_prompt_command//$'\n':$'\n'/$'\n'}" # remove known-token only
    existing_prompt_command="${existing_prompt_command//$'\n':;/$'\n'}" # remove known-token only
    __bp_sanitize_string existing_prompt_command "$existing_prompt_command"
    if [[ "${existing_prompt_command:-:}" == ":" ]]; then
        existing_prompt_command=
    fi

    # Install our hooks in PROMPT_COMMAND to allow our trap to know when we've
    # actually entered something.
    PROMPT_COMMAND='__bp_precmd_invoke_cmd'
    PROMPT_COMMAND+=${existing_prompt_command:+$'\n'$existing_prompt_command}
    if (( BASH_VERSINFO[0] > 5 || (BASH_VERSINFO[0] == 5 && BASH_VERSINFO[1] >= 1) )); then
        PROMPT_COMMAND+=('__bp_interactive_mode')
    else
        # shellcheck disable=SC2179 # PROMPT_COMMAND is not an array in bash <= 5.0
        PROMPT_COMMAND+=$'\n__bp_interactive_mode'
    fi

    # Add two functions to our arrays for convenience
    # of definition.
    precmd_functions+=(precmd)
    preexec_functions+=(preexec)

    # Invoke our two functions manually that were added to $PROMPT_COMMAND
    __bp_precmd_invoke_cmd
    __bp_interactive_mode
}

# Sets an installation string as part of our PROMPT_COMMAND to install
# after our session has started. This allows bash-preexec to be included
# at any point in our bash profile.
__bp_install_after_session_init() {
    # bash-preexec needs to modify these variables in order to work correctly
    # if it can't, just stop the installation
    __bp_require_not_readonly PROMPT_COMMAND HISTCONTROL HISTTIMEFORMAT || return

    local sanitized_prompt_command
    __bp_sanitize_string sanitized_prompt_command "${PROMPT_COMMAND:-}"
    if [[ -n "$sanitized_prompt_command" ]]; then
        # shellcheck disable=SC2178 # PROMPT_COMMAND is not an array in bash <= 5.0
        PROMPT_COMMAND=${sanitized_prompt_command}$'\n'
    fi;
    # shellcheck disable=SC2179 # PROMPT_COMMAND is not an array in bash <= 5.0
    PROMPT_COMMAND+=${__bp_install_string}
}

# Run our install so long as we're not delaying it.
if [[ -z "${__bp_delay_install:-}" ]]; then
    __bp_install_after_session_init
fi;

} # end of __wakterm_install_bash_prexec

# blesh provides it's own preexec mechanism which is recommended over bash-preexec
# See https://github.com/akinomyoga/ble.sh/wiki/Manual-%C2%A71-Introduction#user-content-fn-blehook for more details
if [[ ! -n "${BLE_VERSION-}" ]]; then
  __wakterm_install_bash_prexec
fi

# This function emits an OSC 1337 sequence to set a user var
# associated with the current terminal pane.
# It requires the `base64` utility to be available in the path.
__wakterm_set_user_var() {
  if hash base64 2>/dev/null ; then
    if [[ -z "${TMUX-}" ]] ; then
      printf "\033]1337;SetUserVar=%s=%s\007" "$1" `echo -n "$2" | base64`
    else
      # <https://github.com/tmux/tmux/wiki/FAQ#what-is-the-passthrough-escape-sequence-and-how-do-i-use-it>
      # Note that you ALSO need to add "set -g allow-passthrough on" to your tmux.conf
      printf "\033Ptmux;\033\033]1337;SetUserVar=%s=%s\007\033\\" "$1" `echo -n "$2" | base64`
    fi
  fi
}

# This function emits an OSC 7 sequence to inform the terminal
# of the current working directory.  It prefers to use a helper
# command provided by wakterm if wakterm is installed, but falls
# back to a simple printf command otherwise.
__wakterm_osc7() {
  if hash wakterm 2>/dev/null ; then
    wakterm set-working-directory 2>/dev/null && return 0
    # If the command failed (perhaps the installed wakterm
    # is too old?) then fall back to the simple version below.
  fi
  printf "\033]7;file://%s%s\033\\" "${HOSTNAME}" "${PWD}"
}

# The semantic precmd and prexec functions generate semantic
# zones, marking up the prompt, the user input and the command
# output so that the terminal can better reason about the display.
__wakterm_semantic_precmd_executing=""
__wakterm_semantic_precmd() {
  local ret="$?"
  if [[ "$__wakterm_semantic_precmd_executing" != "0" ]] ; then
    __wakterm_save_ps1="$PS1"
    __wakterm_save_ps2="$PS2"
    # Markup the left and right prompts so that the terminal
    # knows that they are semantically prompt output.
    if [[ -n "${ZSH_NAME-}" ]] ; then
      PS1=$'%{\e]133;P;k=i\a%}'$PS1$'%{\e]133;B\a%}'
      PS2=$'%{\e]133;P;k=s\a%}'$PS2$'%{\e]133;B\a%}'
    else
      PS1='\[\e]133;P;k=i\a\]'$PS1'\[\e]133;B\a\]'
      PS2='\[\e]133;P;k=s\a\]'$PS2'\[\e]133;B\a\]'
    fi
    __wakterm_check_ps1="$PS1"
  fi
  if [[ "$__wakterm_semantic_precmd_executing" != "" ]] ; then
    # Report last command status
    printf "\033]133;D;%s;aid=%s\007" "$ret" "$$"
  fi
  # Fresh line and start the prompt
  if [[ -n "${BLE_VERSION-}" ]]; then
    # FreshLine breaks ble.sh's cursor position tracking.  Also, the cursor
    # position adjustment is already performed ble.sh so unnecessary here.  We
    # here only perform StartPrompt.
    printf "\033]133;P\007"
  else
    printf "\033]133;A;cl=m;aid=%s\007" "$$"
  fi
  __wakterm_semantic_precmd_executing=0
}

function __wakterm_semantic_preexec() {
  # Restore the original PS1/PS2 if set
  if [[ -n "${__wakterm_save_ps1+1}" && "${__wakterm_check_ps1-}" == "${PS1}" ]]; then
	  PS1="$__wakterm_save_ps1"
	  PS2="$__wakterm_save_ps2"
	  unset __wakterm_save_ps1
  fi
  # Indicate that the command output begins here
  printf "\033]133;C;\007"
  __wakterm_semantic_precmd_executing=1
}

__wakterm_user_vars_precmd() {
  __wakterm_set_user_var "WAKTERM_PROG" ""
  __wakterm_set_user_var "WAKTERM_USER" "$(id -un)"

  # Indicate whether this pane is running inside tmux or not
  if [[ -n "${TMUX-}" ]] ; then
    __wakterm_set_user_var "WAKTERM_IN_TMUX" "1"
  else
    __wakterm_set_user_var "WAKTERM_IN_TMUX" "0"
  fi

  # You may set WAKTERM_HOSTNAME to a name you want to use instead
  # of calling out to the hostname executable on every prompt print.
if [[ -z "${WAKTERM_HOSTNAME}" ]]; then
  if [[ -r /proc/sys/kernel/hostname ]]; then
    __wakterm_set_user_var "WAKTERM_HOST" "$(cat /proc/sys/kernel/hostname)"
  elif hash hostname 2>/dev/null; then
    __wakterm_set_user_var "WAKTERM_HOST" "$(hostname)"
  elif hash hostnamectl 2>/dev/null; then
    __wakterm_set_user_var "WAKTERM_HOST" "$(hostnamectl hostname)"
  else
    __wakterm_set_user_var "WAKTERM_HOST" "unknown"
  fi
else
  __wakterm_set_user_var "WAKTERM_HOST" "${WAKTERM_HOSTNAME}"
fi

}

__wakterm_user_vars_preexec() {
  # Tell wakterm the full command that is being run
  __wakterm_set_user_var "WAKTERM_PROG" "$1"
}

# Pane-local history. Wakterm gives each pane a WAKTERM_PANE_TOKEN that
# survives mux restarts. The outermost interactive shell in a pane keeps the
# commands entered in that pane in its own file, so Up recalls this pane's
# commands first and then the shared history. Commands typed in this shell
# collect in "<pane>.new" and are merged into both the pane file and the
# shared HISTFILE when the shell exits; a later shell in the same pane merges
# the leftovers of one that was killed. Live history sharing is turned off in
# this shell so other panes' commands do not arrive while it runs.
__wakterm_pane_history_merge() {
  # Append a finished shell's commands to the pane and shared history.
  local new="$1"
  if [[ -s "$new" ]]; then
    cat -- "$new" >> "$__wakterm_pane_histfile"
    if [[ -n "$__wakterm_shared_histfile" ]]; then
      cat -- "$new" >> "$__wakterm_shared_histfile"
    fi
  fi
  rm -f -- "$new"
}

__wakterm_pane_history_exit() {
  if [[ -n "${ZSH_NAME-}" ]]; then
    fc -AI
  else
    history -a
  fi
  __wakterm_pane_history_merge "$__wakterm_pane_histfile.new"
  # Nothing is left for the shell's own exit save to write.
  HISTFILE=
}

__wakterm_pane_history_start() {
  # Run once, at the first prompt, after the shell loaded its shared history.
  [[ -n "${__wakterm_pane_history_started-}" ]] && return 0
  __wakterm_pane_history_started=1
  local dir="${XDG_STATE_HOME:-$HOME/.local/state}/wakterm/pane-history"
  (umask 077 && mkdir -p -- "$dir") || return 0
  __wakterm_shared_histfile="${HISTFILE-}"
  if [[ -n "${ZSH_NAME-}" ]]; then
    __wakterm_pane_histfile="$dir/$WAKTERM_PANE_TOKEN.zsh"
  else
    __wakterm_pane_histfile="$dir/$WAKTERM_PANE_TOKEN.bash"
  fi
  __wakterm_pane_history_merge "$__wakterm_pane_histfile.new"
  if [[ -n "${ZSH_NAME-}" ]]; then
    setopt no_share_history
    [[ -o inc_append_history_time ]] || setopt inc_append_history
    [[ -r "$__wakterm_pane_histfile" ]] && fc -R "$__wakterm_pane_histfile"
    HISTFILE="$__wakterm_pane_histfile.new"
    zshexit_functions+=(__wakterm_pane_history_exit)
  else
    [[ -r "$__wakterm_pane_histfile" ]] && history -r "$__wakterm_pane_histfile"
    HISTFILE="$__wakterm_pane_histfile.new"
    shopt -s histappend
    if [[ -n "${BLE_VERSION-}" ]]; then
      blehook PRECMD+=__wakterm_pane_history_save
    else
      precmd_functions+=(__wakterm_pane_history_save)
    fi
    local previous
    previous="$(trap -p EXIT)"
    if [[ -n "$previous" ]]; then
      previous="${previous#trap -- \'}"
      previous="${previous%\' EXIT}"
      # shellcheck disable=SC2064
      trap "__wakterm_pane_history_exit; $previous" EXIT
    else
      trap __wakterm_pane_history_exit EXIT
    fi
  fi
}

__wakterm_pane_history_save() {
  history -a
}

# The owner check keeps a nested interactive shell, which inherits the token,
# from sharing the pane's files with the shell that started it. `exec`
# replaces the shell without changing its PID, so it keeps ownership.
if [[ -z "${WAKTERM_SHELL_SKIP_PANE_HISTORY-}" && -z "${WSH_NATIVE_PANE_HISTORY-}" \
      && "${WAKTERM_PANE_TOKEN-}" =~ ^[0-9a-f-]{36}$ \
      && ( -z "${WAKTERM_PANE_HISTORY_OWNER-}" || "${WAKTERM_PANE_HISTORY_OWNER-}" == "$$" ) ]]; then
  export WAKTERM_PANE_HISTORY_OWNER="$$"
  if [[ -n "${BLE_VERSION-}" ]]; then
    blehook PRECMD+=__wakterm_pane_history_start
  else
    precmd_functions+=(__wakterm_pane_history_start)
  fi
fi

# Register the various functions; take care to perform osc7 after
# the semantic zones as we don't want to perturb the last command
# status before we've had a chance to report it to the terminal
if [[ -z "${WAKTERM_SHELL_SKIP_SEMANTIC_ZONES-}" ]]; then
  if [[ -n "${BLE_VERSION-}" ]]; then
    blehook PRECMD+=__wakterm_semantic_precmd
    blehook PREEXEC+=__wakterm_semantic_preexec
  else
    precmd_functions+=(__wakterm_semantic_precmd)
    preexec_functions+=(__wakterm_semantic_preexec)
  fi
fi

if [[ -z "${WAKTERM_SHELL_SKIP_USER_VARS-}" ]]; then
  if [[ -n "${BLE_VERSION-}" ]]; then
    blehook PRECMD+=__wakterm_user_vars_precmd
    blehook PREEXEC+=__wakterm_user_vars_preexec
  else
    precmd_functions+=(__wakterm_user_vars_precmd)
    preexec_functions+=(__wakterm_user_vars_preexec)
  fi
fi

if [[ -z "${WAKTERM_SHELL_SKIP_CWD-}" ]] ; then
  if [[ -n "${BLE_VERSION-}" ]]; then
    blehook PRECMD+=__wakterm_osc7
  else
    precmd_functions+=(__wakterm_osc7)
  fi
fi

true
