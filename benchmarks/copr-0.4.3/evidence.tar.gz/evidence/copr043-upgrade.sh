set -euxo pipefail
test "$(rpm -q --qf '%{VERSION}-%{RELEASE}' wsh)" = 0.4.2-1.fc44
dnf -y --refresh upgrade wsh
python3 /var/tmp/test-hosted-043-rpm.py
/usr/bin/wsh --wsh-version
/usr/bin/wsh --wsh-version | grep -Fx 'wsh 0.4.3 (release build)'
rm -rf /var/tmp/wsh-copr-signed
dnf download --destdir /var/tmp/wsh-copr-signed wsh
rpmkeys --checksig -v /var/tmp/wsh-copr-signed/wsh-0.4.3-1.fc44.x86_64.rpm
rpm -V wsh
sha256sum /var/tmp/wsh-copr-signed/wsh-0.4.3-1.fc44.x86_64.rpm /usr/bin/wsh /usr/libexec/wsh/wsh-runtime /usr/share/wsh/manifest.json
rm -rf /var/tmp/wsh-copr-043-history /var/tmp/wsh-copr-043-mail /var/tmp/wsh-copr-doctor-043
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/history-persistence.py /usr/bin/wsh /var/tmp/wsh-copr-043-history
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/mail-check.py /usr/bin/wsh /var/tmp/wsh-copr-043-mail
runuser -u shellempty -- env TMPDIR=/var/tmp /usr/bin/python3 /var/tmp/doctor-terminal.py /usr/bin/wsh /var/tmp/wsh-copr-doctor-043
getenforce
