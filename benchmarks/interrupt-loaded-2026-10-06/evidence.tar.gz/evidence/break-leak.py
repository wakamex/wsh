#!/usr/bin/env python3
"""Interrupt a widget that runs many short loops, then check that the next command still runs."""
import os, pty, select, signal, sys, tempfile, time, random
binary, tries = sys.argv[1], int(sys.argv[2])
d = tempfile.mkdtemp(prefix='break-leak-', dir='/nvme/claude-tmp/claude-1000/-code-wsh/e6dfe348-3cab-4125-b12b-6d74679311ff/scratchpad')
open(os.path.join(d, '.zshrc'), 'w').write('''
PS1='P> '
w() { local i; repeat 1000000 { for i in 1; do :; done } }
zle -N w; bindkey '^T' w
''')
pid, fd = pty.fork()
if not pid:
    os.execve(binary, [binary, '-i'], {'HOME': d, 'ZDOTDIR': d, 'TERM': 'dumb', 'PATH': '/usr/bin:/bin'})
out = bytearray()
def wait_for(token, t):
    end = time.monotonic() + t
    while time.monotonic() < end:
        if token in out: return True
        if select.select([fd], [], [], 0.01)[0]:
            out.extend(os.read(fd, 65536))
    return token in out
assert wait_for(b'P> ', 10)
leaked = None
for n in range(tries):
    del out[:]
    os.write(fd, b'\x14')
    time.sleep(random.uniform(0.005, 0.03))
    os.kill(pid, signal.SIGINT)
    wait_for(b'P> ', 2)
    del out[:]
    os.write(fd, b'print OK$((40+2))\n')
    if not wait_for(b'OK42', 2):
        leaked = n + 1
        break
os.kill(pid, signal.SIGKILL); os.waitpid(pid, 0)
print(binary, 'command skipped after interrupt', leaked if leaked else 'never', 'of', tries)
