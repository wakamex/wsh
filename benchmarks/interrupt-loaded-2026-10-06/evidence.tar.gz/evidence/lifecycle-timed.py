#!/usr/bin/env python3
"""Cancel an actual pending strategy child when the editor accepts Ctrl-C."""
import json
import os
from pathlib import Path
import sys
import time
root=Path('/code/wsh')
source=(root/'native/test-autosuggestions-owner.py').read_text().split("if MODE=='correctness':",1)[0]
namespace={'__file__':str(root/'native/test-autosuggestions-owner.py')}
exec(compile(source,str(root/'native/test-autosuggestions-owner.py'),'exec'),namespace)
namespace['CONFIG']+=r'''
_zsh_autosuggest_strategy_probe() { print -r -- "$1" >> $HOME/requests; sleep 30; suggestion="$1 result"; }
_pending() { print -nr -- $'\x1ePID:'"${_ZSH_AUTOSUGGEST_CHILD_PID-}|${_ZSH_AUTOSUGGEST_ASYNC_FD-}"$'\x1f'; }
zle -N _pending
bindkey '^Y' _pending
'''
if '--no-monitor' in sys.argv:namespace['CONFIG']+='\nunsetopt monitor\n'
shell=namespace['Shell']('candidate','pending-cancel','custom')
try:
 os.write(shell.fd,b'pending request')
 request=shell.home/'requests';end=time.monotonic()+5
 while not request.exists() or 'pending request' not in request.read_text():
  assert time.monotonic()<end;time.sleep(.005)
 offset=len(shell.output);os.write(shell.fd,b'\x19');shell.wait(b'\x1ePID:',offset)
 start=shell.output.index(b'\x1ePID:',offset)+5;shell.wait(b'\x1f',start)
 pid=int(shell.output[start:shell.output.index(b'|',start)])
 (namespace['OUT']/'before-cancel.json').write_text(json.dumps(dict(pid=pid,pgid=os.getpgid(pid),stat=Path('/proc',str(pid),'stat').read_text()),indent=2)+'\n')
 offset=len(shell.output);_st=lambda q: Path('/proc',str(q),'stat').read_text().rsplit(')',1)[1].split();_pre=_st(shell.pid)[5];import termios as _tm;_lf=_tm.tcgetattr(shell.fd)[3];t0=time.monotonic();os.write(shell.fd,b'\x03');_lf2=_tm.tcgetattr(shell.fd)[3];print('ISIG_AT_CTRL_C before',bool(_lf & _tm.ISIG),'after',bool(_lf2 & _tm.ISIG),'ICANON',bool(_lf & _tm.ICANON),flush=True);_post=_st(shell.pid)[5];print('AT_CTRL_C shell_pgid',_st(shell.pid)[2],'tty_fg_before',_pre,'tty_fg_after',_post,flush=True)
 end2=time.monotonic()+60
 while namespace['base'].READY not in shell.output[offset:]:
  if time.monotonic()>t0+15:
   import subprocess
   sp=shell.pid
   st=lambda q: Path('/proc',str(q),'stat').read_text().rsplit(')',1)[1].split()
   ss=st(sp); print('PGRP shell pgid',ss[2],'tty foreground pgid',ss[5],'| child',pid,'pgid',st(pid)[2] if Path('/proc',str(pid)).exists() else 'gone',flush=True)
   print('SIGSTATE',[l for l in Path('/proc',str(sp),'status').read_text().splitlines() if l.startswith(('SigPnd','ShdPnd','SigBlk','SigIgn','SigCgt'))],flush=True)
   print('HANG shell',sp,'state',[l for l in Path('/proc',str(sp),'status').read_text().splitlines() if l.startswith('State')],'wchan',Path('/proc',str(sp),'wchan').read_text(),flush=True)
   print(subprocess.run(['ps','-o','pid,ppid,stat,wchan:30,cmd','--ppid',str(sp)],capture_output=True,text=True).stdout,flush=True)
   print(subprocess.run(['ps','-o','pid,ppid,stat,wchan:30,cmd','-p',str(pid)],capture_output=True,text=True).stdout,flush=True)
   for tool in (['gdb','-p',str(sp),'-batch','-ex','p (int)errflag','-ex','p (int)wsh_dbg_pos','-ex','x/128dw &wsh_dbg_ring','-ex','p (int)zlell','-ex','p (int)zlecs','-ex','p (int)curhist','-ex','p (int)lastval','-ex','p (int)zleactive','-ex','p (int)queueing_enabled','-ex','p (int)queue_front','-ex','p (int)queue_rear','-ex','bt'],):
    try: print(subprocess.run(tool,capture_output=True,text=True,timeout=60).stdout[-3000:],flush=True)
    except Exception as e: print('no',tool[0],e)
   raise AssertionError('hang captured')
  import select
  if select.select([shell.fd],[],[],0.05)[0]: shell.output.extend(os.read(shell.fd,65536))
 print('PROMPT_AFTER %.2f s child_alive=%s'%(time.monotonic()-t0,Path('/proc',str(pid)).exists()),flush=True)
 offset=len(shell.output);os.write(shell.fd,b'\x19')
 try: shell.wait(b'\x1ePID:|\x1f',offset)
 except RuntimeError:
  import select as _s2
  _t1=time.monotonic(); _end=_t1+45
  while b'\x1ePID:' not in shell.output[offset:] and time.monotonic()<_end:
   if _s2.select([shell.fd],[],[],.1)[0]: shell.output.extend(os.read(shell.fd,65536))
  print('RECOVERY', 'PID output after %.1f s more'%(time.monotonic()-_t1) if b'\x1ePID:' in shell.output[offset:] else 'none in 45 s', 'child_alive_now=%s'%Path('/proc',str(pid)).exists(), flush=True)
  o2=len(shell.output)
  os.write(shell.fd,b"\x15print -r -- STATE: bind=\"$(bindkey '^Y')\" widget=\"${widgets[_pending]-missing}\" pid=\"${_ZSH_AUTOSUGGEST_CHILD_PID-}\" fd=\"${_ZSH_AUTOSUGGEST_ASYNC_FD-}\"\n")
  end3=time.monotonic()+10
  import select as _sel
  while b'STATE: bind' not in shell.output[o2:].replace(b'print -r -- STATE: bind',b'') and time.monotonic()<end3:
   if _sel.select([shell.fd],[],[],.1)[0]: shell.output.extend(os.read(shell.fd,65536))
  import re as _re
  _u=lambda: sum(int(x) for x in Path('/proc',str(shell.pid),'stat').read_text().rsplit(')',1)[1].split()[11:13]); _a=_u(); time.sleep(1); print('CPU_TICKS_PER_S',_u()-_a,flush=True)
  _w="*(char**)&watch_fds"
  _g=__import__('subprocess').run(['gdb','-p',str(shell.pid),'-batch','-ex','p (int)errflag','-ex','p *(int*)&nwatch','-ex','p *(char**)('+_w+')','-ex','p *(int*)(('+_w+')+8)','-ex','p *(char**)(('+_w+')+16)','-ex','p *(int*)(('+_w+')+24)','-ex','p *(char**)((*(char**)&funcstack)+8)','-ex','p *(int*)&breaks','-ex','p *(int*)&loops','-ex','p *(int*)&retflag','-ex','p *(int*)&contflag','-ex','p *(int*)&exit_pending','-ex','bt 12','-ex','p *(int*)&wsh_dbg_pos','-ex','x/256dw &wsh_dbg_ring'],capture_output=True,text=True,timeout=60).stdout
  print('GDB_AFTER_FAILURE',[l for l in _g.splitlines() if l.startswith(('$','#','0x'))],flush=True)
  print('FDS',{f:__import__('os').readlink('/proc/%d/fd/%s'%(shell.pid,f)) for f in __import__('os').listdir('/proc/%d/fd'%shell.pid)},flush=True)
  print('AFTER_FAILURE',_re.findall(rb'STATE: bind="[^\n]*',bytes(shell.output[o2:]))[-1:],flush=True)
  raise
 end=time.monotonic()+3
 while Path('/proc',str(pid)).exists():
  assert time.monotonic()<end,('strategy child survived',pid,Path('/proc',str(pid),'stat').read_text());time.sleep(.01)
 (namespace['OUT']/'lifecycle.json').write_text(json.dumps(dict(ctrl_c_prompt=True,fd_cleared=True,child_reaped=True,pid=pid),indent=2)+'\n')
 print('PASS: pending strategy cancellation, fd cleanup, child reaping and prompt return')
finally:shell.close()
