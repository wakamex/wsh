module_path=($1 $module_path)
zmodload wshdirectory || exit 90
source "$2"
zshz --add "$HOME/project"
