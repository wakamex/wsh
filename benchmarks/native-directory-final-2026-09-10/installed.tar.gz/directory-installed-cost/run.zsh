module_path=($1 $module_path)
(( $+builtins[wsh-directory] )) || zmodload wshdirectory || exit 90
source "$2"
shift 2
zshz "$@"
