module_path=($1 $module_path)
(( $+builtins[wsh-directory] )) || zmodload wshdirectory || exit 90
ZSHZ_CMD=jump
source "$2"
_custom_cd() { print -r -- "CUSTOM:$1"; builtin cd "$1" }
ZSHZ_CD=_custom_cd
zshz project || exit 1
[[ $PWD == "$HOME/project" ]] || exit 2
zsh-z_plugin_unload || exit 3
(( ! $+aliases[jump] && ! $+functions[zshz] )) || exit 4
(( ${#${(M)chpwd_functions:#_zshz_chpwd}} == 0 )) || exit 5
(( ${#${(M)precmd_functions:#_zshz_precmd}} == 0 )) || exit 6
print UNLOADED
