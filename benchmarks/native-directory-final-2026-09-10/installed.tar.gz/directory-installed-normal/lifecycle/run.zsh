module_path=($1 $module_path)
(( $+builtins[wsh-directory] )) || zmodload wshdirectory || exit 90
source "$2"
cd "$HOME/project"
zshz -x "$PWD" || exit 1
if [[ $3 == reenter ]]; then
  cd "$HOME/other"
  cd "$HOME/project"
elif [[ $3 == reload ]]; then
  zsh-z_plugin_unload || exit 2
  source "$2"
fi
_zshz_precmd
