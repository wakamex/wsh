import json
from pathlib import Path
import subprocess
import sys
bundle=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True)
fixture=out/'fixture'
subprocess.run(['python3','native/prepare-directory-owner.py',fixture],check=True)
assert (fixture/'candidate.zsh').read_bytes()==(bundle/'share/wsh/defaults/zsh-z/native.zsh').read_bytes()
rows=[]
for name in ['query','owner','persistence','lifecycle','confirmation','zle']:
 command=['python3','native/test-directory-'+name+'.py',str(bundle/'bin/zsh'),str(fixture),str(fixture),str(out/name)]
 with (out/(name+'.log')).open('wb') as log:
  r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 rows.append(dict(test=name,command=command,status=r.returncode))
 (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,r.returncode,flush=True)
 assert r.returncode==0
