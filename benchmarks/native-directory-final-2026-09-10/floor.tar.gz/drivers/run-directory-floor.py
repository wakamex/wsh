import json
from pathlib import Path
import subprocess
import tarfile
root=Path('/code/wsh')
out=Path('/var/tmp/wsh-directory-floor');out.mkdir(exist_ok=True)
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
epoch=subprocess.check_output(['git','show','-s','--format=%ct','HEAD'],cwd=root,text=True).strip()
work=out/'native'
subprocess.run(['git','worktree','add','--detach',str(work),revision],cwd=root,check=True)
with tarfile.open(root/'benchmarks/native-qualification-2026-09-09/floor-results.tar.gz') as t:
 command=json.load(t.extractfile('build-a-command.json'))
command=[s.replace('/var/tmp/wsh-native-qualification/build-a',str(work)).replace('WSH_SOURCE_REVISION=a98029edea2733e69465d817a9ae999597ad7864','WSH_SOURCE_REVISION='+revision).replace('SOURCE_DATE_EPOCH=1788942025','SOURCE_DATE_EPOCH='+epoch) for s in command]
command.insert(3,'--init')
(out/'native-command.json').write_text(json.dumps(command,indent=2)+'\n')
with (out/'native-build.log').open('wb') as log:
 result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
(out/'native-build-status.json').write_text(json.dumps({'revision':revision,'status':result.returncode})+'\n')
raise SystemExit(result.returncode)
