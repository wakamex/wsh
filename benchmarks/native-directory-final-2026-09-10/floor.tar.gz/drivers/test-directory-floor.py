import json
from pathlib import Path
import subprocess
import sys
bundle=Path(sys.argv[1])
reference=Path('/reference')
out=Path('/workspace/build/floor/qualification');out.mkdir(parents=True,exist_ok=True)
fixture=out/'fixture'
subprocess.run(['python3','native/prepare-directory-owner.py',fixture],check=True)
commands=[['python3','native/check-installation.py',str(bundle),str(out/'contracts')],
 ['python3','native/test-installed-completion.py',str(bundle),str(reference),str(out/'completion'),'correctness'],
 ['python3','native/test-history-owner.py',str(bundle/'bin/zsh'),'installed',str(out/'history'),'correctness']]
for name in ['query','owner','persistence','lifecycle','confirmation','zle']:
 commands.append(['python3','native/test-directory-'+name+'.py',str(bundle/'bin/zsh'),str(fixture),str(fixture),str(out/('directory-'+name))])
for name in ['recovery','profile','profile-lifecycle','profile-isolation']:
 commands.append(['python3','native/test-'+name+'.py',str(bundle),str(out/name)])
commands += [
 ['python3','native/test-profile-report.py',str(bundle/'bin/wsh'),str(out/'profile-report'),'--native'],
 ['python3','native/test-profile-storage.py',str(bundle/'bin/wsh'),str(out/'profile-storage')],
 ['python3','native/test-runtime-lifecycle.py',str(bundle/'bin/wsh-runtime'),str(out/'runtime-lifecycle')],
 ['python3','native/test-runtime-protocol.py','/workspace/build/portable/glibc-2.28/target/release/wsh-runtime',str(bundle/'bin/wsh-runtime'),str(out/'runtime-protocol')]]
rows=[]
for i,command in enumerate(commands):
 with (out/(str(i)+'.log')).open('wb') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 rows.append(dict(command=command,status=r.returncode))
 (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(command[1],r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
