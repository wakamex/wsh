import json
from pathlib import Path
import shutil
import subprocess
out=Path('/var/tmp/wsh-directory-floor')
work=out/'native'
bundles=list((work/'build/floor/bundles').glob('[0-9a-f]'*64))
assert len(bundles)==1,bundles
bundle='/workspace/build/floor/bundles/'+bundles[0].name
shutil.copy2('/var/tmp/wsh-native-adoption/test-directory-floor.py',work/'build/floor/test-directory-floor.py')
command=['podman','run','--rm','--init','--userns=keep-id','--network=none','--workdir','/workspace',
 '--volume',str(work)+':/workspace:Z',
 '--volume','/code/wsh/build/portable/glibc-2.28:/workspace/build/portable/glibc-2.28:ro,z',
 '--volume','/var/tmp/wsh-native-qualification/build-a/build/floor/bundles/0cbd6a555c6647af5750035e84e1da666b2d867212fad97f2c2dfc5884b31b5d:/reference:ro,z',
 '--volume','/home/mihai/.oh-my-zsh:/omz:ro,z',
 '--env','WSH_TEST_ZSH=/workspace/build/portable/glibc-2.28/zsh/zsh-cad0d67c-wsh2/bin/zsh',
 '--env','WSH_REFERENCE_ZSH=/workspace/build/portable/glibc-2.28/zsh/zsh-cad0d67c-wsh2/bin/zsh',
 '--env','WSH_TEST_MANAGER=/workspace/build/floor/target/release/wsh',
 '--env','WSH_TEST_OMZ=/omz','--env','LANG=C.UTF-8','--env','LC_ALL=C.UTF-8',
 'localhost/wsh-native-floor-prototype-20260909','python3','build/floor/test-directory-floor.py',bundle]
(out/'native-tests-command.json').write_text(json.dumps(command,indent=2)+'\n')
with (out/'native-tests.log').open('wb') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
(out/'native-tests-status.json').write_text(json.dumps({'status':r.returncode,'bundle':bundles[0].name})+'\n')
raise SystemExit(r.returncode)
