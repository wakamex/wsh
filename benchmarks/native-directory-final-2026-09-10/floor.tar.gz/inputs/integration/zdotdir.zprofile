if (( ${+WSH_STARTUP_BUNDLE_ZDOTDIR} )); then
  ZDOTDIR=$WSH_USER_ZDOTDIR
  typeset -g WSH_STARTUP_FILE=$ZDOTDIR/.zprofile
  if [[ $WSH_STARTUP_RCS == on && $WSH_STARTUP_FILE != $WSH_STARTUP_BUNDLE_ZDOTDIR/.zprofile && ( -e $WSH_STARTUP_FILE || -L $WSH_STARTUP_FILE ) ]]; then
    (( $+functions[_wsh_profile_event] )) && _wsh_profile_event user-zprofile-start
    source $WSH_STARTUP_FILE
    (( $+functions[_wsh_profile_event] )) && _wsh_profile_event user-zprofile-end
    WSH_STARTUP_RCS=$options[rcs]
  fi
  WSH_USER_ZDOTDIR=$ZDOTDIR
  unset WSH_STARTUP_FILE
  setopt rcs
  ZDOTDIR=$WSH_STARTUP_BUNDLE_ZDOTDIR
fi
