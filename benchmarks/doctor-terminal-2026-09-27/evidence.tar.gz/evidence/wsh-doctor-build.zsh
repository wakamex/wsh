#!/usr/bin/zsh
set -eu
cd /code/wsh
podman run --rm --init --userns=keep-id --network=none \
 --volume /code/wsh:/workspace:Z --workdir /workspace \
 --env LANG=C --env LC_ALL=C --env TZ=UTC \
 --env WSH_BUILD_JOBS=4 --env WSH_KEEP_FAILED_BUILD=1 \
 --env WSH_NATIVE_OUTPUT_ROOT=/workspace/build/portable/doctor-terminal \
 --env WSH_BUNDLE_STATUS=development --env WSH_MINIMUM_GLIBC=2.28 \
 --env WSH_BUILDER_BASE_IMAGE=native-sdk-sha256:e1fdf68370077c882beeaa4b6be901a2552d04450b018109611eb53c1245dca9 \
 sha256:f714819ef1c9dc9a2741370a9b10c4c105a5798c49661fc94176dc36687527c0 \
 zsh /workspace/build/test-native-installation.zsh
